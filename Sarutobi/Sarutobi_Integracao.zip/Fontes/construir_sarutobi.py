#!/usr/bin/env python3
"""Gera o traje de Hiruzen e o bastão de Enma para as duas edições Sarutobi."""

import argparse
from copy import deepcopy
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import ZipFile

from aplicar_integracao import PACK_UUIDS, ROOT, apply, open_packs, sha256
from modelagem import MODES, RIG, SIZE, atlas, create_model, staff_geometry

VERSION = [18, 11, 79]
BASE_VERSION = [18, 11, 78]
VARIANTS = {
    'original': ('18.11.64', 'Sarutobi.mcaddon'),
    'cumulativa': ('18.11.73', 'Sarutobi_Cumulativo.mcaddon'),
}
SLOT = 'slot.armor.head'
SOURCE_RIG = 'models/entity/swbr39/custom.geo.json'
RENDER = 'controller.render.swbr.sarutobi.traje'
RENDER_PATH = 'render_controllers/swbr_sarutobi.json'
VISIBLE = 'variable.swbr_sarutobi_equipped'
STAFF_VISIBLE = 'variable.swbr_sarutobi_bastao'
GATE = (f"{VISIBLE} = context.item_slot == 'head' && !context.is_first_person"
        " && !(context.owning_entity -> q.is_spectator) && !(context.owning_entity -> q.is_invisible);")
EMPTY_HAND = "(context.owning_entity -> q.get_equipped_item_name('main_hand'))"
PLAYER = 'entity/player.entity.json'
PLAYER_RENDER = 'render_controllers/player.json'
HELMET = 'v.swbr_sarutobi_capacete'
EYE_LAYERS = {'controller.render.nzs_olho_dourado', 'controller.render.nzs_olho_azul',
              'controller.render.nzs_olho_mangekyou_flor', 'controller.render.swbr_v18735.lp_hair'}
ENMA_TEXTURE = 'textures/entity/swbr/sarutobi/bastao_enma'
STAFF_ATTACHABLES = {
    'bastao_enma': 'attachables/nz_bastao_enma.json',
    'bastao_enma3h': 'attachables/zenkai_autoral/bastao_enma3h.json',
}
AGE = "(context.owning_entity -> q.property('nzs:body_age'))"
SCALE = f'0.9375 * ({AGE} == 1 ? 0.87 : ({AGE} == 2 ? 0.70 : 1.0))'


def read(pack, name):
    return json.loads(pack.read(name))


def write_json(file, doc):
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def record(file, root):
    return {'arquivo': file.relative_to(root).as_posix(), 'sha256': sha256(file.read_bytes())}


def attachable(source, mode):
    original = source['minecraft:attachable']['description']
    if original['identifier'] != mode.item:
        raise ValueError(f'Identificador original inesperado em {mode.attachable}.')
    show_staff = f"{VISIBLE} && ({EMPTY_HAND} == '' || {EMPTY_HAND} == 'minecraft:air')" if mode.stage == 2 else '0.0'
    desc = {
        'identifier': mode.item,
        'materials': {'default': 'entity_alphatest'},
        'textures': {'default': mode.texture},
        'geometry': {'default': mode.geometry},
        'animations': {'fitas': mode.animation},
        'scripts': {'parent_setup': original['scripts']['parent_setup'],
                    'pre_animation': [GATE, f'{STAFF_VISIBLE} = {show_staff};'],
                    'scale': SCALE, 'animate': [{'fitas': VISIBLE}]},
        'render_controllers': [RENDER],
    }
    if 'item' in original:
        desc['item'] = original['item']
    return {'format_version': '1.10.0', 'minecraft:attachable': {'description': desc}}


def helmet_code():
    items = ', '.join(f"'{mode.item}'" for mode in MODES)
    return (f"{HELMET} = (!v.swbr_view_first_person && !v.swbr_view_map_face && !q.is_spectator && !q.is_invisible"
            f" && q.is_item_name_any('slot.armor.head', 0, {items})) ? 1.0 : 0.0;")


def mask_cosmetics(document):
    desc = document['minecraft:client_entity']['description']
    code = desc['scripts']['pre_animation']
    if not any(line.startswith('v.swbr_view_first_person =') for line in code):
        raise ValueError('Contexto de câmera do jogador ausente na base.')
    code.append(helmet_code())
    patched = set()
    for controller in desc['render_controllers']:
        if not isinstance(controller, dict):
            continue
        for name, requirement in controller.items():
            if re.fullmatch(r'controller\.render\.cabelo\d+', name) or name in EYE_LAYERS:
                controller[name] = f'({requirement}) && !{HELMET}'
                patched.add(name)
    expected = {f'controller.render.cabelo{n}' for n in range(1, 28)} | EYE_LAYERS
    if patched != expected:
        raise ValueError('Camadas de cabelo ou olhos divergentes.')
    return document


def mask_hat(document):
    parts = document['render_controllers']['controller.render.player.third_person']['part_visibility']
    wildcard = parts[0]['*']
    for item in parts:
        if 'hat' in item:
            item['hat'] = f"({item['hat']}) && !{HELMET}"
            return document
    parts.append({'hat': f'({wildcard}) && !{HELMET}'})
    return document


def staff_attachable(document, item):
    desc = document['minecraft:attachable']['description']
    if desc['identifier'] != f'nz:{item}':
        raise ValueError(f'Identificador inesperado para {item}.')
    desc['materials']['default'] = 'entity_alphatest'
    desc['textures']['default'] = ENMA_TEXTURE
    desc['geometry']['default'] = f'geometry.swbr.sarutobi.{item}'
    if item == 'bastao_enma':
        # A animação antiga de terceira pessoa não existe no pacote.
        desc['animations'].pop('wield_third_person')
        desc['scripts']['animate'] = [{'wield_first_person': 'c.is_first_person'}]
    return document


def update_manifest(original, family):
    manifest = deepcopy(original)
    version = '.'.join(map(str, VERSION))
    manifest['header'].update(name=f'Shinobi World BR {version} · Sarutobi',
                              description=f'Shinobi World BR {version} | Revisão visual Sarutobi | Base {family}',
                              version=VERSION)
    for module in manifest['modules']:
        module['version'] = VERSION
    for dependency in manifest.get('dependencies', []):
        if dependency.get('uuid') in PACK_UUIDS.values():
            dependency['version'] = VERSION
    return manifest


def check_source(bp, rp):
    bones = {b['name']: b for b in read(rp, SOURCE_RIG)['minecraft:geometry'][0]['bones']}
    for name, parent, pivot in RIG:
        if bones[name].get('parent') != parent or tuple(bones[name]['pivot']) != pivot:
            raise ValueError(f'Pivô nativo alterado em {name}.')
    for mode in MODES:
        item = read(bp, f'items/nz_modo_sarutobi_v{mode.stage}.json')['minecraft:item']
        if item['description']['identifier'] != mode.item or item['components']['minecraft:wearable']['slot'] != SLOT:
            raise ValueError(f'Slot ou ID diverge em {mode.item}.')


def build(original, cumulative, prior_integration, root=ROOT):
    inputs = {'original': original, 'cumulativa': cumulative}
    overlay = root / 'Integracao'
    rp = overlay / 'RP'
    version = '.'.join(map(str, VERSION))
    manifest = {'cla': 'Sarutobi', 'versao': VERSION, 'slot': SLOT, 'modos': {}, 'bases': {}, 'arquivos': {'BP': {}, 'RP': {}}}
    with ZipFile(prior_integration) as archive:
        older = json.loads(archive.read('Integracao_Manifesto.json'))['bases']
    bindings = {}
    for variant, addon in inputs.items():
        family, _ = VARIANTS[variant]
        packs = open_packs(addon)
        spec = {'nome': addon.name, 'sha256': sha256(addon.read_bytes()), 'packs': {}}
        with ZipFile(BytesIO(packs['BP'][2])) as source_bp, ZipFile(BytesIO(packs['RP'][2])) as source_rp:
            check_source(source_bp, source_rp)
            for mode in MODES:
                source_binding = read(source_rp, mode.attachable)
                if mode.key in bindings and bindings[mode.key] != source_binding:
                    raise ValueError(f'Attachable {mode.item} diverge entre as edições.')
                bindings[mode.key] = source_binding
            for item, path in STAFF_ATTACHABLES.items():
                binding = read(source_rp, path)
                if item in bindings and bindings[item] != binding:
                    raise ValueError(f'Attachable {item} diverge entre as edições.')
                bindings[item] = binding
            skins = {PLAYER: mask_cosmetics(read(source_rp, PLAYER)),
                     PLAYER_RENDER: mask_hat(read(source_rp, PLAYER_RENDER))}
        for kind, (entry, info, _) in packs.items():
            if info['header']['version'] != BASE_VERSION or not info['header']['description'].endswith('Base ' + family):
                raise ValueError(f'Use a edição Sarutobi 18.11.78 {variant}.')
            file = overlay / 'Versoes' / variant / kind / 'manifest.json'
            write_json(file, update_manifest(info, family))
            spec['packs'][kind] = {'entrada': entry, 'saida': f'SWBR_{kind}_v{version}_SARUTOBI.mcpack',
                                    'arquivos': {'manifest.json': record(file, root)}}
            if kind == 'RP':
                for path, document in skins.items():
                    target = overlay / 'Versoes' / variant / 'RP' / path
                    write_json(target, document)
                    spec['packs'][kind]['arquivos'][path] = record(target, root)
        manifest['bases'][f'{variant}-18.11.78'] = spec
        manifest['bases'][f'{variant}-18.11.77'] = {
            'nome': older[variant]['nome'], 'sha256': older[variant]['sha256'],
            'packs': {key: {**pack, 'entrada': older[variant]['packs'][key]['entrada']}
                      for key, pack in spec['packs'].items()},
        }

    for mode in MODES:
        model = create_model(mode)
        write_json(rp / mode.geometry_path, model.geometry())
        write_json(rp / mode.animation_path, model.animation())
        write_json(rp / mode.attachable, attachable(bindings[mode.key], mode))
        texture = rp / (mode.texture + '.png')
        texture.parent.mkdir(parents=True, exist_ok=True)
        atlas(mode.stage).save(texture, optimize=True)
        manifest['modos'][mode.key] = {
            'id': mode.item, 'nome': mode.name, 'projeto': mode.project, 'attachable': mode.attachable,
            'geometria': mode.geometry, 'arquivo_geo': mode.geometry_path,
            'animacao': mode.animation, 'arquivo_anim': mode.animation_path, 'textura': mode.texture + '.png',
            'cubos': sum(len(bone.get('cubes', [])) for bone in model.bones.values()),
            'bones': len(model.bones), 'atlas': SIZE,
        }
    for item, path in STAFF_ATTACHABLES.items():
        write_json(rp / path, staff_attachable(bindings[item], item))
        staff_path = rp / f'models/entity/swbr/sarutobi/{item}.geo.json'
        write_json(staff_path, staff_geometry(item, first_person_animation=item == 'bastao_enma'))
    staff_texture = rp / (ENMA_TEXTURE + '.png')
    atlas(2).save(staff_texture, optimize=True)
    write_json(rp / RENDER_PATH, {'format_version': '1.8.0', 'render_controllers': {
        RENDER: {'geometry': 'Geometry.default', 'materials': [{'*': 'Material.default'}],
                 'textures': ['Texture.default'], 'part_visibility': [{'*': VISIBLE},
                                                                    {'sar_bastao_de_enma': STAFF_VISIBLE}]},
    }})
    manifest['arquivos']['RP'] = {file.relative_to(rp).as_posix(): record(file, root)
                                   for file in sorted(rp.rglob('*')) if file.is_file()}
    write_json(root / 'Integracao_Manifesto.json', manifest)
    for variant, addon in inputs.items():
        print(apply(addon, root / VARIANTS[variant][1], root))
    for info in manifest['modos'].values():
        print(info['nome'], info['cubos'], 'cubos', info['bones'], 'ossos')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path, help='Sarutobi.mcaddon 18.11.78')
    parser.add_argument('cumulativa', type=Path, help='Sarutobi_Cumulativo.mcaddon 18.11.78')
    parser.add_argument('integracao_anterior', type=Path, help='Sarutobi_Integracao.zip 18.11.78')
    args = parser.parse_args()
    build(args.original, args.cumulativa, args.integracao_anterior)
