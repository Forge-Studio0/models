#!/usr/bin/env python3
"""Gera os três visuais Sarutobi e atualiza os dois pacotes Hōzuki 18.11.77."""

import argparse
from copy import deepcopy
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

from aplicar_integracao import PACK_UUIDS, ROOT, apply, open_packs, sha256
from modelagem import MODES, RIG, SIZE, atlas, create_model

VERSION = [18, 11, 78]
BASE_VERSION = [18, 11, 77]
VARIANTS = {
    'original': ('18.11.64', 'Sarutobi.mcaddon'),
    'cumulativa': ('18.11.73', 'Sarutobi_Cumulativo.mcaddon'),
}
SLOT = 'slot.armor.head'
SOURCE_RIG = 'models/entity/swbr39/custom.geo.json'
RENDER = 'controller.render.swbr.sarutobi.traje'
RENDER_PATH = 'render_controllers/swbr_sarutobi.json'
VISIBLE = 'variable.swbr_sarutobi_equipped'
GATE = f"{VISIBLE} = context.item_slot == 'head' && !context.is_first_person;"
AGE = "(context.owning_entity -> q.property('nzs:body_age'))"
SCALE = f'0.9375 * ({AGE} == 1 ? 0.87 : ({AGE} == 2 ? 0.70 : 1.0))'


def read(pack, name):
    return json.loads(pack.read(name))


def write_json(file, doc):
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def record(file, root):
    return {'arquivo': file.relative_to(root).as_posix(), 'sha256': sha256(file.read_bytes())}


def attachable(source, mode):
    original = source['minecraft:attachable']['description']
    if original['identifier'] != mode.item:
        raise ValueError(f'Identificador original inesperado em {mode.attachable}.')
    desc = {
        'identifier': mode.item,
        'materials': {'default': 'entity_alphatest'},
        'textures': {'default': mode.texture},
        'geometry': {'default': mode.geometry},
        'animations': {'cauda': mode.animation},
        'scripts': {'parent_setup': original['scripts']['parent_setup'], 'pre_animation': [GATE],
                    'scale': SCALE, 'animate': [{'cauda': VISIBLE}]},
        'render_controllers': [RENDER],
    }
    if 'item' in original:
        desc['item'] = original['item']
    return {'format_version': '1.10.0', 'minecraft:attachable': {'description': desc}}


def update_manifest(original, family):
    manifest = deepcopy(original)
    version = '.'.join(map(str, VERSION))
    manifest['header'].update(name=f'Shinobi World BR {version} · Sarutobi',
                              description=f'Shinobi World BR {version} | Revisão visual Sarutobi | Base {family}',
                              version=VERSION)
    for module in manifest['modules']:
        module['version'] = VERSION
    for dependency in manifest.get('dependencies', []):
        if dependency.get('uuid') in PACK_UUIDS.values():
            dependency['version'] = VERSION
    return manifest


def check_source(bp, rp):
    bones = {b['name']: b for b in read(rp, SOURCE_RIG)['minecraft:geometry'][0]['bones']}
    for name, parent, pivot in RIG:
        if bones[name].get('parent') != parent or tuple(bones[name]['pivot']) != pivot:
            raise ValueError(f'Pivô nativo alterado em {name}.')
    for mode in MODES:
        item = read(bp, f'items/nz_modo_sarutobi_v{mode.stage}.json')['minecraft:item']
        if item['description']['identifier'] != mode.item or item['components']['minecraft:wearable']['slot'] != SLOT:
            raise ValueError(f'Slot ou ID diverge em {mode.item}.')


def build(original, cumulative, root=ROOT):
    inputs = {'original': original, 'cumulativa': cumulative}
    overlay = root / 'Integracao'
    rp = overlay / 'RP'
    version = '.'.join(map(str, VERSION))
    manifest = {'cla': 'Sarutobi', 'versao': VERSION, 'slot': SLOT, 'modos': {}, 'bases': {}, 'arquivos': {'BP': {}, 'RP': {}}}
    bindings = {}
    for variant, addon in inputs.items():
        family, _ = VARIANTS[variant]
        packs = open_packs(addon)
        spec = {'nome': addon.name, 'sha256': sha256(addon.read_bytes()), 'packs': {}}
        with ZipFile(BytesIO(packs['BP'][2])) as source_bp, ZipFile(BytesIO(packs['RP'][2])) as source_rp:
            check_source(source_bp, source_rp)
            for mode in MODES:
                source_binding = read(source_rp, mode.attachable)
                if mode.key in bindings and bindings[mode.key] != source_binding:
                    raise ValueError(f'Attachable {mode.item} diverge entre as edições.')
                bindings[mode.key] = source_binding
        for kind, (entry, info, _) in packs.items():
            if info['header']['version'] != BASE_VERSION or not info['header']['description'].endswith('Base ' + family):
                raise ValueError(f'Use a edição Hōzuki 18.11.77 {variant}.')
            file = overlay / 'Versoes' / variant / kind / 'manifest.json'
            write_json(file, update_manifest(info, family))
            spec['packs'][kind] = {'entrada': entry, 'saida': f'SWBR_{kind}_v{version}_SARUTOBI.mcpack',
                                    'arquivos': {'manifest.json': record(file, root)}}
        manifest['bases'][variant] = spec

    for mode in MODES:
        model = create_model(mode)
        write_json(rp / mode.geometry_path, model.geometry())
        write_json(rp / mode.animation_path, model.animation())
        write_json(rp / mode.attachable, attachable(bindings[mode.key], mode))
        texture = rp / (mode.texture + '.png')
        texture.parent.mkdir(parents=True, exist_ok=True)
        atlas(mode.stage).save(texture, optimize=True)
        manifest['modos'][mode.key] = {
            'id': mode.item, 'nome': mode.name, 'projeto': mode.project, 'attachable': mode.attachable,
            'geometria': mode.geometry, 'arquivo_geo': mode.geometry_path,
            'animacao': mode.animation, 'arquivo_anim': mode.animation_path, 'textura': mode.texture + '.png',
            'cubos': sum(len(bone.get('cubes', [])) for bone in model.bones.values()),
            'bones': len(model.bones), 'atlas': SIZE,
        }
    write_json(rp / RENDER_PATH, {'format_version': '1.8.0', 'render_controllers': {
        RENDER: {'geometry': 'Geometry.default', 'materials': [{'*': 'Material.default'}],
                 'textures': ['Texture.default'], 'part_visibility': [{'*': VISIBLE}]},
    }})
    manifest['arquivos']['RP'] = {file.relative_to(rp).as_posix(): record(file, root)
                                   for file in sorted(rp.rglob('*')) if file.is_file()}
    write_json(root / 'Integracao_Manifesto.json', manifest)
    for variant, addon in inputs.items():
        print(apply(addon, root / VARIANTS[variant][1], root))
    for info in manifest['modos'].values():
        print(info['nome'], info['cubos'], 'cubos', info['bones'], 'ossos')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path, help='Hozuki.mcaddon 18.11.77')
    parser.add_argument('cumulativa', type=Path, help='Hozuki_Cumulativo.mcaddon 18.11.77')
    args = parser.parse_args()
    build(args.original, args.cumulativa)
