/* Simula o equipar e retirar de cada attachable, incluindo câmera e idade. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { Molang, Context } = require('molang');
const root = path.resolve(__dirname, '..');
const rp = path.join(root, 'Integracao', 'RP');
const read = name => JSON.parse(fs.readFileSync(name, 'utf8'));
const manifest = read(path.join(root, 'Integracao_Manifesto.json'));
const controllers = read(path.join(rp, 'render_controllers/swbr_sarutobi.json')).render_controllers;
const report = {};

for (const mode of Object.values(manifest.modos)) {
  const desc = read(path.join(rp, mode.attachable))['minecraft:attachable'].description;
  const gate = controllers[desc.render_controllers[0]].part_visibility[0]['*'];
  const animate = desc.scripts.animate[0].cauda;
  let total = 0;
  for (const item_slot of ['head', 'main_hand', 'off_hand', 'chest', 'legs', 'feet', '']) {
    for (const is_first_person of [0, 1]) {
      for (const age of [0, 1, 2]) {
        const context = {
          item_slot, is_first_person,
          owning_entity: new Context({ query: { property: name => name === 'nzs:body_age' ? age : 0 } }),
        };
        const molang = new Molang({ context }, { useCache: false });
        const visible = item_slot === 'head' && !is_first_person;
        molang.execute(desc.scripts.pre_animation[0]);
        assert.equal(Boolean(molang.execute(gate)), visible, mode.id);
        assert.equal(Boolean(molang.execute(animate)), visible, mode.id + ' animação');
        assert.ok(Math.abs(Number(molang.execute(desc.scripts.scale)) - .9375 * [1, .87, .70][age]) < 1e-8);
        molang.updateExecutionEnv({ context: { ...context, item_slot: '' },
          variable: { swbr_sarutobi_equipped: molang.execute(gate) } });
        molang.execute(desc.scripts.pre_animation[0]);
        assert.equal(Boolean(molang.execute(gate)), false, mode.id + ' desequipado');
        assert.equal(Boolean(molang.execute(animate)), false, mode.id + ' parado');
        total++;
      }
    }
  }
  report[mode.id] = { contextos: total, desequipamentos: total };
}
fs.writeFileSync(path.join(root, 'Validacao_Molang.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
