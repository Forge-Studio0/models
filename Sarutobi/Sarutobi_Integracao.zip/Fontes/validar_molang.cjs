/* Confere câmera, slot, cosméticos e empunhadura nas condições do pacote. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { Molang, Context } = require('molang');
const root = path.resolve(__dirname, '..');
const rp = path.join(root, 'Integracao', 'RP');
const read = name => JSON.parse(fs.readFileSync(name, 'utf8'));
const manifest = read(path.join(root, 'Integracao_Manifesto.json'));
const controllers = read(path.join(rp, 'render_controllers/swbr_sarutobi.json')).render_controllers;
const modes = Object.values(manifest.modos);
const ids = modes.map(mode => mode.id);
const report = { attachables: {}, cosmeticos: {} };

for (const [stage, mode] of modes.entries()) {
  const desc = read(path.join(rp, mode.attachable))['minecraft:attachable'].description;
  const parts = Object.assign({}, ...controllers[desc.render_controllers[0]].part_visibility);
  const animate = desc.scripts.animate[0].fitas;
  let total = 0;
  for (const item_slot of ['head', 'main_hand', 'off_hand', 'chest', 'legs', 'feet', '']) {
    for (const is_first_person of [0, 1]) {
      for (const age of [0, 1, 2]) {
        for (const hand of ['', 'minecraft:air', 'nz:bastao_enma', 'nz:bastao_enma3h', 'stone']) {
          for (const status of [{}, { spectator: 1 }, { invisible: 1 }]) {
            const context = {
              item_slot, is_first_person,
              owning_entity: new Context({ query: {
                property: name => name === 'nzs:body_age' ? age : 0,
                get_equipped_item_name: name => name === 'main_hand' ? hand : '',
                is_spectator: status.spectator || 0, is_invisible: status.invisible || 0,
              } }),
            };
            const molang = new Molang({ context }, { useCache: false });
            const visible = item_slot === 'head' && !is_first_person && !status.spectator && !status.invisible;
            molang.execute(desc.scripts.pre_animation.join(''));
            assert.equal(Boolean(molang.execute(parts['*'])), visible, mode.id);
            assert.equal(Boolean(molang.execute(animate)), visible, mode.id + ' animação');
            assert.equal(Boolean(molang.execute(parts.sar_bastao_de_enma)),
              visible && stage === 1 && ['', 'minecraft:air'].includes(hand), mode.id + ' bastão');
            assert.ok(Math.abs(Number(molang.execute(desc.scripts.scale)) - .9375 * [1, .87, .70][age]) < 1e-8);
            molang.updateExecutionEnv({ context: { ...context, item_slot: '' },
              variable: { swbr_sarutobi_equipped: 1, swbr_sarutobi_bastao: 1 } });
            molang.execute(desc.scripts.pre_animation.join(''));
            assert.equal(Boolean(molang.execute(parts['*'])), false, 'traje retirado');
            assert.equal(Boolean(molang.execute(parts.sar_bastao_de_enma)), false, 'bastão retirado');
            total++;
          }
        }
      }
    }
  }
  report.attachables[mode.id] = { contextos: total, desequipamentos: total };
}

for (const variant of ['original', 'cumulativa']) {
  const variantDir = path.join(root, 'Integracao', 'Versoes', variant, 'RP');
  const player = read(path.join(variantDir, 'entity/player.entity.json'))['minecraft:client_entity'].description;
  const renderer = read(path.join(variantDir, 'render_controllers/player.json')).render_controllers;
  const headState = player.scripts.pre_animation.find(line => line.startsWith('v.swbr_sarutobi_capacete ='));
  const hat = Object.assign({}, ...renderer['controller.render.player.third_person'].part_visibility).hat;
  const cosmetics = player.render_controllers.flatMap(entry => typeof entry === 'string' ? [] : Object.entries(entry))
    .filter(([, condition]) => condition.endsWith(' && !v.swbr_sarutobi_capacete'));
  assert.equal(cosmetics.length, 31);
  let total = 0;
  for (const gear of ['', ...ids, 'nz:hozuki1', 'minecraft:iron_helmet']) {
    for (const mode of [{}, { first: 1 }, { map: 1 }, { spectator: 1 }, { invisible: 1 }]) {
      const env = {
        variable: { swbr_view_first_person: mode.first || 0, swbr_view_map_face: mode.map || 0 },
        query: { property: () => 0, is_spectator: mode.spectator || 0, is_invisible: mode.invisible || 0,
          is_item_name_any: (slot, index, ...items) => Number(slot === 'slot.armor.head' && index === 0 && items.includes(gear)) },
      };
      const molang = new Molang(env, { useCache: false });
      molang.execute(headState);
      const covered = ids.includes(gear) && Object.keys(mode).length === 0;
      assert.equal(Boolean(molang.execute('v.swbr_sarutobi_capacete')), covered);
      assert.equal(Boolean(molang.execute(hat)), !covered);
      total++;
    }
  }
  report.cosmeticos[variant] = { contextos: total, controladores: cosmetics.length };
}
fs.writeFileSync(path.join(root, 'Validacao_Molang.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
