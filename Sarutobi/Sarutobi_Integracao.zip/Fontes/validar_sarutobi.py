#!/usr/bin/env python3
"""Confere a entrega, o encaixe das peças e os vínculos dos três modos."""

import argparse
import base64
from io import BytesIO
import json
from itertools import product
from math import cos, radians, sin
from pathlib import Path
from zipfile import ZipFile

import numpy as np
from PIL import Image

from aplicar_integracao import ROOT, PACK_UUIDS, RELEASE_NOTES, base_spec, checked_file, open_packs
from construir_sarutobi import (
    ENMA_TEXTURE, PLAYER, PLAYER_RENDER, RENDER, RENDER_PATH, SOURCE_RIG, STAFF_ATTACHABLES,
    VARIANTS, mask_cosmetics, mask_hat, read, staff_attachable, update_manifest, write_json,
)
from modelagem import FACES, MODES, RIG, SIZE, create_model, staff_geometry, tile_origin


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def names(archive):
    entries = archive.namelist()
    require(len(set(entries)) == len(entries), 'Arquivo com entradas ZIP duplicadas.')
    require(archive.testzip() is None, 'CRC inválido.')
    return set(entries)


def audit_pack(base, final, manifest):
    variant, spec = base_spec(base, manifest)
    family = variant.split('-', 1)[0]
    prior, output = open_packs(base), open_packs(final)
    results = {}
    with ZipFile(base) as old_archive, ZipFile(final) as new_archive:
        others = names(old_archive) - {pack[0] for pack in prior.values()} - {RELEASE_NOTES}
        require(names(new_archive) == others | {RELEASE_NOTES} | {pack[0] for pack in output.values()},
                'Arquivos externos inesperados.')
        for path in others:
            require(old_archive.read(path) == new_archive.read(path), f'Arquivo externo modificado: {path}.')
        require(new_archive.read(RELEASE_NOTES) == (ROOT / 'LEIA-ME.md').read_bytes(), 'Nota da versão divergente.')

    for kind in PACK_UUIDS:
        with ZipFile(BytesIO(prior[kind][2])) as old, ZipFile(BytesIO(output[kind][2])) as new:
            allowed = {**manifest['arquivos'][kind], **spec['packs'][kind]['arquivos']}
            original, current = names(old), names(new)
            require(current == original | allowed.keys(), f'Arquivos inesperados em {kind}.')
            require(read(new, 'manifest.json') == update_manifest(prior[kind][1], VARIANTS[family][0]),
                    'O manifesto diverge dos UUIDs ou da versão esperada.')
            for path in current:
                expected = checked_file(ROOT, allowed[path]) if path in allowed else old.read(path)
                require(new.read(path) == expected, f'Arquivo modificado fora da revisão: {kind}/{path}.')
            if kind == 'BP':
                require(set(allowed) == {'manifest.json'}, 'A revisão modificou recursos do pack de comportamento.')
                for mode in MODES:
                    item = read(new, f'items/nz_modo_sarutobi_v{mode.stage}.json')['minecraft:item']
                    require(item['description']['identifier'] == mode.item
                            and item['components']['minecraft:wearable']['slot'] == manifest['slot'],
                            f'Slot ou ID alterado para {mode.name}.')
            else:
                require(read(new, PLAYER) == mask_cosmetics(read(old, PLAYER))
                        and read(new, PLAYER_RENDER) == mask_hat(read(old, PLAYER_RENDER)),
                        'Mudanças indevidas nos cosméticos do jogador.')
                for item, path in STAFF_ATTACHABLES.items():
                    require(read(new, path) == staff_attachable(read(old, path), item),
                            f'Mudanças indevidas no vínculo de {item}.')
                audit_references(new)
            results[kind] = {'arquivos': len(current), 'preservados': len(current - allowed.keys())}
    return results


def audit_references(pack):
    entries = pack.namelist()
    rc = read(pack, RENDER_PATH)['render_controllers'][RENDER]
    require(rc['geometry'] == 'Geometry.default' and rc['materials'] == [{'*': 'Material.default'}]
            and rc['textures'] == ['Texture.default'], 'Controlador sem vínculo de textura e geometria.')
    for mode in MODES:
        binding = read(pack, mode.attachable)['minecraft:attachable']['description']
        require(binding['identifier'] == mode.item and binding['geometry'] == {'default': mode.geometry}
                and binding['animations'] == {'fitas': mode.animation} and binding['render_controllers'] == [RENDER],
                f'Vínculo incorreto em {mode.name}.')
        require(binding['textures'] == {'default': mode.texture} and mode.texture + '.png' in entries
                and binding['materials'] == {'default': 'entity_alphatest'}, f'Material ou textura inválidos em {mode.name}.')
        for prefix, identifier, key, target in (
                ('models/', mode.geometry, 'minecraft:geometry', mode.geometry_path),
                ('animations/', mode.animation, 'animations', mode.animation_path)):
            matches = []
            for path in entries:
                if not path.startswith(prefix) or not path.endswith('.json') or identifier.encode() not in pack.read(path):
                    continue
                entries_by_id = read(pack, path).get(key, [])
                if key == 'minecraft:geometry':
                    entries_by_id = [e['description']['identifier'] for e in entries_by_id]
                matches.extend(path for name in entries_by_id if name == identifier)
            require(matches == [target], f'Identificador inexistente ou duplicado: {identifier}.')
    for item, path in STAFF_ATTACHABLES.items():
        binding = read(pack, path)['minecraft:attachable']['description']
        geometry_path = f'models/entity/swbr/sarutobi/{item}.geo.json'
        require(binding['geometry']['default'] == f'geometry.swbr.sarutobi.{item}' and
                binding['textures']['default'] == ENMA_TEXTURE and ENMA_TEXTURE + '.png' in entries,
                f'Geometria ou textura do bastão ausente para {item}.')
        require(read(pack, geometry_path) == staff_geometry(item, first_person_animation=item == 'bastao_enma'),
                f'Geometria inválida para {item}.')
    primary = read(pack, STAFF_ATTACHABLES['bastao_enma'])['minecraft:attachable']['description']
    animation = primary['animations']['wield_first_person']
    require(set(primary['animations']) == {'wield_first_person'} and
            animation in read(pack, 'animations/zenkai_weapon_firstperson.animation.json')['animations'],
            'Animação em primeira pessoa do bastão ausente.')


def rotation(angles):
    x, y, z = (-radians(angles[0]), radians(angles[1]), -radians(angles[2]))
    cx, sx, cy, sy, cz, sz = cos(x), sin(x), cos(y), sin(y), cos(z), sin(z)
    return np.array(((cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx),
                     (sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx), (-sy, cy * sx, cy * cx)))


def sample(channel, t):
    if isinstance(channel, list):
        return np.array(channel, dtype=float)
    seq = sorted((float(key), np.array(val, dtype=float)) for key, val in channel.items())
    if t <= seq[0][0]:
        return seq[0][1]
    for (a, p), (b, q) in zip(seq, seq[1:]):
        if t <= b:
            return p + (q - p) * (t - a) / (b - a)
    return seq[-1][1]


def all_transforms(bones, native, time, action, pose_time):
    matrices = {}
    for bone in bones:
        name, pivot = bone['name'], np.array(bone['pivot'])
        tracks = native.get(name, {})
        at = time
        if name in action:
            tracks, at = action[name], pose_time
        scale = sample(tracks.get('scale', [1, 1, 1]), at)
        shift = sample(tracks.get('position', [0, 0, 0]), at)
        rot = rotation(sample(tracks.get('rotation', [0, 0, 0]), at)) * scale
        translation = pivot + shift - rot @ pivot
        if 'parent' in bone:
            inherited, offset = matrices[bone['parent']]
            translation = inherited @ translation + offset
            rot = inherited @ rot
        matrices[name] = rot, translation
    return matrices


def cube_frame(cube):
    origin, size = np.array(cube['origin']), np.array(cube['size'])
    pivot = np.array(cube.get('pivot', cube['origin']))
    matrix = rotation(cube.get('rotation', [0, 0, 0]))
    center = matrix @ (origin + size / 2 - pivot) + pivot
    return center, matrix, size / 2


def cube_points(cube):
    center, matrix, half = cube_frame(cube)
    return (np.array(list(product((-1, 1), repeat=3))) * half) @ matrix.T + center


def intersect(a, b):
    """Testa caixas rotacionadas nas normais das faces e nos eixos cruzados."""
    ac, am, ah = cube_frame(a)
    bc, bm, bh = cube_frame(b)
    axes = np.vstack((am.T, bm.T, np.cross(am.T[:, None, :], bm.T).reshape(-1, 3)))
    reach = np.abs(axes @ am) @ ah + np.abs(axes @ bm) @ bh
    return np.all(np.abs(axes @ (ac - bc)) <= reach + .04 * np.linalg.norm(axes, axis=1))


def audit_contact(model, native):
    groups = {}
    for name, bone in model.bones.items():
        if 'cubes' not in bone:
            continue
        host = bone['parent']
        while host not in native:
            host = model.bones[host]['parent']
        groups.setdefault(host, []).extend(bone['cubes'])
    for host, boxes in groups.items():
        host_part = 'body' if host == 'waist' else host
        attached = native[host_part]['cubes'].copy()
        pending = list(boxes)
        while pending:
            closest = [cube for cube in pending if any(intersect(cube, anchor) for anchor in attached)]
            require(bool(closest), f'Peças soltas em {model.mode.name}/{host}: {pending}.')
            attached.extend(closest)
            pending = [cube for cube in pending if cube not in closest]


def contains(cube, transform, point):
    matrix, shift = transform
    local = np.linalg.solve(matrix, point - shift)
    center, frame, size = cube_frame(cube)
    return np.all(np.abs(frame.T @ (local - center)) <= size + .04)


def audit_poses(model, pack):
    motions = read(pack, 'animations/player.json')['animations']
    sprint = read(pack, 'animations/correndo.json')['animations']['animation.player_new.correndo']
    poses = {'repouso': {'bones': {}, 'animation_length': 0}, 'caminhada': motions['animation.player_new.andando'],
             'corrida': sprint, 'salto': motions['animation.player_new.pulo'], 'combate': motions['animation.player_new.soco']}
    bones = list(model.bones.values())
    ribbons = [bone for bone in bones if bone['name'].startswith('sar_fita_')]
    result = {}
    for label, pose in poses.items():
        joints = 0
        for time in np.linspace(0, pose['animation_length'], 9):
            for phase in (0, .8, 1.6, 2.4):
                world = all_transforms(bones, model.channels, phase, pose['bones'], time)
                for bone in ribbons:
                    name, parent = bone['name'], bone['parent']
                    rotation_matrix, shift = world[name]
                    point = rotation_matrix @ np.array(bone['pivot']) + shift
                    require(contains(bone['cubes'][0], world[name], point), f'Segmento desalinhado: {name}.')
                    require(any(contains(cube, world[parent], point) for cube in model.bones[parent]['cubes']),
                            f'Fita se separa em {model.mode.name}/{name}/{label}.')
                    joints += 1
                if 'sar_bastao_de_enma' in model.bones:
                    arm, offset = world['rightArm']
                    grip = arm @ np.array((-6.06, 13.03, -.50)) + offset
                    require(contains(model.bones['sar_bastao_de_enma']['cubes'][0], world['sar_bastao_de_enma'], grip)
                            and any(contains(cube, world['sar_manga_d'], grip)
                                    for cube in model.bones['sar_manga_d']['cubes']),
                            f'Bastão fora da mão em {label}.')
        result[label] = {'poses': 9, 'fases_das_fitas': 4, 'juntas_verificadas': joints}
    return result


def audit_models(manifest, original):
    rp = ROOT / 'Integracao/RP'
    snapshot = {}
    with ZipFile(BytesIO(open_packs(original)['RP'][2])) as pack:
        native = {bone['name']: bone for bone in read(pack, SOURCE_RIG)['minecraft:geometry'][0]['bones']}
        for mode in MODES:
            model = create_model(mode)
            spec = manifest['modos'][mode.key]
            geo, animation = [(rp / spec[key]).read_bytes() for key in ('arquivo_geo', 'arquivo_anim')]
            require(json.loads(geo) == model.geometry(), f'Geometria persistida incorreta em {mode.name}.')
            require(json.loads(animation) == model.animation(), f'Animação persistida incorreta em {mode.name}.')
            for name, parent, pivot in RIG:
                bone = model.bones[name]
                require(bone.get('parent') == parent and tuple(bone['pivot']) == pivot and 'cubes' not in bone,
                        f'Vínculo da roupa com a pele alterado em {name}.')
            require(set(model.channels) == {'sar_fita_d', 'sar_fita_e'}, 'Ossos animados inválidos.')
            require(all(frames['rotation']['0.00'] == frames['rotation']['3.20'] for frames in model.channels.values()),
                    'As fitas saltam na passagem do ciclo.')
            atlas_path = rp / spec['textura']
            with Image.open(atlas_path) as image:
                require(image.mode == 'RGBA' and image.size == (SIZE, SIZE), 'Textura inválida.')
                alpha = image.getchannel('A')
                for bone in model.bones.values():
                    for cube in bone.get('cubes', []):
                        require(set(cube['uv']) == set(FACES) and min(cube['size']) > 0, 'Cubo incompleto.')
                        for face in cube['uv'].values():
                            x, y = face['uv']
                            w, h = face['uv_size']
                            require(0 <= x < x + w <= SIZE and 0 <= y < y + h <= SIZE, 'UV fora do atlas.')
                            require(alpha.crop((x, y, x + w, y + h)).getextrema() == (255, 255),
                                    'Transparência inesperada no interior de uma peça.')
            helmet = model.bones['sar_capacete']['cubes']
            front_uvs = [cube['uv']['north']['uv'] for cube in helmet]
            require(all([x + 4 for x in tile_origin(texture)] in front_uvs for texture in ('face', 'placa_konoha')),
                    'Rosto ou placa de Konoha ausente.')
            require(('sar_bastao_de_enma' in model.bones) == (mode.stage == 2), 'Bastão cosmético ligado ao item errado.')
            audit_contact(model, native)
            points = np.concatenate([cube_points(cube) for b in model.bones.values() for cube in b.get('cubes', [])])
            require(np.all(points.min(axis=0) >= [-13, -.1, -6]) and np.all(points.max(axis=0) <= [11, 36, 8]),
                    f'Peça excessivamente projetada em {mode.name}.')
            project = json.loads((ROOT / 'Modelos_Blockbench' / spec['projeto']).read_bytes())
            require(len(project['elements']) == spec['cubos'] and len(project['animations']) == 1,
                    'Projeto Blockbench incompleto.')
            require(base64.b64decode(project['textures'][0]['source'].split(',', 1)[1]) == atlas_path.read_bytes(),
                    'A textura incorporada diverge do RP.')
            snapshot[mode.key] = {'cubos': spec['cubos'], 'ossos': spec['bones'],
                                  'limites': np.round([points.min(axis=0), points.max(axis=0)], 3).tolist(),
                                  'poses': audit_poses(model, pack), 'pecas_conectadas': True}
    return snapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'Integracao_Manifesto.json').read_bytes())
    report = {'minecraft_executado': False, 'modelos': audit_models(manifest, args.original), 'packs': {}}
    for variant, base in (('original', args.original), ('cumulativa', args.cumulativa)):
        report['packs'][variant] = audit_pack(base, ROOT / VARIANTS[variant][1], manifest)
    write_json(ROOT / 'Validacao.json', report)
    print('Três modelos conectados e auditados. Packs conferidos nas duas edições.')


if __name__ == '__main__':
    main()
