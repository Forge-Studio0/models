#!/usr/bin/env python3
"""Gera o ZIP editável e reproduz as duas variantes a partir dele."""

import argparse
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from aplicar_integracao import ROOT, sha256, zip_item
from construir_sarutobi import VARIANTS


def package(original, cumulative):
    included = ['LEIA-ME.md', 'Integracao_Manifesto.json', 'Validacao.json',
                'Validacao_Molang.json', 'Validacao_Blockbench.json']
    for name in ('Fontes', 'Integracao', 'Modelos_Blockbench'):
        included.extend(sorted(path.relative_to(ROOT).as_posix() for path in (ROOT / name).rglob('*')
                               if path.is_file() and '__pycache__' not in path.parts))
    destination = ROOT / 'Sarutobi_Integracao.zip'
    with ZipFile(destination, 'w') as archive:
        for name in included:
            archive.writestr(zip_item(name), (ROOT / name).read_bytes())
    with TemporaryDirectory(prefix='sarutobi-integracao-') as folder:
        stage = Path(folder)
        with ZipFile(destination) as archive:
            if archive.testzip() is not None or archive.namelist() != included:
                raise ValueError('ZIP de integração inválido.')
            report = json.loads(archive.read('Validacao_Blockbench.json'))
            if len(report['resultados']) != 3 or not all(model['reaberto'] for model in report['resultados']):
                raise ValueError('Falta a validação de um projeto no Blockbench.')
            archive.extractall(stage)
        for variant, source in (('original', original), ('cumulativa', cumulative)):
            expected = ROOT / VARIANTS[variant][1]
            rebuilt = stage / expected.name
            subprocess.run([sys.executable, str(stage / 'Fontes/aplicar_integracao.py'), str(source), str(rebuilt)], check=True)
            if sha256(rebuilt.read_bytes()) != sha256(expected.read_bytes()):
                raise ValueError(f'O ZIP não reproduziu {expected.name}.')
    for artifact in (ROOT / VARIANTS['original'][1], ROOT / VARIANTS['cumulativa'][1], destination):
        print(artifact.name, artifact.stat().st_size, sha256(artifact.read_bytes()))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    args = parser.parse_args()
    package(args.original, args.cumulativa)
