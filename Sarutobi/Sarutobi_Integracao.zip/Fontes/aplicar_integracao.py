#!/usr/bin/env python3
"""Aplica a revisão Hōzuki a uma das bases registradas no manifesto."""

import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
PACK_UUIDS = {
    'BP': '82dafe0d-c36f-4665-9df0-371f6d8b2a55',
    'RP': 'ef513a51-2cb2-4cc5-b300-5ef44201c3f5',
}
RELEASE_NOTES = 'LEIA-ME_SARUTOBI.md'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def open_packs(addon):
    """Localiza BP e RP pelo UUID e mantém os outros packs fora do overlay."""
    matches = {}
    keys = {uuid: key for key, uuid in PACK_UUIDS.items()}
    with ZipFile(addon) as outer:
        for path in outer.namelist():
            if not path.lower().endswith('.mcpack'):
                continue
            content = outer.read(path)
            with ZipFile(io.BytesIO(content)) as pack:
                manifest = json.loads(pack.read('manifest.json'))
            key = keys.get(manifest['header']['uuid'])
            if key is not None:
                if key in matches:
                    raise ValueError(f'Pack {key} duplicado em {addon.name}.')
                matches[key] = (path, manifest, content)
    if set(matches) != set(PACK_UUIDS):
        raise ValueError(f'BP e RP do Shinobi World BR incompletos em {addon.name}.')
    return matches


def checked_file(root, entry):
    path = root / entry['arquivo']
    data = path.read_bytes()
    if sha256(data) != entry['sha256']:
        raise ValueError(f'Arquivo de integração alterado: {entry["arquivo"]}.')
    return data


def zip_item(name):
    info = ZipInfo(name, (2026, 11, 19, 0, 0, 0))
    info.compress_type = ZIP_DEFLATED
    return info


def update_pack(content, replacements):
    output = io.BytesIO()
    with ZipFile(io.BytesIO(content)) as source, ZipFile(output, 'w', ZIP_DEFLATED) as target:
        for entry in source.infolist():
            if entry.filename in replacements:
                data = replacements[entry.filename]
            else:
                data = source.read(entry)
            target.writestr(copy.copy(entry), data)
        for name in sorted(set(replacements) - set(source.namelist())):
            target.writestr(zip_item(name), replacements[name])
    return output.getvalue()


def base_spec(base, manifest):
    digest = sha256(base.read_bytes())
    for key, spec in manifest['bases'].items():
        if digest == spec['sha256']:
            return key, spec
    raise ValueError('Use uma das bases registradas no manifesto de integração.')


def apply(base, output, root=ROOT):
    base, output, root = Path(base), Path(output), Path(root)
    if base.resolve() == output.resolve():
        raise ValueError('Escolha outro arquivo de saída para preservar a addon de entrada.')
    manifest = json.loads((root / 'Integracao_Manifesto.json').read_text(encoding='utf-8'))
    _, spec = base_spec(base, manifest)
    mapping = {info['entrada']: (pack, info) for pack, info in spec['packs'].items()}
    overlay = {}
    for pack, files in manifest['arquivos'].items():
        pack_files = {**files, **spec['packs'][pack]['arquivos']}
        overlay[pack] = {name: checked_file(root, entry) for name, entry in pack_files.items()}
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent, prefix='.sarutobi-') as tmp:
        partial = Path(tmp) / output.name
        with ZipFile(base) as source, ZipFile(partial, 'w', ZIP_DEFLATED) as target:
            for entry in source.infolist():
                if entry.filename == RELEASE_NOTES:
                    continue
                data = source.read(entry)
                if entry.filename in mapping:
                    pack, info = mapping[entry.filename]
                    target.writestr(zip_item(info['saida']), update_pack(data, overlay[pack]))
                else:
                    target.writestr(copy.copy(entry), data)
            target.writestr(zip_item(RELEASE_NOTES), (root / 'LEIA-ME.md').read_bytes())
        partial.replace(output)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base', type=Path)
    parser.add_argument('saida', type=Path)
    args = parser.parse_args()
    print(apply(args.base, args.saida))
