"""Traje do Terceiro Hokage e bastão de Enma, em geometria Bedrock."""

from dataclasses import dataclass
from math import cos, pi, sin

import numpy as np
from PIL import Image, ImageDraw


SIZE = 256
TILE = 32
FACES = ('north', 'east', 'south', 'west', 'up', 'down')
RIG = (
    ('root', None, (0, 0, 0)), ('waist', 'root', (0, 12, 0)),
    ('body', 'waist', (0, 24, 0)), ('head', 'body', (0, 24, 0)),
    ('rightArm', 'body', (-5, 22, 0)), ('leftArm', 'body', (5, 22, 0)),
    ('rightLeg', 'root', (-1.9, 12, 0)), ('leftLeg', 'root', (1.9, 12, 0)),
)
ITEM_BONE = ('rightItem', 'rightArm', (-6, 15, 1))

COLORS = {
    'malha_preta': (32, 37, 45),
    'tecido': (29, 32, 40),
    'tecido_claro': (43, 47, 56),
    'gola': (22, 24, 31),
    'laca': (70, 75, 82),
    'laca_clara': (88, 93, 100),
    'laca_sombra': (52, 55, 64),
    'metal': (150, 155, 160),
    'bandagem': (124, 123, 118),
    'sandalia': (41, 48, 62),
    'sola': (25, 26, 29),
    'pele': (176, 132, 101),
    'face': (185, 141, 108),
    'placa_konoha': (156, 160, 167),
    'madeira': (36, 32, 31),
    'latão': (174, 137, 64),
    'latão_sombra': (121, 91, 47),
}
TILES = {name: index for index, name in enumerate(COLORS)}


@dataclass(frozen=True)
class Mode:
    stage: int
    key: str
    name: str
    project: str

    @property
    def item(self):
        return f'nz:modo_sarutobi_v{self.stage}'

    @property
    def attachable(self):
        return f'attachables/modo_sarutobi_v{self.stage}.json'

    @property
    def geometry(self):
        return f'geometry.swbr.sarutobi.{self.key}'

    @property
    def geometry_path(self):
        return f'models/entity/swbr/sarutobi/{self.key}.geo.json'

    @property
    def texture(self):
        return f'textures/entity/swbr/sarutobi/{self.key}'

    @property
    def animation(self):
        return f'animation.swbr.sarutobi.{self.key}.fitas'

    @property
    def animation_path(self):
        return f'animations/swbr/sarutobi/{self.key}.animation.json'


MODES = (
    Mode(1, 'earth_monkey', 'Earth Monkey', 'Sarutobi_01_Earth_Monkey.bbmodel'),
    Mode(2, 'earth_monkey_v2', 'Earth Monkey V2', 'Sarutobi_02_Earth_Monkey_V2.bbmodel'),
    Mode(3, 'cinco_elementos', '5 Elementos', 'Sarutobi_03_Cinco_Elementos.bbmodel'),
)


def tile_origin(name):
    y, x = divmod(TILES[name], SIZE // TILE)
    return x * TILE, y * TILE


def material_tile(name, color):
    yy, xx = np.mgrid[:TILE, :TILE]
    noise = np.random.default_rng(31 + TILES[name]).integers(-2, 3, (TILE, TILE))
    value = noise + (30 - yy) * .12
    if name == 'malha_preta':
        chain = ((xx + yy) % 6 == 0) | ((xx - yy) % 6 == 0)
        value += np.where(chain, 7, -3)
    elif name.startswith('laca'):
        rim = (xx == 4) | (xx == 27) | (yy == 4) | (yy == 25)
        value += np.where(rim, -7, 0) + np.where(yy == 6, 10, 0) - np.where(yy == 26, 14, 0)
    elif name in ('metal', 'latão', 'latão_sombra', 'placa_konoha'):
        value += 10 * np.sin(yy * .21 + .7)
    elif name == 'bandagem':
        value += np.where((yy + xx // 12) % 7 == 0, -12, 3)
    elif name == 'madeira':
        value += np.where(xx % 7 == 3, 8, 0)
    else:
        value += ((xx + 2 * yy) % 11 == 0) * 3
    pixels = np.clip(np.array(color) + value[..., None], 0, 255).astype(np.uint8)
    return Image.fromarray(pixels, 'RGB').convert('RGBA')


def face_tile(edo):
    tone = '#b3927a' if edo else '#caa17d'
    image = Image.new('RGBA', (TILE, TILE), tone)
    d = ImageDraw.Draw(image)
    d.polygon(((4, 14), (7, 16), (8, 22), (13, 27), (4, 27)), fill='#997560')
    d.polygon(((27, 14), (24, 16), (23, 22), (18, 27), (27, 27)), fill='#997560')
    d.line(((8, 11), (12, 10), (14, 12)), fill='#686569', width=2)
    d.line(((18, 12), (20, 10), (24, 11)), fill='#686569', width=2)
    for x in (8, 18):
        d.polygon(((x, 14), (x + 2, 13), (x + 6, 14), (x + 5, 16), (x + 1, 16)),
                  fill='#32343c' if edo else '#ddd6ca')
        d.line(((x, 14), (x + 2, 13), (x + 6, 14)), fill='#332d30', width=1)
        d.rectangle((x + 3, 14, x + 4, 15), fill='#a68c77' if edo else '#3d342e')
    d.line(((15, 15), (14, 19), (17, 20)), fill='#96765f', width=1)
    d.line(((12, 18), (10, 20), (9, 22)), fill='#a18269', width=1)
    d.line(((19, 18), (21, 20), (22, 22)), fill='#a18269', width=1)
    d.line(((12, 22), (16, 23), (20, 22)), fill='#624e46', width=1)
    d.polygon(((13, 24), (16, 23), (19, 24), (18, 28), (16, 31), (14, 28)), fill='#6d6870')
    d.line(((16, 25), (16, 29)), fill='#89838a', width=1)
    if edo:
        d.line(((6, 17), (9, 18), (7, 20), (10, 22), (8, 24)), fill='#514b4b', width=1)
        d.line(((25, 17), (22, 20), (24, 23), (21, 25)), fill='#514b4b', width=1)
        d.line(((8, 20), (6, 21), (5, 23)), fill='#665751', width=1)
    return image


def plate_tile():
    image = material_tile('placa_konoha', COLORS['placa_konoha'])
    d = ImageDraw.Draw(image)
    d.rounded_rectangle((4, 6, 27, 25), 3, outline='#666972', width=1)
    for x in (7, 24):
        for y in (10, 20):
            d.rectangle((x, y, x + 1, y + 1), fill='#535963')
    # A espiral forma o centro da folha, com a haste e a ponta nas extremidades.
    spiral = [(16 + 7 * (1 - k / 31) * cos(k * .21),
               15 + 8 * (1 - k / 31) * sin(k * .21)) for k in range(32)]
    d.line(((23, 8), (20, 10), (22, 13), *spiral), fill='#343b45', width=2)
    d.line(((11, 18), (9, 22), (15, 21)), fill='#343b45', width=2)
    return image


def atlas(stage):
    texture = Image.new('RGBA', (SIZE, SIZE))
    for name, color in COLORS.items():
        if name == 'face':
            tile = face_tile(stage == 3)
        elif name == 'placa_konoha':
            tile = plate_tile()
        else:
            tile = material_tile(name, color)
        texture.paste(tile, tile_origin(name))
    return texture


def rounded(values):
    return [round(value, 5) for value in values]


def vertical_axis(x, z):
    rx, rz = x * pi / 180, z * pi / 180
    return sin(rz) * cos(rx), cos(rz) * cos(rx), -sin(rx)


class Wearable:
    def __init__(self, mode):
        self.mode = mode
        self.bones = {}
        self.channels = {}
        for name, parent, pivot in RIG:
            self.bone(name, parent, pivot)

    def bone(self, name, parent, pivot):
        bone = {'name': name, 'pivot': list(pivot)}
        if parent:
            bone['parent'] = parent
        self.bones[name] = bone
        return name

    def box(self, group, center, size, material, rotation=None, *, front=None, top=None, bottom=None):
        cube = {'origin': rounded(c - s / 2 for c, s in zip(center, size)), 'size': list(size), 'uv': {}}
        if rotation and any(rotation):
            cube.update(pivot=list(center), rotation=rounded(rotation))
        for face in FACES:
            tile = {'north': front, 'up': top, 'down': bottom}.get(face) or material
            x, y = tile_origin(tile)
            cube['uv'][face] = {'uv': [x + 4, y + 4], 'uv_size': [24, 24]}
        self.bones[group].setdefault('cubes', []).append(cube)

    def geometry(self):
        return {'format_version': '1.16.0', 'minecraft:geometry': [{
            'description': {'identifier': self.mode.geometry, 'texture_width': SIZE, 'texture_height': SIZE,
                            'visible_bounds_width': 5, 'visible_bounds_height': 4, 'visible_bounds_offset': [0, 1, 0]},
            'bones': list(self.bones.values()),
        }]}

    def animation(self):
        return {'format_version': '1.8.0', 'animations': {self.mode.animation: {
            'loop': True, 'animation_length': 3.2, 'bones': self.channels,
        }}}


def headgear(model):
    hood = model.bone('sar_capacete', 'head', (0, 29.8, 0))
    model.box(hood, (0, 28.22, -.032), (8.24, 8.68, 8.24), 'pele', front='face')
    model.box(hood, (0, 31.54, .02), (8.70, 2.63, 8.52), 'tecido', top='tecido_claro')
    model.box(hood, (0, 32.66, .19), (7.52, .74, 7.56), 'tecido_claro', top='tecido')
    model.box(hood, (0, 28.36, 3.97), (8.26, 6.16, .88), 'gola')
    model.box(hood, (0, 30.83, -4.23), (7.80, 1.75, .46), 'tecido')
    model.box(hood, (0, 30.91, -4.53), (6.73, 1.45, .47), 'metal', front='placa_konoha')
    model.box(hood, (0, 31.0, 4.38), (2.37, .92, .88), 'gola')
    for side, name in ((-1, 'd'), (1, 'e')):
        model.box(hood, (side * 4.01, 27.74, -.04), (.87, 5.16, 8.18), 'tecido', top='tecido_claro')
        model.box(hood, (side * 3.86, 27.28, -3.95), (.76, 3.52, .72), 'gola')
        anchor = (side * .73, 31.03, 4.48)
        tie = model.bone(f'sar_fita_{name}', hood, anchor)
        rx, rz = 9 + side * 2, -side * 8
        length = 5.72 + side * .40
        center = rounded(point - direction * (length / 2 - .29)
                         for point, direction in zip(anchor, vertical_axis(rx, rz)))
        model.box(tie, center, (1.10, length, .43), 'gola', (rx, 0, rz), top='tecido_claro')
        channel = {}
        for step in range(9):
            angle = (step % 8) * pi / 4 + (.78 if side < 0 else 0)
            channel[f'{step * .4:.2f}'] = rounded((3.4 * sin(angle), 2.4 * cos(angle), side * 1.6 * sin(angle)))
        model.channels[tie] = {'rotation': channel}


def torso(model):
    vest = model.bone('sar_gibao', 'body', (0, 22, 0))
    model.box(vest, (0, 18.28, 0), (8.26, 11.72, 4.32), 'tecido', top='gola')
    model.box(vest, (0, 22.58, -.02), (6.78, 1.87, 4.62), 'tecido_claro', top='gola')
    model.box(vest, (0, 19.11, -.03), (7.78, 6.64, 4.63), 'laca_sombra', top='laca_clara')
    for index in range(3):
        y = 20.80 - index * 1.78
        width = 7.65 - index * .20
        for side in (-1, 1):
            z = side * 2.28
            model.box(vest, (0, y, z), (width, 1.78, .48), 'laca',
                      top='laca_clara', bottom='laca_sombra')
    model.box(vest, (0, 22.49, -2.14), (5.66, .83, .66), 'laca_sombra')
    belt = model.bone('sar_cinto', 'waist', (0, 12, 0))
    model.box(belt, (0, 12.41, 0), (8.46, 1.33, 4.45), 'gola')
    model.box(belt, (0, 12.50, -2.20), (1.54, .93, .47), 'laca_clara', front='metal')


def sleeves(model, side):
    arm = 'rightArm' if side < 0 else 'leftArm'
    group = model.bone('sar_manga_d' if side < 0 else 'sar_manga_e', arm, (side * 6, 20, 0))
    model.box(group, (side * 6, 18.82, 0), (4.16, 10.26, 4.16), 'tecido')
    model.box(group, (side * 6.04, 22.32, 0), (4.35, 2.81, 4.46), 'laca_sombra', top='laca')
    for band in range(2):
        model.box(group, (side * (6.41 + band * .14), 22.51 - band * 1.01, .035),
                  (3.78, 1.32, 4.60), 'laca', (0, 0, side * 8), top='laca_clara')
    model.box(group, (side * 6.01, 19.28, 0), (4.24, 2.00, 4.22), 'malha_preta')
    model.box(group, (side * 6.02, 15.68, 0), (4.31, 4.91, 4.30), 'laca_sombra')
    for band in range(3):
        model.box(group, (side * 6.06, 16.95 - band * 1.12, -.07), (4.44, .94, 4.40),
                  'laca', top='laca_clara')
    # Luva e punho próximos à empunhadura.
    model.box(group, (side * 6.02, 12.99, 0), (4.17, 2.08, 4.16), 'gola')


def legs(model, side):
    parent = 'rightLeg' if side < 0 else 'leftLeg'
    group = model.bone('sar_calca_d' if side < 0 else 'sar_calca_e', parent, (side * 2, 8, 0))
    # As pernas permanecem separadas na linha central.
    model.box(group, (side * 2.09, 6.48, 0), (4.14, 10.76, 4.16), 'tecido')
    model.box(group, (side * 2.09, 6.81, -2.09), (3.65, 3.08, .54), 'laca_sombra', top='laca')
    model.box(group, (side * 2.10, 6.62, -2.36), (3.45, 1.98, .31), 'laca', top='laca_clara')
    model.box(group, (side * 2.09, 3.27, 0), (4.17, 1.62, 4.25), 'bandagem')
    model.box(group, (side * 2.09, 1.05, -.19), (4.19, 2.13, 4.57), 'sandalia')
    model.box(group, (side * 2.09, .25, -.22), (4.22, .56, 4.62), 'sola')


def staff(model, group, grip, lower, upper, *, worn):
    """Pintura negra com ponteiras douradas. Parte do eixo passa pela mão."""
    span = upper - lower
    x, y, z = grip
    if worn:
        skew = (9, 0, -13)
        sx, sy, sz = vertical_axis(skew[0], skew[2])
    else:
        skew = None
        sx, sy, sz = (0, 0, 1)

    def section(offset, length, girth, material):
        center = (x + offset * sx, y + offset * sy, z + offset * sz)
        size = (girth, length, girth) if worn else (girth, girth, length)
        model.box(group, center, size, material, skew if worn else None)

    section((lower + upper) / 2, span, 1.06, 'madeira')
    for offset, direction in ((lower, 1), (upper, -1)):
        section(offset + .84 * direction, 2.05, 1.28, 'latão')
        section(offset + .21 * direction, .65, 1.35, 'latão_sombra')
        section(offset + 1.84 * direction, .49, 1.36, 'latão_sombra')


def staff_geometry(item, *, first_person_animation):
    """Mantém os pivôs e o eixo longitudinal usados por cada item existente."""
    model = Wearable(MODES[1])
    item_bone = model.bone(*ITEM_BONE)
    if first_person_animation:
        staff(model, 'rightArm', (-6, 12.0, 1), -23, 22, worn=False)
    else:
        staff(model, item_bone, (-6, 12.28, 1), -28, 28, worn=False)
    description = model.geometry()['minecraft:geometry'][0]['description']
    description.update(identifier=f'geometry.swbr.sarutobi.{item}', visible_bounds_width=8, visible_bounds_height=6)
    return {'format_version': '1.16.0', 'minecraft:geometry': [{
        'description': description, 'bones': list(model.bones.values()),
    }]}


def create_model(mode):
    model = Wearable(mode)
    headgear(model)
    torso(model)
    for side in (-1, 1):
        sleeves(model, side)
        legs(model, side)
    if mode.stage == 2:
        model.bone('sar_bastao_de_enma', 'rightArm', (-6, 13, -.45))
        staff(model, 'sar_bastao_de_enma', (-6.06, 13.03, -.50), -11.8, 22.1, worn=True)
    return model
