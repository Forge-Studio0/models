"""Geometrias e texturas dos três estágios Sarutobi do Shinobi World BR."""

from dataclasses import dataclass
from math import atan2, degrees, hypot, pi, sin

import numpy as np
from PIL import Image, ImageDraw


SIZE = 256
TILE = 32
FACES = ('north', 'east', 'south', 'west', 'up', 'down')
RIG = (
    ('root', None, (0, 0, 0)), ('waist', 'root', (0, 12, 0)),
    ('body', 'waist', (0, 24, 0)), ('head', 'body', (0, 24, 0)),
    ('rightArm', 'body', (-5, 22, 0)), ('leftArm', 'body', (5, 22, 0)),
    ('rightLeg', 'root', (-1.9, 12, 0)), ('leftLeg', 'root', (1.9, 12, 0)),
)

MATERIALS = {
    'rocha': ((105, 87, 67), 'stone'),
    'rocha_escura': ((82, 72, 61), 'stone'),
    'rocha_clara': ((134, 112, 87), 'stone'),
    'basalto': ((66, 74, 72), 'stone'),
    'ardosia': ((93, 103, 99), 'stone'),
    'tecido': ((48, 52, 58), 'cloth'),
    'trama': ((59, 65, 71), 'cloth'),
    'couro': ((60, 52, 48), 'cloth'),
    'carvao': ((44, 44, 39), 'cloth'),
    'linho': ((152, 140, 120), 'cloth'),
    'faixa': ((100, 51, 57), 'cloth'),
    'cobre': ((151, 119, 77), 'metal'),
    'ferro': ((91, 91, 79), 'metal'),
    'crina': ((167, 166, 151), 'fur'),
    'crina_sombra': ((128, 130, 124), 'fur'),
    'cauda': ((91, 73, 57), 'fur'),
    'cauda_ponta': ((67, 62, 56), 'fur'),
}

ELEMENTS = {
    'fogo': ((171, 79, 60), ((14, 23), (10, 17), (16, 10), (17, 15), (22, 12), (23, 19), (20, 23))),
    'vento': ((138, 181, 155), ((8, 19), (12, 15), (16, 15), (21, 12), (24, 13), (23, 17), (18, 19), (13, 20), (17, 22))),
    'raio': ((157, 150, 194), ((18, 8), (11, 18), (17, 17), (14, 24), (23, 14), (17, 15), (20, 8))),
    'terra': ((188, 151, 93), ((9, 21), (14, 13), (17, 16), (20, 11), (24, 21))),
    'agua': ((101, 169, 198), ((10, 20), (14, 15), (19, 14), (22, 17), (17, 18), (15, 21), (10, 22))),
}
TILES = {name: index for index, name in enumerate((*MATERIALS, *ELEMENTS))}


@dataclass(frozen=True)
class Mode:
    stage: int
    key: str
    name: str
    project: str

    @property
    def item(self):
        return f'nz:modo_sarutobi_v{self.stage}'

    @property
    def attachable(self):
        return f'attachables/modo_sarutobi_v{self.stage}.json'

    @property
    def geometry(self):
        return f'geometry.swbr.sarutobi.{self.key}'

    @property
    def geometry_path(self):
        return f'models/entity/swbr/sarutobi/{self.key}.geo.json'

    @property
    def texture(self):
        return f'textures/entity/swbr/sarutobi/{self.key}'

    @property
    def animation(self):
        return f'animation.swbr.sarutobi.{self.key}.cauda'

    @property
    def animation_path(self):
        return f'animations/swbr/sarutobi/{self.key}.animation.json'


MODES = (
    Mode(1, 'earth_monkey', 'Earth Monkey', 'Sarutobi_01_Earth_Monkey.bbmodel'),
    Mode(2, 'earth_monkey_v2', 'Earth Monkey V2', 'Sarutobi_02_Earth_Monkey_V2.bbmodel'),
    Mode(3, 'cinco_elementos', '5 Elementos', 'Sarutobi_03_Cinco_Elementos.bbmodel'),
)


def tile_origin(name):
    row, col = divmod(TILES[name], SIZE // TILE)
    return col * TILE, row * TILE


def painted_tile(color, kind, seed):
    yy, xx = np.mgrid[:TILE, :TILE]
    rng = np.random.default_rng(seed)
    graining = rng.integers(-5, 6, size=(TILE, TILE))
    if kind == 'stone':
        # Estratos oblíquos de pedra com granulação e pequenas fissuras escuras.
        strata = yy + .43 * xx + 1.6 * np.sin(xx * .32 + seed)
        shale = 8 * np.sin(strata * .64) + 5 * np.sin(strata * 1.28 + .6)
        texture = graining + 3 * np.floor(shale / 3) + (31 - yy) * .15
    elif kind == 'fur':
        texture = graining + 9 * np.sin(xx * 1.12 + np.floor(yy / 6)) + 6 * np.sin(yy * .47 + xx * .20)
    elif kind == 'cloth':
        texture = graining * .43 + (xx % 4 == 1) * 3 + (yy % 3 == 1) * 3 - (yy % 11 == 8) * 3
    else:
        texture = graining * .36 + 11 * np.sin(yy * .21 + .5)
    rgb = np.clip(np.array(color)[None, None, :] + texture[..., None], 0, 255).astype(np.uint8)
    return Image.fromarray(rgb, 'RGB').convert('RGBA')


def atlas(stage):
    texture = Image.new('RGBA', (SIZE, SIZE))
    for name, (color, kind) in MATERIALS.items():
        tile = painted_tile(color, kind, TILES[name] + stage * 19)
        texture.paste(tile, tile_origin(name))
    for name, (color, glyph) in ELEMENTS.items():
        tile = Image.new('RGBA', (TILE, TILE), '#302f2f')
        draw = ImageDraw.Draw(tile)
        draw.rounded_rectangle((4, 4, 27, 27), radius=4, fill='#48423c', outline='#a09076', width=2)
        if name == 'vento':
            draw.line(glyph, fill=color, width=3)
        else:
            draw.polygon(glyph, fill=color)
        texture.paste(tile, tile_origin(name))
    return texture


def rounded(values):
    return [round(value, 5) for value in values]


class Wearable:
    def __init__(self, mode):
        self.mode = mode
        self.bones = {}
        self.channels = {}
        for name, parent, pivot in RIG:
            self.bone(name, parent, pivot)

    def bone(self, name, parent, pivot):
        bone = {'name': name, 'pivot': list(pivot)}
        if parent:
            bone['parent'] = parent
        self.bones[name] = bone
        return name

    def box(self, group, center, size, material, rotation=None, *, front=None, top=None, bottom=None):
        cube = {'origin': rounded(c - s / 2 for c, s in zip(center, size)), 'size': list(size), 'uv': {}}
        if rotation and any(rotation):
            cube.update(pivot=list(center), rotation=rounded(rotation))
        for face in FACES:
            tile = {'north': front, 'up': top, 'down': bottom}.get(face) or material
            x, y = tile_origin(tile)
            cube['uv'][face] = {'uv': [x + 4, y + 4], 'uv_size': [24, 24]}
        self.bones[group].setdefault('cubes', []).append(cube)

    def geometry(self):
        return {'format_version': '1.16.0', 'minecraft:geometry': [{
            'description': {'identifier': self.mode.geometry, 'texture_width': SIZE, 'texture_height': SIZE,
                            'visible_bounds_width': 3, 'visible_bounds_height': 3, 'visible_bounds_offset': [0, 1, 0]},
            'bones': list(self.bones.values()),
        }]}

    def animation(self):
        return {'format_version': '1.8.0', 'animations': {self.mode.animation: {
            'loop': True, 'animation_length': 2.4, 'bones': self.channels,
        }}}


def forearm(model, side, stage):
    arm = 'rightArm' if side < 0 else 'leftArm'
    label = 'd' if side < 0 else 'e'
    lower = model.bone('sar_punho_' + label, arm, (side * 6, 15, 0))
    rock = 'basalto' if stage == 3 else 'rocha'
    edge = 'ardosia' if stage == 3 else 'rocha_clara'
    dark = 'ferro' if stage == 3 else 'rocha_escura'
    cuff = 'couro' if stage > 1 else 'linho'
    weight = stage - 1

    model.box(lower, (side * 6, 15.23, 0), (4.27, 5.48, 4.25), cuff)
    model.box(lower, (side * 6, 12.90, -.01), (4.39, .67, 4.40), 'ferro' if stage > 1 else 'couro')
    model.box(lower, (side * 6.54, 15.95, -2.23), (2.62 + .16 * weight, 5.55 + .38 * weight, 1.23 + .11 * weight),
              rock, (6, -side * 9, side * 10), top=edge, bottom=dark)
    model.box(lower, (side * 7.97, 16.73, -.09), (1.42 + .23 * weight, 5.65 + .36 * weight, 3.44),
              dark, (-7, side * 9, side * 9), top=edge)
    model.box(lower, (side * 6.33, 17.55 + .13 * weight, 2.17), (2.48, 4.85, 1.20),
              rock, (-8, side * 12, -side * 8), top=edge, bottom=dark)
    model.box(lower, (side * 6.77, 14.57, -2.69 - .05 * weight), (1.98 + .12 * weight, 2.20, .69),
              edge, (4, -side * 11, -side * 14))
    model.box(lower, (side * 8.04, 14.11, 1.01), (1.54 + .10 * weight, 2.08, 1.72),
              rock, (14, side * 10, side * 12), top=edge, bottom=dark)
    if stage > 1:
        model.box(lower, (side * 6.25, 18.87, 0), (4.53 + .09 * weight, 1.29, 4.50),
                  'ferro', (-3, 0, side * 5), top='cobre' if stage == 3 else 'rocha_clara')
        model.box(lower, (side * 7.29, 18.39, -2.32), (1.70, 2.86, 1.03), edge, (-8, -side * 11, side * 17))

    shoulder = model.bone('sar_ombro_' + label, arm, (side * 5.55, 22, 0))
    if stage == 1:
        model.box(shoulder, (side * 6.20, 22.52, .04), (4.26, 1.65, 4.31), 'couro', (0, 0, side * 5))
        model.box(shoulder, (side * 7.34, 22.61, -.17), (2.53, 1.91, 3.69), rock, (6, side * 8, side * 13), top=edge)
    else:
        model.box(shoulder, (side * 6.42, 22.13, .06), (4.37, 3.42, 4.38), 'tecido')
        model.box(shoulder, (side * 6.85, 23.15 if stage == 3 else 23.02, .14), (3.78, 2.18, 4.52),
                  rock, (0, side * 8, side * 16), top=edge)
        model.box(shoulder, (side * 7.64, 21.65, -.47), (2.68 + .14 * weight, 2.48, 3.12),
                  dark, (-5, -side * 8, side * 22), top=edge, bottom='basalto')
        model.box(shoulder, (side * 6.98, 22.74, -2.12), (2.72, 1.18, 1.01),
                  'cobre' if stage == 3 else 'rocha_clara', (3, 0, side * 18))


def torso(model, stage):
    belt = model.bone('sar_cinto', 'waist', (0, 12.45, 0))
    model.box(belt, (0, 12.40, .01), (8.36, 1.14, 4.37), 'faixa' if stage == 3 else 'couro')
    model.box(belt, (0, 12.53, -2.23), (1.57, 1.19, .37), 'ferro', front='cobre')
    # A base da cauda atravessa o cinto e sobrepõe o primeiro segmento.
    model.box(belt, (0, 12.30, 2.32), (2.10, 1.37, 1.02), 'couro', top='ferro')
    if stage == 1:
        return

    vest = model.bone('sar_colete', 'body', (0, 21.2, 0))
    model.box(vest, (.02, 18.58, -.01), (8.28, 10.47, 4.34), 'tecido', top='trama')
    model.box(vest, (0, 19.64, 2.32), (6.70, 6.0, .57), 'trama', top='ferro')
    if stage == 2:
        for side in (-1, 1):
            model.box(vest, (side * 1.94, 20.48, -2.20), (2.88, 4.65, .66), 'rocha_escura', (0, 0, side * 7),
                      top='rocha_clara')
            model.box(vest, (side * 2.29, 22.43, -2.63), (.82, 2.95, .34), 'linho', (0, -side * 5, side * 19))
            model.box(vest, (side * 2.38, 15.26, -2.20), (2.01, 1.93, .53), 'couro', (6, 0, side * 8))
        model.box(vest, (0, 16.65, -2.40), (5.37, 1.34, .75), 'trama', front='ferro')
    else:
        model.box(vest, (0, 21.39, -2.24), (6.98, 3.30, .84), 'basalto', top='ardosia')
        for side in (-1, 1):
            model.box(vest, (side * 2.97, 22.41, -2.60), (.78, 3.24, .41), 'faixa', (0, 0, side * 21))
            model.box(vest, (side * 2.15, 15.65, -2.27), (3.05, 2.83, .62), 'basalto', (-7, 0, side * 11), top='ardosia')
        crest = model.bone('sar_cinco_elementos', vest, (0, 18.46, -2.36))
        model.box(crest, (0, 18.46, -2.37), (6.62, 1.78, .80), 'ferro')
        for index, token in enumerate(ELEMENTS):
            model.box(crest, ((index - 2) * 1.24, 18.46, -2.77), (1.16, 1.24, .34),
                      'basalto', front=token, top='cobre')

    collar = model.bone('sar_gola', 'body', (0, 23.45, 1.65))
    model.box(collar, (0, 23.27, 1.90), (6.42, 1.59, 1.55), 'crina_sombra' if stage == 2 else 'tecido')
    for side in (-1, 1):
        for index in range(3):
            x = side * (1.24 + 1.05 * index)
            y = 23.96 - index * .35
            z = 2.32 - index * .23
            model.box(collar, (x, y, z), (1.54, 1.67 if stage == 2 else 1.36, 1.19),
                      'crina' if index < 2 else 'crina_sombra', (-16, side * 14, side * (13 + 8 * index)))
        if stage == 2:
            model.box(collar, (side * 3.64, 24.16, 1.98), (1.73, 1.81, 1.52),
                      'crina', (-14, side * 17, side * 21), bottom='crina_sombra')


def shin(model, side, stage):
    leg = 'rightLeg' if side < 0 else 'leftLeg'
    label = 'd' if side < 0 else 'e'
    group = model.bone('sar_perna_' + label, leg, (side * 2, 8, 0))
    z = -2.17
    if stage == 2:
        model.box(group, (side * 2.05, 3.82, 0), (4.10, 2.86, 4.14), 'couro')
        model.box(group, (side * 2.17, 5.40, z), (2.88, 3.41, .83), 'rocha_escura', (-5, 0, side * 8), top='rocha')
    else:
        model.box(group, (side * 2.075, 6.55, .015), (4.12, 10.38, 4.11), 'tecido')
        model.box(group, (side * 2.42, 9.37, z), (2.91, 2.98, .73), 'basalto',
                  (3, side * 8, -side * 9), top='ardosia')
        for index in range(3):
            model.box(group, (side * (2.10 + index * .12), 7.02 - index * 1.84, z), (3.37 - index * .19, 2.25, .95),
                      'basalto', (-8, side * 6, side * (6 - index)), top='ardosia')
        model.box(group, (side * 2.15, 2.39, z - .14), (2.74, 1.19, .55), 'ferro', top='cobre')


def tail(model, stage):
    parent = 'sar_cinto'
    start = (0, 12.27, 2.44)
    lengths = (
        ((.35, 1.60), (.41, 1.43), (.47, 1.10)),
        ((.24, 1.86), (.42, 1.69), (.64, 1.35)),
        ((.28, 1.53), (.43, 1.45), (.56, 1.05)),
    )[stage - 1]
    for index, (rise, reach) in enumerate(lengths):
        end = (0, round(start[1] + rise, 4), round(start[2] + reach, 4))
        bone = model.bone(f'sar_cauda_{index + 1}', parent, start)
        width = (1.29, 1.04, .75)[index] + (.08 if stage == 2 else 0)
        model.box(bone, rounded((a + b) / 2 for a, b in zip(start, end)),
                  (width, round(hypot(rise, reach) + .39, 5), width * .92),
                  'cauda_ponta' if index == 2 else 'cauda', (-degrees(atan2(reach, rise)), 0, 0))
        amplitude = (5.8, 7.4, 8.1)[index] * (.83 if stage == 1 else 1.0)
        motion = {}
        for frame in range(9):
            phase = (frame % 8) * pi / 4 - index * .39
            motion[f'{frame * .3:.2f}'] = rounded((sin(phase + .7) * 2.1, sin(phase) * amplitude, 0))
        model.channels[bone] = {'rotation': motion}
        parent, start = bone, end


def create_model(mode):
    model = Wearable(mode)
    torso(model, mode.stage)
    for side in (-1, 1):
        forearm(model, side, mode.stage)
        if mode.stage > 1:
            shin(model, side, mode.stage)
    tail(model, mode.stage)
    return model
