/* Simula equipamento, câmera e troca de modo nas condições reais dos JSONs. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { Molang, Context } = require('molang');

const root = path.resolve(__dirname, '..');
const rp = path.join(root, 'Integracao', 'RP');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const modes = Object.values(read(path.join(root, 'Integracao_Manifesto.json')).modos);
const ids = modes.map(mode => mode.id);
const renderer = read(path.join(rp, 'render_controllers/swbr_chinoike.json')).render_controllers['controller.render.swbr.chinoike'];
const report = { attachables: {}, jogadores: {} };

for (const mode of modes) {
  for (const file of mode.attachables) {
    const desc = read(path.join(rp, file))['minecraft:attachable'].description;
    let count = 0;
    for (const item_slot of ['head', 'chest', 'legs', 'feet', 'main_hand', 'off_hand', '']) {
      for (const is_first_person of [0, 1]) {
        for (const age of [0, 1, 2]) {
          for (const [is_spectator, is_invisible] of [[0, 0], [1, 0], [0, 1]]) {
            const makeContext = slot => ({ item_slot: slot, is_first_person,
              owning_entity: new Context({ query: {
                property: key => key === 'nzs:body_age' ? age : 0, is_spectator, is_invisible,
              } }),
            });
            const runtime = new Molang({ context: makeContext(item_slot) }, { useCache: false });
            const truth = expression => Boolean(runtime.execute(expression));
            const gate = desc.scripts.pre_animation[0];
            const active = Object.values(desc.scripts.animate[0])[0];
            const expected = item_slot === 'head' && !is_first_person && !is_spectator && !is_invisible;
            runtime.execute(gate);
            assert.equal(truth(renderer.part_visibility[0]['*']), expected, desc.identifier);
            assert.equal(truth(active), expected, `${desc.identifier} animação`);
            assert.ok(Math.abs(runtime.execute(desc.scripts.scale) - .9375 * [1, .87, .70][age]) < 1e-8);
            runtime.updateExecutionEnv({ context: makeContext(''), variable: { swbr_chinoike_equipado: 1 } });
            runtime.execute(gate);
            assert.equal(truth(renderer.part_visibility[0]['*']), false);
            assert.equal(truth(active), false);
            count++;
          }
        }
      }
    }
    report.attachables[desc.identifier] = { contextos: count, retiradas: count };
  }
}

for (const family of ['original', 'cumulativa']) {
  const player = read(path.join(root, 'Integracao', 'Edicoes', family, 'RP/entity/player.entity.json'))['minecraft:client_entity'].description;
  const gates = player.scripts.pre_animation.filter(statement => /^v\.swbr_chinoike_(ocular|particulas) =/.test(statement)).join('');
  const triggers = Object.assign({}, ...player.scripts.animate.filter(track => typeof track !== 'string'));
  const eyeFilters = player.render_controllers.flatMap(layer => typeof layer === 'string' ? [] : Object.entries(layer))
    .filter(([, condition]) => condition.endsWith(' && !v.swbr_chinoike_ocular'));
  assert.equal(eyeFilters.length, 3);
  const gear = ['', ...ids, 'nz:sharingan3', 'nz:modo_admin_ketsuryugan_chomei', 'nz:modo_hatake_lobo_branco'];
  let count = 0;
  for (const current of gear) {
    for (const situation of [{}, { first: 1 }, { map: 1 }, { ui: 1 }, { invisible: 1 }, { spectator: 1 }]) {
      let equipped = current;
      const context = {
        variable: { swbr_view_first_person: situation.first || 0, swbr_view_map_face: situation.map || 0 },
        query: { is_in_ui: situation.ui || 0, is_invisible: situation.invisible || 0, is_spectator: situation.spectator || 0,
          is_item_name_any: (slot, index, ...items) => Number(slot === 'slot.armor.head' && index === 0 && items.includes(equipped)) },
      };
      const runtime = new Molang(context, { useCache: false });
      const truth = expression => Boolean(runtime.execute(expression));
      const eyesVisible = !situation.first && !situation.map && !situation.spectator && !situation.invisible;
      for (const next of [current, ...gear.filter(item => item !== current)]) {
        equipped = next;
        runtime.execute(gates);
        assert.equal(truth('v.swbr_chinoike_ocular'), eyesVisible && ids.includes(equipped));
        for (const stage of modes) {
          const key = 'chinoike_gotas_' + stage.chave;
          assert.equal(truth(triggers[key]), Boolean(eyesVisible && !situation.ui && stage.id === equipped), `${current}→${next}`);
        }
        count++;
      }
    }
  }
  report.jogadores[family] = { contextos_e_trocas: count, animacoes_testadas: modes.length, sobreposicoes_oculares: eyeFilters.length };
}

fs.writeFileSync(path.join(root, 'Validacao_Molang.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
