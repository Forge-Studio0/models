"""Texturas RGBA do Ketsuryūgan, do sangue denso e das bordas líquidas."""

from math import cos, sin

from PIL import Image, ImageDraw, ImageOps


SIZE, TILE = 256, 32
COLORS = {
    'vinho': ((49, 9, 24), (115, 20, 40), (178, 52, 66)),
    'denso': ((69, 10, 26), (147, 25, 51), (212, 70, 83)),
    'carmesim': ((87, 13, 31), (168, 31, 54), (223, 83, 97)),
    'borda': ((101, 21, 36), (181, 45, 66), (232, 107, 113)),
    'sombra': ((33, 7, 17), (93, 15, 32), (145, 41, 58)),
    'focinho': ((65, 13, 28), (148, 27, 50), (213, 65, 82)),
    'claro': ((95, 20, 36), (183, 47, 64), (234, 108, 111)),
}
TILES = {key: index for index, key in enumerate((*COLORS, 'superficie', 'gota', 'olho_d', 'olho_e',
                                                 'reflexo', 'dragao_olho', 'mandibula', 'vazio'))}


def interpolate(a, b, portion):
    return tuple(round(x + (y - x) * portion) for x, y in zip(a, b))


def blood(name, seed):
    dark, middle, light = COLORS[name]
    image = Image.new('RGBA', (TILE, TILE))
    pixels = []
    for y in range(TILE):
        for x in range(TILE):
            u, v = (x - 15.5) / 15.5, (y - 15.5) / 15.5
            wave = sin((v * 3.4) + seed * .61) * .16 + cos(v * 8.3 - seed) * .045
            wet = abs(u - wave)
            stratification = .22 * sin((u * 4.1 - v * 2.90 + seed * .39))
            sheen = max(0., 1 - abs(wet - .56) / .23) ** 4
            speck = ((x * 17 + y * 11 + x * y) % 11 - 5) * .004
            base = max(0., min(1., (1 - wet * .70) * .90 + stratification + speck))
            value = interpolate(dark, middle, base)
            value = interpolate(value, light, sheen * (.46 + .24 * sin(v * 4.9 + seed) ** 2))
            # O recorte suaviza os cantos. Os centros das junções continuam sólidos.
            a = 0 if abs(u) ** 5 + abs(v) ** 6 > 1.62 else 255
            pixels.append((*value, a))
    image.putdata(pixels)
    if name == 'focinho':
        d = ImageDraw.Draw(image)
        d.line(((4, 19), (10, 21), (18, 20), (27, 17)), fill=(105, 25, 45, 255), width=2)
        d.line(((5, 11), (12, 9), (24, 8)), fill=(205, 75, 88, 255), width=2)
    return image


def fluid_edge(seed):
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    tip = 12 + seed % 8
    d.polygon(((tip, 1), (tip + 2, 7), (22, 13), (24, 19), (29, 25), (28, 30), (6, 30),
               (4, 24), (9, 17), (10, 11)), fill=(150, 32, 52, 134))
    d.polygon(((tip, 2), (tip + 1, 8), (19, 13), (20, 18), (24, 24), (25, 29), (10, 29),
               (8, 24), (12, 17), (12, 10)), fill=(210, 66, 81, 170))
    d.line(((tip, 4), (tip, 10), (15, 16), (16, 21), (20, 26), (20, 29)), fill=(242, 118, 126, 193), width=2)
    d.line(((6, 27), (9, 21), (9, 18)), fill=(185, 52, 75, 155))
    d.point((26, 19), fill=(219, 106, 114, 154))
    return image


def droplet():
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    d.polygon(((15, 1), (17, 6), (20, 13), (26, 20), (26, 25), (22, 30), (9, 30), (5, 25),
               (6, 21), (10, 15)), fill=(139, 23, 45, 194))
    d.polygon(((15, 3), (18, 10), (21, 18), (24, 22), (23, 26), (19, 28), (11, 28), (8, 25),
               (9, 20), (12, 15)), fill=(203, 51, 74, 223))
    d.line(((13, 14), (10, 22), (11, 25)), fill=(238, 130, 136, 219), width=2)
    d.line(((20, 23), (19, 27), (14, 28)), fill=(90, 17, 34, 226), width=2)
    return image


def eye(mirror):
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    d.polygon(((1, 14), (5, 9), (12, 6), (24, 9), (30, 14), (28, 22), (22, 25),
               (9, 24), (3, 20)), fill='#2d0918')
    d.polygon(((3, 14), (7, 11), (12, 8), (23, 10), (28, 14), (26, 20), (21, 23),
               (9, 22), (5, 19)), fill='#991b38')
    d.polygon(((6, 15), (12, 10), (21, 11), (25, 14), (24, 19), (20, 22), (10, 20)), fill='#c83651')
    d.polygon(((7, 15), (12, 14), (21, 15), (25, 15), (23, 18), (14, 18), (9, 17)), fill='#3a0b22')
    d.line(((8, 12), (12, 10), (17, 11)), fill='#f0737d', width=2)
    d.line(((17, 20), (21, 20), (23, 19)), fill='#e35364')
    return ImageOps.mirror(image) if mirror else image


def detail(name):
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    if name == 'reflexo':
        d.polygon(((5, 13), (12, 10), (18, 10), (19, 13), (13, 14), (7, 16)), fill=(239, 113, 126, 172))
        d.line(((8, 13), (12, 11), (16, 11)), fill=(244, 152, 154, 199))
    elif name == 'dragao_olho':
        d.polygon(((3, 19), (8, 10), (17, 7), (29, 13), (25, 20), (14, 25)), fill='#5a1027')
        d.polygon(((7, 17), (13, 11), (24, 13), (19, 20), (11, 20)), fill='#e26972')
        d.line(((17, 12), (15, 17), (13, 20)), fill='#4d1127', width=2)
    elif name == 'mandibula':
        d.polygon(((2, 12), (10, 7), (22, 8), (30, 13), (27, 19), (19, 24), (8, 22), (4, 19)), fill='#300b1e')
        d.line(((5, 14), (12, 16), (20, 15), (26, 12)), fill='#9e294c', width=2)
    return image


def atlas(mode):
    image = Image.new('RGBA', (SIZE, SIZE))
    for name, index in TILES.items():
        if name in COLORS:
            patch = blood(name, mode.stage)
        elif name == 'superficie':
            patch = fluid_edge(mode.stage)
        elif name == 'gota':
            patch = droplet()
        elif name.startswith('olho_'):
            patch = eye(name.endswith('_e'))
        else:
            patch = detail(name)
        row, column = divmod(index, SIZE // TILE)
        image.paste(patch, (column * TILE, row * TILE))
    return image
