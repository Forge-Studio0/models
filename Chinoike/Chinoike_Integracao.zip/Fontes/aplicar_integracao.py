"""Aplica os cinco modelos Chinoike aos packs Shinobi World BR registrados."""

import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
VERSION = [18, 11, 82]
VERSION_TEXT = '.'.join(map(str, VERSION))
PACK_UUIDS = {'BP': '82dafe0d-c36f-4665-9df0-371f6d8b2a55', 'RP': 'ef513a51-2cb2-4cc5-b300-5ef44201c3f5'}
NOTES = 'LEIA-ME_CHINOIKE.md'
PLAYER = 'entity/player.entity.json'
PLAYER_MODELS = ('models/entity/swbr39/custom.geo.json', 'models/entity/swbr39/custom_b.geo.json')
LOCATORS = {
    'head': {'temporal_d': [-3.95, 28.40, -2.16], 'temporal_e': [3.95, 28.40, -2.16]},
    'body': {'dorso': [0, 21.50, 3.23], 'dorso_d': [-2.48, 22.35, 3.20]},
    'rightArm': {'mao_d': [-6.28, 13.10, -2.68]}, 'leftArm': {'mao_e': [6.28, 13.10, -2.68]},
    'rightLeg': {'pe_d': [-2.49, 1.39, -2.36]}, 'leftLeg': {'pe_e': [2.49, 1.39, -2.36]},
}
DRAW = 'v.swbr_chinoike_particulas'
EYE_DRAW = 'v.swbr_chinoike_ocular'
COSMETIC_EYES = {'controller.render.nzs_olho_dourado', 'controller.render.nzs_olho_azul',
                 'controller.render.nzs_olho_mangekyou_flor'}
FX = {'miuda': 'swbr:chinoike_gota_miuda', 'densa': 'swbr:chinoike_gota_densa'}


def locator(name):
    return 'swbr_chinoike_' + name


def manifest_bytes(document):
    return (json.dumps(document, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def zip_item(name):
    info = ZipInfo(name, (2026, 11, 23, 0, 0, 0))
    info.compress_type = ZIP_DEFLATED
    return info


def open_packs(addon):
    """Lê os packs principais pelos UUIDs e deixa os demais membros intactos."""
    packs = {}
    keys = {uuid: kind for kind, uuid in PACK_UUIDS.items()}
    with ZipFile(addon) as outer:
        for entry in outer.namelist():
            if not entry.endswith('.mcpack'):
                continue
            content = outer.read(entry)
            with ZipFile(io.BytesIO(content)) as archive:
                manifest = json.loads(archive.read('manifest.json'))
            kind = keys.get(manifest['header']['uuid'])
            if kind:
                if kind in packs:
                    raise ValueError(f'Pack {kind} duplicado em {addon.name}.')
                packs[kind] = (entry, manifest, content)
    if set(packs) != set(PACK_UUIDS):
        raise ValueError(f'BP e RP principais ausentes em {addon.name}.')
    return packs


def item_query(ids):
    return "q.is_item_name_any('slot.armor.head', 0, " + ', '.join(f"'{name}'" for name in ids) + ')'


def patch_player(document, modes):
    desc = document['minecraft:client_entity']['description']
    scripts = desc['scripts']
    selected = item_query([mode['id'] for mode in modes])
    scripts['pre_animation'].extend([
        f'{EYE_DRAW} = (!(v.swbr_view_first_person ?? 0.0) && !(v.swbr_view_map_face ?? 0.0)'
        f' && !q.is_spectator && !q.is_invisible && {selected}) ? 1.0 : 0.0;',
        f'{DRAW} = ({EYE_DRAW} && !q.is_in_ui) ? 1.0 : 0.0;',
    ])
    for layer in desc['render_controllers']:
        if isinstance(layer, dict):
            for name in COSMETIC_EYES.intersection(layer):
                layer[name] = f'({layer[name]}) && !{EYE_DRAW}'
    desc.setdefault('particle_effects', {}).update({f'chinoike_{key}': name for key, name in FX.items()})
    for mode in modes:
        key = f'chinoike_gotas_{mode["chave"]}'
        desc['animations'][key] = f'animation.swbr.chinoike.{mode["chave"]}.gotas'
        scripts['animate'].append({key: f'{DRAW} && {item_query([mode["id"]])}'})
    return document


def patch_locators(document):
    bones = {bone['name']: bone for bone in document['minecraft:geometry'][0]['bones']}
    for bone, points in LOCATORS.items():
        bones[bone].setdefault('locators', {}).update({locator(name): point for name, point in points.items()})
    return document


def upgrade_manifest(manifest, base_label):
    manifest = copy.deepcopy(manifest)
    manifest['header'].update(name=f'Shinobi World BR {VERSION_TEXT} · Chinoike', version=VERSION,
                              description=f'Shinobi World BR {VERSION_TEXT} | Cinco modos Chinoike | Base {base_label}')
    for module in manifest['modules']:
        module['version'] = VERSION
    for dependency in manifest.get('dependencies', []):
        if dependency.get('uuid') in PACK_UUIDS.values():
            dependency['version'] = VERSION
    return manifest


def changed_assets(kind, source, manifest, overlay):
    changed = dict(overlay)
    if kind == 'RP':
        changed[PLAYER] = manifest_bytes(patch_player(json.loads(source.read(PLAYER)), list(manifest['modos'].values())))
        for path in PLAYER_MODELS:
            changed[path] = manifest_bytes(patch_locators(json.loads(source.read(path))))
    return changed


def update_pack(content, manifest, overlay, kind, base_label):
    output = io.BytesIO()
    with ZipFile(io.BytesIO(content)) as source, ZipFile(output, 'w', ZIP_DEFLATED) as target:
        selected = changed_assets(kind, source, manifest, overlay)
        selected['manifest.json'] = manifest_bytes(upgrade_manifest(json.loads(source.read('manifest.json')), base_label))
        for entry in source.infolist():
            data = selected[entry.filename] if entry.filename in selected else source.read(entry)
            target.writestr(copy.copy(entry), data)
        for path in sorted(selected.keys() - set(source.namelist())):
            target.writestr(zip_item(path), selected[path])
    return output.getvalue()


def read_overlay(root, manifest):
    overlay = {}
    for path, entry in manifest['recursos'].items():
        data = (root / 'Integracao' / 'RP' / path).read_bytes()
        if sha256(data) != entry:
            raise ValueError(f'Recurso alterado ou corrompido: {path}.')
        overlay[path] = data
    return overlay


def apply(base, output, root=ROOT):
    base, output = Path(base), Path(output)
    if base.resolve() == output.resolve():
        raise ValueError('Use um caminho de saída diferente da base.')
    manifest = json.loads((root / 'Integracao_Manifesto.json').read_bytes())
    spec = manifest['bases'].get(sha256(base.read_bytes()))
    if spec is None:
        raise ValueError('O arquivo de entrada não corresponde a uma base registrada.')
    packs = open_packs(base)
    paths = {pack[0]: kind for kind, pack in packs.items()}
    overlay = read_overlay(root, manifest)
    output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix='.chinoike-', dir=output.parent) as scratch:
        partial = Path(scratch) / output.name
        with ZipFile(base) as source, ZipFile(partial, 'w', ZIP_DEFLATED) as target:
            for entry in source.infolist():
                kind = paths.get(entry.filename)
                if kind:
                    payload = update_pack(packs[kind][2], manifest, overlay if kind == 'RP' else {}, kind, spec['base'])
                    target.writestr(zip_item(f'SWBR_{kind}_v{VERSION_TEXT}_CHINOIKE.mcpack'), payload)
                else:
                    target.writestr(copy.copy(entry), source.read(entry))
            target.writestr(zip_item(NOTES), (root / 'LEIA-ME.md').read_bytes())
        partial.replace(output)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base', type=Path)
    parser.add_argument('saida', type=Path)
    args = parser.parse_args()
    print(apply(args.base, args.saida))
