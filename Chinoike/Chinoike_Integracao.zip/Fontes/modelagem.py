"""Geometrias Chinoike em escala humana e curvas animadas de sangue."""

from dataclasses import dataclass
from math import asin, atan2, cos, degrees, dist, pi, radians, sin

from texturas import SIZE, TILE, TILES


RIG = (
    ('root', None, (0, 0, 0)), ('waist', 'root', (0, 12, 0)),
    ('body', 'waist', (0, 24, 0)), ('head', 'body', (0, 24, 0)),
    ('rightArm', 'body', (-5, 22, 0)), ('leftArm', 'body', (5, 22, 0)),
    ('rightLeg', 'root', (-1.9, 12, 0)), ('leftLeg', 'root', (1.9, 12, 0)),
)
SIDES = ((-1, 'd', 'rightArm', 'rightLeg'), (1, 'e', 'leftArm', 'leftLeg'))
FACES = ('north', 'east', 'south', 'west', 'up', 'down')


@dataclass(frozen=True)
class Mode:
    stage: int
    key: str
    name: str
    level: int
    suffix: str
    length: float

    @property
    def item(self):
        return 'nz:ketsuryugan' + self.suffix

    @property
    def base_filename(self):
        return 'nz_ketsuryugan' + self.suffix

    @property
    def paths(self):
        main = f'attachables/{self.base_filename}.json'
        return (main, 'attachables/nz_ketsuryugan.player.json') if self.stage == 1 else (main,)

    @property
    def geometry_path(self):
        ext = '.json' if self.stage == 2 else '.geo.json'
        return f'models/entity/{self.base_filename}{ext}'

    @property
    def geometry(self):
        return 'geometry.' + self.base_filename

    @property
    def texture(self):
        return 'textures/entity/swbr/chinoike/' + self.key

    @property
    def slots(self):
        return ('idle', 'andando', 'agachando') if self.stage == 5 else ('idle',)

    def animation(self, slot):
        if self.stage in (3, 4):
            return 'animation.' + self.base_filename + '.idle'
        return f'animation.swbr.chinoike.{self.key}.{slot}'

    def animation_path(self, slot):
        if self.stage in (3, 4):
            return f'animations/{self.base_filename}.idle.json'
        return f'animations/swbr/chinoike/{self.key}.{slot}.animation.json'

    @property
    def project(self):
        return f'Chinoike_{self.stage:02d}_{self.key}.bbmodel'


MODES = (
    Mode(1, 'ketsuryugan', 'Ketsuryūgan', 12, '', 4.8),
    Mode(2, 'oito_dragoes', '8-Dragões', 20, '_8dragoes', 4.8),
    Mode(3, 'imbuido_half', 'Imbuído Half', 40, '_halfblood', 4.0),
    Mode(4, 'imbuido_full', 'Imbuído Full', 55, '_fullblood', 4.4),
    Mode(5, 'lua_de_sangue', 'Lua de Sangue', 65, '_bloodmoon', 5.2),
)


def clean(values):
    return [round(v, 5) + 0.0 for v in values]


def mirrored(side, points):
    return [(side * x, y, z) for x, y, z in points]


class Model:
    def __init__(self, mode):
        self.mode = mode
        self.bones, self.tracks = {}, {}
        for name, parent, pivot in RIG:
            self.bone(name, parent, pivot)

    def bone(self, name, parent, pivot):
        bone = {'name': name, 'pivot': clean(pivot)}
        if parent:
            bone['parent'] = parent
        self.bones[name] = bone
        return name

    def box(self, bone, center, size, ink, rotation=None, **faces):
        cube = {'origin': clean(c - s / 2 for c, s in zip(center, size)), 'size': clean(size), 'uv': {}}
        if rotation and any(rotation):
            cube.update(pivot=clean(center), rotation=clean(rotation))
        for face in FACES:
            row, column = divmod(TILES[faces.get(face, ink)], SIZE // TILE)
            cube['uv'][face] = {'uv': [column * TILE + 1, row * TILE + 1], 'uv_size': [TILE - 2, TILE - 2]}
        self.bones[bone].setdefault('cubes', []).append(cube)

    def card(self, bone, center, size, ink, rotation=None):
        self.box(bone, center, size, 'vazio', rotation, north=ink, south=ink)

    def strand(self, bone, start, stop, size, ink='carmesim', *, edge=False, join=.18):
        length = dist(start, stop)
        dx, dy, dz = (b - a for a, b in zip(start, stop))
        rx, rz = -degrees(asin(dz / length)), degrees(atan2(dx, dy))
        center = tuple((a + b) / 2 for a, b in zip(start, stop))
        dimensions = size[0], length + join, size[1]
        if edge:
            self.card(bone, center, dimensions, ink, (rx, 0, rz))
        else:
            self.box(bone, center, dimensions, ink, (rx, 0, rz))

    def ribbon(self, bone, points, sizes, inks=('vinho', 'denso', 'carmesim', 'borda')):
        assert len(points) == len(sizes) + 1
        for i, (a, b) in enumerate(zip(points, points[1:])):
            self.strand(bone, a, b, sizes[i], inks[min(i, len(inks) - 1)])

    def edge(self, name, parent, start, stop, width):
        bone = self.bone('ch_borda_' + name, parent, start)
        self.strand(bone, start, stop, (width, .11), 'superficie', edge=True, join=.07)
        return bone

    def wave(self, bone, axis, phase, *, swelling=False):
        length = self.mode.length
        frames = {'rotation': {}}
        if swelling:
            frames['scale'] = {}
        for i in range(5):
            t = str(round(i * length / 4, 2))
            wave = sin(2 * pi * (i / 4 + phase))
            frames['rotation'][t] = clean(amount * wave for amount in axis)
            if swelling:
                frames['scale'][t] = clean(1 + wave * delta for delta in (.018, .022, .019))
        self.tracks[bone] = frames

    def drop(self, name, parent, origin, fraction):
        bone = self.bone('ch_borda_gota_' + name, parent, origin)
        self.card(bone, origin, (.33, .53, .11), 'gota')
        self.card(bone, origin, (.29, .49, .10), 'gota', (0, 90, 0))
        end = self.mode.length
        start = round(end * fraction, 2)
        a, b, c, d = (str(round(start + step, 2)) for step in (0, .08, .26, .34))
        self.tracks[bone] = {
            'scale': {'0.0': [0, 0, 0], a: [0, 0, 0], b: [1, 1, 1], c: [.58, .58, .58], d: [0, 0, 0], str(end): [0, 0, 0]},
            'position': {'0.0': [0, 0, 0], a: [0, 0, 0], b: [0, -.10, .03], c: [.07, -.61, .18],
                         d: [.09, -.82, .24], str(end): [0, 0, 0]},
        }

    def geometry(self):
        return {'format_version': '1.16.0', 'minecraft:geometry': [{
            'description': {'identifier': self.mode.geometry, 'texture_width': SIZE, 'texture_height': SIZE,
                            'visible_bounds_width': 4, 'visible_bounds_height': 4,
                            'visible_bounds_offset': [0, 1, 0]},
            'bones': list(self.bones.values()),
        }]}

    def animation(self, slot):
        tracks, length, loop = self.tracks, self.mode.length, True
        if slot == 'andando':
            length = 3.25
            tracks = {bone: {kind: {str(round(float(t) * .625, 2)): value for t, value in keys.items()}
                             for kind, keys in channels.items()} for bone, channels in tracks.items()}
        if slot == 'agachando':
            length, loop = .75, 'hold_on_last_frame'
            tracks = {
                'ch_anel': {'position': {'0.0': [0, 0, 0], '0.75': [0, -.27, .19]},
                            'rotation': {'0.0': [0, 0, 0], '0.75': [-3, 0, -4]}},
                'ch_punho_d': {'rotation': {'0.0': [0, 0, 0], '0.75': [0, 0, 5]}},
                'ch_punho_e': {'rotation': {'0.0': [0, 0, 0], '0.75': [0, 0, -5]}},
            }
            for bone in self.bones:
                if bone.startswith('ch_borda_gota_'):
                    tracks[bone] = {'scale': {'0.0': [0, 0, 0], '0.75': [0, 0, 0]}}
        return {'format_version': '1.8.0', 'animations': {self.mode.animation(slot): {
            'loop': loop, 'animation_length': length, 'bones': tracks,
        }}}


def eyes(model):
    bone = model.bone('ch_olhos', 'head', (0, 27.67, -4.088))
    for side, label, _, _ in SIDES:
        center = (side * 1.94, 27.70, -4.098)
        model.box(bone, center, (2.76, 1.79, .045), 'vazio', north=f'olho_{label}')
    # O brilho é fino. A pupila principal permanece na mesma posição durante o ciclo.
    iris = model.bone('ch_borda_reflexos', bone, (0, 27.78, -4.138))
    for side, _, _, _ in SIDES:
        model.box(iris, (side * 1.96, 27.78, -4.138), (1.98, 1.11, .018), 'vazio', north='reflexo')
    length = model.mode.length
    model.tracks[iris] = {'scale': {'0.0': [.98, .95, 1], str(round(length / 2, 2)): [1, 1.06, 1],
                                    str(length): [.98, .95, 1]}}


def pool(model, bone, center, sizes):
    x, y, z = center
    w, h, d = sizes
    model.box(bone, center, sizes, 'vinho', (0, 7, -10), north='denso', south='carmesim')
    model.box(bone, (x + .16, y + h * .14, z + d * .20), (w * .76, h * .77, d * .80),
              'denso', (10, -12, 16), south='claro')


def sinews(model, name, parent, points, widths, phase, stroke=4.0):
    joint = parent
    for i, (start, stop) in enumerate(zip(points, points[1:])):
        joint = model.bone(f'ch_{name}_{i + 1}', joint, start)
        width, depth = widths[i]
        model.strand(joint, start, stop, (width, depth), ('vinho', 'denso', 'carmesim', 'borda')[min(i, 3)], join=.29)
        model.wave(joint, (stroke * .59, stroke * .30, stroke), phase + i * .12)
    return joint


def dragon_head(model, label, parent, root, yaw, detail_scale, phase):
    bone = model.bone('ch_dragao_cabeca_' + label, parent, root)
    angle = radians(yaw)

    def where(x, y, z):
        return (root[0] + (x * cos(angle) + z * sin(angle)) * detail_scale,
                root[1] + y * detail_scale,
                root[2] + (-x * sin(angle) + z * cos(angle)) * detail_scale)

    def form(local, dimensions, ink, pitch=0, roll=0, **face_inks):
        model.box(bone, where(*local), tuple(v * detail_scale for v in dimensions), ink, (pitch, yaw, roll), **face_inks)

    form((0, .15, .07), (1.71, 1.04, 1.26), 'denso', roll=3, north='carmesim')
    form((0, .10, -.68), (1.38, .66, 1.12), 'focinho', pitch=9, up='borda')
    form((0, .05, -1.19), (1.03, .47, .47), 'carmesim', pitch=11, north='claro')
    form((0, -.42, -.62), (1.20, .34, 1.14), 'vinho', pitch=-4, up='sombra')
    form((0, -.48, -1.06), (.91, .27, .43), 'denso', pitch=-6)
    for side in (-1, 1):
        form((side * .59, .42, -.38), (.61, .36, .77), 'borda', pitch=-9, roll=side * -18)
        form((side * .61, .17, -.76), (.37, .36, .12), 'vazio', north='dragao_olho')
        flank = 'east' if side > 0 else 'west'
        form((side * .64, .03, -.60), (.07, .62, .98), 'vazio', **{flank: 'mandibula'})
        model.strand(bone, where(side * .59, .50, .19), where(side * .70, .92, .83), (.34, .33), 'carmesim')
    crest = model.edge('crista_' + label, bone, where(.09, .64, .08), where(-.15, 1.10, .96), .50)
    model.wave(crest, (3, 4, 2), phase)
    model.wave(bone, (3.6, 5.1, 3.0), phase + .16)
    model.drop('dragao_' + label, bone, where(.13, -.67, -1.12), .10 + phase * .67)


def dragons(model):
    base = model.bone('ch_massa_dragao', 'body', (0, 21.69, 2.17))
    pool(model, base, (0, 21.62, 2.40), (5.76, 5.37, 1.92))
    model.ribbon(base, [(-1.34, 21.49, 2.45), (1.06, 20.26, 2.81), (2.27, 21.39, 3.00)],
                 [(1.88, .94), (1.34, .71)], ('denso', 'carmesim'))
    lines = (
        ((1.34, 23.07, 2.55), (2.20, 25.56, 3.30), (3.59, 28.55, 4.20), (5.09, 30.99, 5.35), (5.79, 33.31, 5.02)),
        ((1.65, 22.71, 2.85), (3.60, 24.25, 4.12), (6.01, 26.63, 5.73), (7.26, 28.78, 6.37), (7.71, 30.68, 5.72)),
        ((1.63, 21.32, 2.88), (4.01, 21.91, 4.37), (6.53, 23.21, 5.57), (8.09, 24.77, 6.48), (8.29, 26.78, 5.63)),
        ((1.48, 19.95, 2.76), (3.68, 19.85, 3.65), (6.07, 20.23, 4.18), (8.17, 21.16, 4.91), (9.09, 23.11, 4.59)),
    )
    for side, label, _, _ in SIDES:
        for i, line in enumerate(lines):
            tag = f'dragao_{label}{i + 1}'
            phase = .13 + i * .14 + (.20 if side > 0 else 0.)
            points = [(side * (x + side * .08 * j), y + side * .095 * j, z + side * .075 * j)
                      for j, (x, y, z) in enumerate(line)]
            neck = sinews(model, tag, base, points, [(1.48, 1.30), (1.23, 1.07), (.94, .91), (.75, .79)], phase, 2.2 + .15 * i)
            dragon_head(model, f'{label}{i + 1}', neck, points[-1], -side * (22, 34, 29, 40)[i], 1.06 - i * .045, phase)


def temple_streams(model, moon):
    for side, label, _, _ in SIDES:
        points = mirrored(side, ((3.84, 29.29, -1.25), (4.04, 28.62, -.48), (4.11, 27.56, .55),
                                 (4.13, 26.72, 1.85 if moon else 1.18)))
        model.ribbon('head', points, [(.58, .54), (.57, .52), (.37, .36)], ('denso', 'carmesim', 'borda'))
        edge = model.edge('temporal_' + label, 'head', points[-2], (side * 4.03, 25.96, 2.23), .48)
        model.wave(edge, (3, 0, 2), .6 + side * .16)


def half_torso(model):
    lines = (
        [(-3.59, 22.07, -1.99), (-2.91, 20.84, -2.38), (-2.04, 19.89, -2.46), (-.70, 19.19, -2.12)],
        [(-3.55, 19.33, -1.96), (-2.76, 18.36, -2.27), (-1.60, 17.69, -2.36), (-.98, 16.99, -2.01)],
        [(-3.51, 16.91, -1.99), (-2.83, 16.20, -2.18), (-2.11, 15.72, -2.19)],
    )
    for i, path in enumerate(lines):
        model.ribbon('body', path, [(1.02 - .23 * j, .46 - .05 * j) for j in range(len(path) - 1)])
        end = path[-1]
        model.edge(f'torso_half_{i}', 'body', path[-2], (end[0] + .26, end[1] - .41, end[2] - .10), .53)
    base = model.bone('ch_massa_half', 'body', (-2.53, 22.08, 2.16))
    pool(model, base, (-2.52, 22.4, 2.13), (2.60, 2.92, 1.53))
    for i, path in enumerate((
            [(-2.77, 23.56, 2.37), (-3.88, 23.02, 3.20), (-3.34, 21.77, 3.69), (-1.96, 20.13, 2.10)],
            [(-1.78, 23.19, 2.31), (-1.14, 23.75, 2.87), (-.76, 22.56, 3.16), (-1.45, 21.64, 2.14)])):
        model.ribbon(base, path, [(.73, .66), (.60, .56), (.45, .43)])
        edge = model.edge(f'massa_half_{i}', base, path[1], path[2], .61)
        model.wave(edge, (4, 1.5, 4), .21 + .34 * i)
    model.wave(base, (2.8, 2.1, 2.), .3, swelling=True)


def body_channels(model, moon):
    includes = (
        ((3.42, 22.93, -1.92), (2.69, 21.84, -2.40), (1.50, 20.83, -2.56), (.19, 20.00, -2.31)),
        ((3.73, 20.31, -.95), (3.51, 18.80, -1.96), (2.89, 17.56, -2.42), (1.45, 16.73, -2.29), (.53, 15.66, -2.01)),
        ((3.20, 17.28, 1.78), (3.72, 15.85, .89), (3.54, 14.65, -.64), (2.70, 13.66, -1.97)),
        ((3.27, 22.64, 1.83), (2.62, 21.18, 2.45), (1.20, 19.94, 2.60), (.35, 18.52, 2.13)),
        ((3.16, 18.11, 1.83), (2.46, 16.88, 2.38), (1.41, 15.58, 2.51), (.34, 15.21, 2.05)),
    )
    for side, label, _, _ in SIDES:
        for i, raw in enumerate(includes):
            if i == 0 and side > 0:
                raw = ((3.42, 23.10, -1.89), (2.63, 22.54, -2.38), (1.94, 21.55, -2.50),
                       (1.06, 20.82, -2.48), (-.21, 20.26, -2.16))
            if i == 1 and side < 0:
                raw = ((3.73, 20.31, -.95), (3.47, 18.98, -1.98), (2.87, 17.65, -2.47),
                       (1.86, 16.49, -2.55), (1.93, 14.99, -2.07) if moon else (.84, 16.10, -2.13))
            path = [(side * x, y + side * (.22 if i % 2 == 0 else -.27), z) for x, y, z in raw]
            widths = [(max(.47, (1.93 if moon else 1.52) - .25 * j - .12 * (i % 3)), .86 - .11 * j)
                      for j in range(len(path) - 1)]
            model.ribbon('body', path, widths)
            tip = path[-1]
            if i in (0, 1, 3):
                effect = model.edge(f'canal_{label}{i}', 'body', path[-2],
                                    (tip[0] - side * .30, tip[1] - .38, tip[2] - .16 if i < 2 else tip[2] + .18),
                                    .74 if moon else .69)
                model.wave(effect, (2.6, 1.8, 3.5), .22 * i + side * .12)
        model.ribbon('body', mirrored(side, ((3.65, 22.9, -.37), (3.53, 22.52, .84), (3.22, 22.07, 2.20))),
                     [(1.33, .75), (1.38, .84)], ('carmesim', 'denso'))
    if moon:
        crossing = [(3.13, 21.93, -1.97), (2.24, 20.50, -2.52), (.88, 19.22, -2.71),
                    (-.67, 18.24, -2.66), (-1.73, 17.15, -2.39), (-2.18, 16.03, -2.09)]
        model.ribbon('body', crossing, [(1.21, .71), (1.44, .74), (1.32, .72), (1.07, .59), (.71, .45)],
                     ('vinho', 'denso', 'carmesim', 'denso', 'borda'))
        model.edge('lua_peito', 'body', crossing[-2], (-2.44, 15.76, -2.37), .73)


def arms(model, half=False, moon=False):
    for side, label, arm, _ in SIDES:
        if half and side > 0:
            points = [(6.22, 15.09, -1.91), (6.88, 14.12, -2.22), (6.06, 13.11, -2.31), (5.78, 12.57, -1.97)]
            model.ribbon(arm, points, [(.49, .37), (.52, .44), (.31, .36)])
            model.edge('pulso_half_e', arm, points[-2], (5.77, 12.19, -2.29), .37)
            continue
        flow = model.bone('ch_antebraco_' + label, arm, (side * 6.07, 16.20, -.99))
        forearm_paths = (
            ((5.48, 18.20, -1.76), (6.68, 17.20, -2.29), (7.30, 15.90, -2.42), (6.43, 14.30, -2.58), (5.61, 12.84, -2.30)),
            ((7.60, 17.59, -.18), (8.08, 16.16, -.97), (8.0, 14.65, .28), (7.50, 13.13, 1.08)),
            ((5.13, 15.66, -1.84), (5.28, 14.90, -2.34), (6.03, 13.99, -2.56), (6.93, 13.16, -2.17)),
        )
        margin = .28 if moon else .07 if half else .19
        for i, path in enumerate(forearm_paths):
            widths = [(max(.55, 1.74 - .27 * j - .28 * i) + margin, .77 - j * .10)
                      for j in range(len(path) - 1)]
            model.ribbon(flow, mirrored(side, path), widths, ('vinho', 'denso', 'carmesim', 'borda'))
        model.wave(flow, (2.7, 2.0, 1.8), .29 + side * .06, swelling=True)
        mix = [((6.84, 14.89, -2.35), (6.42, 13.58, -2.96)),
               ((7.48, 14.89, .19), (7.83, 13.08, .99)), ((5.80, 13.91, -2.56), (5.45, 12.49, -2.69))]
        for i, (start, stop) in enumerate(mix):
            a, b = mirrored(side, (start, stop))
            edge = model.edge(f'ponta_pulso_{label}{i}', flow, a, b, .79 if i == 0 else .53)
            model.wave(edge, (4.7, 2.8, 3.2), .23 + i * .17 + side * .12)
        model.drop('mao_' + label, flow, (side * 6.19, 12.16, -2.77), .44 + side * .13)
        if half:
            continue
        continuous = ((6.26, 23.64, -1.73), (5.60, 22.28, -2.15), (5.55, 20.63, -2.30),
                      (6.46, 19.25, -2.27), (6.83, 17.53, -1.99))
        model.ribbon(arm, mirrored(side, continuous), [(1.46, .71), (1.60, .58), (1.49, .61), (1.34, .70)])
        model.ribbon(arm, mirrored(side, ((7.41, 23.36, 1.54), (7.67, 21.93, 1.80), (7.80, 20.45, 1.20),
                                           (7.52, 19.33, .10))), [(1.16, .63), (.97, .59), (.61, .56)])
        if moon:
            pivot = (side * 6.29, 13.62, -2.34)
            curl = model.bone('ch_punho_' + label, flow, pivot)
            sweep = mirrored(side, ((6.29, 13.62, -2.34), (5.80, 12.43, -2.87), (6.24, 11.25, -3.43),
                                     (7.14, 11.67, -3.27), (7.61, 12.74, -2.64)))
            model.ribbon(curl, sweep, [(.99, .61), (.86, .59), (.69, .47), (.47, .37)])
            model.edge('retorno_' + label, curl, sweep[2], (side * 7.47, 12.34, -3.53), .69)
            model.wave(curl, (4.9, 3.5, 4.3), .35 + side * .19)


def legs(model, moon):
    for side, label, _, leg in SIDES:
        upper = mirrored(side, ((3.32, 11.38, -.32), (3.80, 9.83, -1.29), (3.16, 8.23, -2.25), (2.52, 7.12, -2.36)))
        lower = mirrored(side, ((3.57, 7.59, 1.19), (3.70, 6.03, .41), (3.37, 4.76, -1.11),
                                (2.78, 3.36, -2.20), (2.30, 1.22, -2.21)))
        model.ribbon(leg, upper, [(1.04, .69), (1.19, .75), (1.05, .59)])
        model.ribbon(leg, lower, [(1.18, .66), (1.07, .64), (.91, .58), (.59, .47)])
        edge = model.edge('tornozelo_' + label, leg, lower[-2], (side * 2.05, .97, -2.43), .59)
        model.wave(edge, (3, 2, 2.7), .26 + side * .13)
        model.drop('perna_' + label, leg, (side * 2.48, 1.55, -2.60), .65 + side * .08)
        if moon:
            pivot = (side * 2.72, 6.77, -1.93)
            knot = model.bone('ch_joelho_' + label, leg, pivot)
            model.ribbon(knot, mirrored(side, ((3.77, 7.56, -.55), (3.18, 7.27, -1.93), (2.24, 6.63, -2.59),
                                              (1.28, 5.71, -1.94))), [(1.34, .82), (1.53, .79), (.84, .69)])
            model.wave(knot, (2.6, 1.6, 2.1), .48 + side * .12, swelling=True)


def full_back(model):
    base = model.bone('ch_massa_full', 'body', (0, 22.15, 2.01))
    pool(model, base, (.13, 21.6, 2.26), (5.21, 3.76, 1.77))
    model.wave(base, (1.45, 1.3, 1.6), .27, swelling=True)
    for side, label, _, _ in SIDES:
        for i, points in enumerate((
                ((1.09, 22.48, 2.52), (2.07, 24.05, 3.05), (3.17, 25.18, 3.92), (3.61, 24.44, 4.39)),
                ((1.53, 21.47, 2.53), (3.25, 21.62, 3.54), (4.23, 22.67, 4.34), (4.58, 23.69, 4.21)))):
            path = mirrored(side, points)
            curve = f'vertice_{label}{i + 1}'
            tip = sinews(model, curve, base, path, [(1.41, 1.06), (1.06, .80), (.65, .54)], .34 + .27 * i + side * .12, 3.5)
            a = path[-2]
            b = (path[-1][0] + side * .12, path[-1][1] + .17, path[-1][2] + .20)
            model.edge(curve, tip, a, b, .84)


def moon_ring(model):
    pool(model, 'body', (0, 20.21, 2.35), (4.87, 3.75, 1.84))
    model.ribbon('body', [(-2.91, 21.32, 2.29), (-1.63, 20.32, 3.11), (0., 19.80, 3.86), (1.06, 20.12, 4.46)],
                 [(1.34, .91), (1.51, 1.18), (1.27, 1.02)])
    center = (0, 25.43, 4.75)
    ring = model.bone('ch_anel', 'body', center)
    degrees_list = [29, 49, 71, 94, 116, 136, 154, 171, 190, 213, 237, 257, 276, 293, 310, 327]
    widths = [(.53, .49), (.85, .56), (1.19, .89), (1.59, 1.11), (1.08, .87), (.88, .78), (1.49, 1.06),
              (1.35, .96), (1.30, .97), (1.58, 1.15), (1.04, .76), (1.51, 1.07), (1.21, .94), (.91, .75), (.48, .50)]
    trail = []
    for i, degree in enumerate(degrees_list):
        a = radians(degree)
        x = (6.76 + sin(3 * a) * .32) * cos(a)
        y = center[1] + (6.11 + sin(2 * a) * .32) * sin(a)
        z = center[2] + .42 * sin(2 * a) + .18 * cos(i * 1.9)
        trail.append((x, y, z))
    model.ribbon(ring, trail, widths, ('borda', 'carmesim', 'denso', 'vinho', 'denso', 'carmesim', 'vinho',
                                      'denso', 'carmesim', 'denso', 'vinho', 'denso', 'carmesim', 'vinho', 'borda'))
    model.wave(ring, (1.9, 2.0, 4.1), .12, swelling=True)
    for i in (0, 3, 6, 8, 11, 14):
        a, b = trail[i], trail[i + 1]
        dx, dy = b[0] - a[0], b[1] - a[1]
        point = ((a[0] + b[0]) * .5 - dy * .27, (a[1] + b[1]) * .5 + dx * .28, b[2] + .15)
        model.strand(ring, a, point, (.84, .64), 'carmesim')
        edge = model.edge(f'anel_{i:02}', ring, point, (point[0] - dy * .15, point[1] + dx * .19, point[2] + .16), .85)
        model.wave(edge, (3.4, 4.8, 3.1), i * .087)
    for i, point in enumerate((trail[1], trail[6], trail[12], trail[-1])):
        model.drop(f'anel_{i}', ring, (point[0] * 1.06, point[1] - .27, point[2] + .26), .18 + i * .16)


def create_model(mode):
    model = Model(mode)
    eyes(model)
    if mode.stage == 2:
        dragons(model)
    elif mode.stage == 3:
        half_torso(model)
        arms(model, half=True)
    elif mode.stage >= 4:
        moon = mode.stage == 5
        temple_streams(model, moon)
        body_channels(model, moon)
        arms(model, moon=moon)
        legs(model, moon)
        if moon:
            moon_ring(model)
        else:
            full_back(model)
    return model
