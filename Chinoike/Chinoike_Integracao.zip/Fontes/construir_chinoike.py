"""Gera as cinco geometrias, o atlas de cada modo e os recursos da integração."""

import argparse
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

from aplicar_integracao import FX, ROOT, VERSION, apply, locator, manifest_bytes, open_packs, sha256
from modelagem import MODES, RIG, create_model
from texturas import SIZE, TILE, atlas, droplet


CATALOG = {'original': ('Chinoike.mcaddon', '18.11.81 derivada de 18.11.64 com Hōzuki'),
           'cumulativa': ('Chinoike_Cumulativo.mcaddon', '18.11.81 cumulativa')}
LEGACY_HASH = 'c3ef05c2446e2fb8dd359aa7de98761b8623189c94804cb66c2bdd8c79aa21a2'
SLOT = 'slot.armor.head'
ORIGINAL_RIG = 'models/entity/swbr39/custom.geo.json'
VISIBLE = 'v.swbr_chinoike_equipado'
DRAW_GATE = ("context.item_slot == 'head' && !(context.is_first_person ?? 0.0)"
             ' && !(context.owning_entity -> q.is_spectator) && !(context.owning_entity -> q.is_invisible)')
AGE = "(context.owning_entity -> q.property('nzs:body_age'))"
SCALE = f'0.9375 * ({AGE} == 1 ? 0.87 : ({AGE} == 2 ? 0.70 : 1.0))'
RENDER = 'controller.render.swbr.chinoike'
RENDER_PATH = 'render_controllers/swbr_chinoike.json'
PARTICLES_ANIM = 'animations/swbr/chinoike/gotas.animation.json'
PARTICLE_TEXTURE = 'textures/particle/swbr_chinoike_gota'
ADMIN = 'attachables/nz_modo_admin_ketsuryugan_chomei.json'
MOTION_CONTROLLER = 'controller.animation.base_attachable'
MOTION_CONTROLLER_PATH = 'animation_controllers/base_attachable.json'
EMISSIONS = {
    'ketsuryugan': (5.80, [(1.07, 'temporal_d', 'miuda'), (3.88, 'temporal_e', 'miuda')]),
    'oito_dragoes': (4.80, [(1.82, 'dorso', 'miuda'), (4.02, 'dorso', 'densa')]),
    'imbuido_half': (4.00, [(1.30, 'mao_d', 'densa'), (1.61, 'dorso_d', 'miuda'), (3.22, 'mao_e', 'miuda')]),
    'imbuido_full': (4.40, [(0.75, 'mao_d', 'densa'), (1.07, 'dorso', 'miuda'), (2.23, 'pe_e', 'miuda'),
                           (2.68, 'mao_e', 'densa'), (3.17, 'pe_d', 'miuda'), (3.73, 'dorso', 'miuda')]),
    'lua_de_sangue': (5.20, [(0.61, 'dorso', 'densa'), (1.12, 'mao_e', 'miuda'), (2.03, 'pe_d', 'miuda'),
                            (2.84, 'mao_d', 'densa'), (3.32, 'dorso', 'densa'), (4.19, 'pe_e', 'miuda')]),
}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(manifest_bytes(value))


def attachable(mode, specific_player=False):
    animations = {'idle': mode.animation('idle')}
    active = 'idle'
    if mode.stage == 5:
        animations = {'cont': MOTION_CONTROLLER, 'parado': mode.animation('idle'),
                      'andando': mode.animation('andando'), 'agachando': mode.animation('agachando')}
        active = 'cont'
    definition = {
        'identifier': mode.item + ('.player' if specific_player else ''),
        'materials': {'default': 'entity_alphatest', 'borda': 'entity_alphablend'},
        'textures': {'default': mode.texture}, 'geometry': {'default': mode.geometry}, 'animations': animations,
        'scripts': {'parent_setup': 'variable.helmet_layer_visible = 0.0;',
                    'pre_animation': [f'{VISIBLE} = ({DRAW_GATE}) ? 1.0 : 0.0;'],
                    'scale': SCALE, 'animate': [{active: VISIBLE}]},
        'render_controllers': [RENDER],
    }
    if specific_player:
        definition['item'] = {mode.item: "query.owner_identifier == 'minecraft:player'"}
    return {'format_version': '1.10.0', 'minecraft:attachable': {'description': definition}}


def particle(variant):
    small = variant == 'miuda'
    return {'format_version': '1.10.0', 'particle_effect': {
        'description': {'identifier': FX[variant], 'basic_render_parameters': {
            'material': 'particles_blend', 'texture': PARTICLE_TEXTURE}},
        'components': {
            'minecraft:emitter_local_space': {'position': True, 'rotation': True, 'velocity': False},
            'minecraft:emitter_rate_instant': {'num_particles': 1 if small else 2},
            'minecraft:emitter_lifetime_once': {'active_time': .13},
            'minecraft:emitter_shape_sphere': {'radius': .037 if small else .057, 'direction': 'outwards'},
            'minecraft:particle_initial_speed': .065 if small else .122,
            'minecraft:particle_motion_dynamic': {'linear_acceleration': [0, -.66, 0], 'linear_drag_coefficient': 1.6},
            'minecraft:particle_lifetime_expression': {'max_lifetime': .24 if small else .36},
            'minecraft:particle_initial_spin': {'rotation': 'math.random(-28, 28)', 'rotation_rate': 'math.random(-40, 40)'},
            'minecraft:particle_appearance_billboard': {
                'size': [.016, .023] if small else [.021, .029], 'facing_camera_mode': 'lookat_xyz',
                'uv': {'texture_width': TILE, 'texture_height': TILE, 'uv': [0, 0], 'uv_size': [TILE, TILE]},
            },
            'minecraft:particle_appearance_tinting': {'color': [1, 1, 1,
                'math.clamp(1 - v.particle_age / math.max(v.particle_lifetime, 0.001), 0, 1)']},
        },
    }}


def particle_animations():
    result = {}
    for mode in MODES:
        length, schedule = EMISSIONS[mode.key]
        events = {str(time): {'effect': f'chinoike_{density}', 'locator': locator(origin)}
                  for time, origin, density in schedule}
        result[f'animation.swbr.chinoike.{mode.key}.gotas'] = {
            'loop': True, 'animation_length': length, 'particle_effects': events,
        }
    return {'format_version': '1.8.0', 'animations': result}


def source_check(source):
    packs = open_packs(source)
    if any(value[1]['header']['version'] != [18, 11, 81] for value in packs.values()):
        raise ValueError('Use as edições Hatake 18.11.81 para reproduzir os pacotes publicados.')
    with ZipFile(BytesIO(packs['BP'][2])) as bp, ZipFile(BytesIO(packs['RP'][2])) as rp:
        native = {bone['name']: bone for bone in json.loads(rp.read(ORIGINAL_RIG))['minecraft:geometry'][0]['bones']}
        for name, parent, pivot in RIG:
            if native[name].get('parent') != parent or tuple(native[name]['pivot']) != pivot:
                raise ValueError(f'Pivô original alterado em {name}.')
        assert bp.testzip() is None and rp.testzip() is None
        for mode in MODES:
            item = json.loads(bp.read(f'items/{mode.base_filename}.json'))['minecraft:item']
            assert item['description']['identifier'] == mode.item and item['components']['minecraft:wearable']['slot'] == SLOT
            for path in mode.paths:
                old = json.loads(rp.read(path))['minecraft:attachable']['description']
                assert old['geometry']['default'] == mode.geometry
                assert old['identifier'] == mode.item + ('.player' if path.endswith('.player.json') else '')
            bases = json.loads(rp.read(mode.geometry_path))['minecraft:geometry']
            assert [entry['description']['identifier'] for entry in bases] == [mode.geometry]


def generate(original, cumulative):
    rp = ROOT / 'Integracao' / 'RP'
    bases = {LEGACY_HASH: {'arquivo': 'SWBR_v18.11.64_GUI_VILA_CORRIGIDA.mcaddon', 'base': '18.11.64 original'}}
    for family, source in (('original', original), ('cumulativa', cumulative)):
        source_check(source)
        bases[sha256(source.read_bytes())] = {'arquivo': source.name, 'base': CATALOG[family][1]}
    manifest = {'cla': 'Chinoike', 'versao': VERSION, 'bases': bases, 'slot': SLOT, 'modos': {}, 'recursos': {}}
    for mode in MODES:
        model = create_model(mode)
        write_json(rp / mode.geometry_path, model.geometry())
        for slot in mode.slots:
            write_json(rp / mode.animation_path(slot), model.animation(slot))
        for path in mode.paths:
            write_json(rp / path, attachable(mode, path.endswith('.player.json')))
        texture = rp / (mode.texture + '.png')
        texture.parent.mkdir(parents=True, exist_ok=True)
        atlas(mode).save(texture, optimize=True)
        manifest['modos'][mode.key] = {
            'chave': mode.key, 'id': mode.item, 'nome': mode.name, 'nivel': mode.level, 'projeto': mode.project,
            'attachables': list(mode.paths), 'arquivo_geo': mode.geometry_path, 'geometria': mode.geometry,
            'arquivos_anim': [mode.animation_path(slot) for slot in mode.slots], 'textura': mode.texture + '.png',
            'cubos': sum(len(bone.get('cubes', [])) for bone in model.bones.values()),
            'bones': len(model.bones), 'atlas': SIZE,
        }

    write_json(rp / PARTICLES_ANIM, particle_animations())
    for variant in FX:
        write_json(rp / f'particles/swbr_chinoike_gota_{variant}.json', particle(variant))
    texture = rp / (PARTICLE_TEXTURE + '.png')
    texture.parent.mkdir(parents=True, exist_ok=True)
    droplet().save(texture, optimize=True)
    write_json(rp / RENDER_PATH, {'format_version': '1.8.0', 'render_controllers': {RENDER: {
        'geometry': 'Geometry.default', 'textures': ['Texture.default'],
        'materials': [{'*': 'Material.default'}, {'ch_borda_*': 'Material.borda'}],
        'part_visibility': [{'*': VISIBLE}],
    }}})
    manifest['recursos'] = {path.relative_to(rp).as_posix(): sha256(path.read_bytes())
                            for path in sorted(rp.rglob('*')) if path.is_file()}
    write_json(ROOT / 'Integracao_Manifesto.json', manifest)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    parser.add_argument('--somente-recursos', action='store_true')
    args = parser.parse_args()
    generate(args.original, args.cumulativa)
    if not args.somente_recursos:
        for variant, base in (('original', args.original), ('cumulativa', args.cumulativa)):
            print(apply(base, ROOT / CATALOG[variant][0]))
