"""Confere a pele exposta, as curvas animadas, os vínculos e o conteúdo dos packs."""

import argparse
from base64 import b64decode
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import ZipFile

import numpy as np
from PIL import Image

from aplicar_integracao import (COSMETIC_EYES, EYE_DRAW, FX, LOCATORS, NOTES, PLAYER, PLAYER_MODELS, ROOT, VERSION,
                                 changed_assets, locator, open_packs, read_overlay, sha256, upgrade_manifest)
from construir_chinoike import (ADMIN, CATALOG, MOTION_CONTROLLER_PATH, ORIGINAL_RIG, PARTICLES_ANIM,
                               PARTICLE_TEXTURE, RENDER, RENDER_PATH, SLOT, VISIBLE, write_json)
from geometria import cube_points, frame_in_pose, overlap, transforms
from modelagem import MODES, RIG, create_model


def read(archive, path):
    return json.loads(archive.read(path))


def names(archive):
    entries = archive.namelist()
    assert len(set(entries)) == len(entries), 'ZIP com entradas duplicadas.'
    assert archive.testzip() is None, 'CRC inválido.'
    return set(entries)


def is_detached_effect(name):
    return name in ('ch_olhos', 'ch_borda_reflexos') or name.startswith('ch_borda_gota_')


def contacts(model, avatar, tracks, phase):
    native = {name for name, _, _ in RIG}
    grouped = {}
    for name, bone in model.bones.items():
        if not bone.get('cubes') or is_detached_effect(name):
            continue
        host = name
        while host not in native:
            host = model.bones[host]['parent']
        grouped.setdefault(host, []).extend((name, i, cube) for i, cube in enumerate(bone['cubes']))

    world = transforms(list(model.bones.values()), tracks, phase, {}, 0)
    for host, parts in grouped.items():
        pending = [(name, i, frame_in_pose(cube, world[name])) for name, i, cube in parts]
        connected = [frame_in_pose(cube, world[host]) for cube in avatar[host]['cubes']]
        while pending:
            after = []
            for name, i, frame in pending:
                if any(overlap(frame, anchor, .075) for anchor in connected):
                    connected.append(frame)
                else:
                    after.append((name, i, frame))
            if len(after) == len(pending):
                loose = [(name, i, np.round(frame[0], 2).tolist()) for name, i, frame in after]
                raise AssertionError(f'Peças sem vínculo visual em {model.mode.key}/{host} à fase {phase:.2f}: {loose}')
            pending = after


def shape_audit(model, avatar):
    points = np.concatenate([cube_points(cube) for bone in model.bones.values() for cube in bone.get('cubes', [])])
    mins, maxs = np.round([points.min(axis=0), points.max(axis=0)], 3)
    assert np.all(mins >= [-11.2, .28, -5.1]) and np.all(maxs <= [11.2, 36.3, 8.1]), (model.mode.key, mins, maxs)
    eyes = model.bones['ch_olhos']
    assert eyes['parent'] == 'head' and len(eyes['cubes']) == 2
    assert all(cube['size'][0] < 3 and cube['size'][2] < .05 for cube in eyes['cubes'])
    face = min(cube['origin'][2] for cube in avatar['head']['cubes'])
    assert all(0 < face - cube['origin'][2] - cube['size'][2] < .15 for cube in eyes['cubes'])
    stage = model.mode.stage
    if stage == 1:
        assert {name for name, bone in model.bones.items() if bone.get('cubes')} == {'ch_olhos', 'ch_borda_reflexos'}
    if stage == 2:
        heads = [name for name in model.bones if name.startswith('ch_dragao_cabeca_')]
        assert len(heads) == len({str(model.tracks[name]['rotation']) for name in heads}) == 8
        assert all(len(model.bones[name]['cubes']) >= 10 for name in heads)
    if stage == 3:
        assert 'ch_antebraco_d' in model.bones and 'ch_antebraco_e' not in model.bones
        assert all('cubes' not in model.bones[leg] for leg in ('rightLeg', 'leftLeg'))
    if stage >= 4:
        assert model.bones['rightLeg']['cubes'] and model.bones['leftLeg']['cubes']
    if stage == 5:
        assert len(model.bones) < 60 and sum(len(b.get('cubes', ())) for b in model.bones.values()) < 200

    for slot in model.mode.slots:
        anim = model.animation(slot)['animations'][model.mode.animation(slot)]
        for phase in np.linspace(0, anim['animation_length'], 5):
            contacts(model, avatar, anim['bones'], phase)
    return [mins.tolist(), maxs.tolist()]


def motion_audit(model, rp):
    native = read(rp, 'animations/player.json')['animations']
    sprint = read(rp, 'animations/correndo.json')['animations']['animation.player_new.correndo']
    crouch = {'animation_length': 1., 'bones': {
        'root': {'position': {'0.0': [0, 0, 0], '1.0': [0, -2.2, 0]}},
        'body': {'rotation': {'0.0': [0, 0, 0], '1.0': [25, 0, 0]}},
        'head': {'rotation': {'0.0': [0, 0, 0], '1.0': [-22, 0, 0]}},
        'rightLeg': {'rotation': {'0.0': [0, 0, 0], '1.0': [-14, 0, 0]}},
        'leftLeg': {'rotation': {'0.0': [0, 0, 0], '1.0': [-14, 0, 0]}},
    }}
    poses = {'repouso': {'animation_length': 0., 'bones': {}}, 'caminhada': native['animation.player_new.andando'],
             'corrida': sprint, 'salto': native['animation.player_new.pulo'], 'combate': native['animation.player_new.soco'],
             'agachamento_simulado': crouch}
    tested = {}
    for label, pose in poses.items():
        slot = 'idle'
        if model.mode.stage == 5:
            slot = 'andando' if label in ('caminhada', 'corrida') else 'agachando' if label.startswith('agachamento') else slot
        flow = model.animation(slot)['animations'][model.mode.animation(slot)]
        joints = [bone for name, bone in model.bones.items() if name in flow['bones'] and not is_detached_effect(name)]
        cases = 0
        for time in np.linspace(0, pose['animation_length'], 7):
            for phase in np.linspace(0, flow['animation_length'], 5):
                world = transforms(list(model.bones.values()), flow['bones'], phase, pose['bones'], time)
                for bone in joints:
                    pivot = np.array(bone['pivot'])
                    matrix, move = world[bone['name']]
                    parent, parent_move = world[bone['parent']]
                    at = matrix @ pivot + move
                    expected = parent @ pivot + parent_move
                    assert np.linalg.norm(at - expected) <= .36, (model.mode.key, bone['name'], label)
                    cases += 1
                if model.mode.stage == 5:
                    body, offset = world['body']
                    ring, ring_offset = world['ch_anel']
                    lowest = min(np.min(((cube_points(cube) @ ring.T + ring_offset - offset) @ body)[:, 2])
                                 for cube in model.bones['ch_anel']['cubes'])
                    assert lowest > 3.05, f'Anel avançou para o tronco durante {label}: {lowest}.'
        tested[label] = {'quadros': 7, 'fases': 5, 'encaixes': cases, 'ciclo': slot}
    return tested


def catalog_check(bp):
    menu = bp.read('scripts/menu/config.js').decode()
    tiers = bp.read('scripts/rp_v130_mode_multipliers.js').decode()
    grants = bp.read('scripts/menu/category.js').decode()
    for mode in MODES:
        item = read(bp, f'items/{mode.base_filename}.json')['minecraft:item']
        assert item['description']['identifier'] == mode.item
        assert item['components']['minecraft:wearable']['slot'] == SLOT
        assert re.search(r'\{ id: "' + re.escape(mode.item) + r'",[^\n]+lvl: ' + str(mode.level) + r',', menu)
        lines = [line for line in tiers.splitlines() if '"kekkei:ketsuryugan"' in line and f'"{mode.item}"' in line]
        assert len(lines) == 1 and f'], {min(mode.stage, 4)}, ' in lines[0]
        if mode.stage <= 2:
            section = grants.split(f'if (modo.id === "{mode.item}") {{', 1)[1].split('\n        }', 1)[0]
            assert 'markModeGrantedItem(player, modo.id, "nz:sha_genjutsu")' in section
            assert 'grantBoundTechnique(player, "nz:sha_genjutsu")' in section


def asset_check(rp, manifest):
    assets = set(rp.namelist())
    render = read(rp, RENDER_PATH)['render_controllers'][RENDER]
    assert render['materials'] == [{'*': 'Material.default'}, {'ch_borda_*': 'Material.borda'}]
    assert render['part_visibility'] == [{'*': VISIBLE}]
    ids = {mode.geometry: [] for mode in MODES}
    for path in sorted(assets):
        if not path.startswith('models/') or not path.endswith('.json'):
            continue
        data = rp.read(path)
        for name in ids:
            if f'"{name}"'.encode() in data:
                ids[name].append(path)

    actor = read(rp, PLAYER)['minecraft:client_entity']['description']
    timetables = read(rp, PARTICLES_ANIM)['animations']
    for path in PLAYER_MODELS:
        rig = {bone['name']: bone for bone in read(rp, path)['minecraft:geometry'][0]['bones']}
        for bone, anchors in LOCATORS.items():
            for name, value in anchors.items():
                assert rig[bone]['locators'][locator(name)] == value
    for style, identifier in FX.items():
        particle = read(rp, f'particles/swbr_chinoike_gota_{style}.json')['particle_effect']
        assert particle['description']['identifier'] == actor['particle_effects'][f'chinoike_{style}'] == identifier
        assert particle['description']['basic_render_parameters']['texture'] == PARTICLE_TEXTURE
        assert particle['components']['minecraft:emitter_local_space']['position'] is True
        assert particle['components']['minecraft:particle_lifetime_expression']['max_lifetime'] <= .36
    assert PARTICLE_TEXTURE + '.png' in assets
    admin_animations = read(rp, ADMIN)['minecraft:attachable']['description']['animations']
    assert all(admin_animations[slot] == f'animation.nz_ketsuryugan_bloodmoon.{old}'
               for slot, old in (('parado', 'idle'), ('andando', 'andando'), ('agachando', 'shift')))
    assert 'controller.animation.base_attachable' in read(rp, MOTION_CONTROLLER_PATH)['animation_controllers']

    for mode in MODES:
        spec = manifest['modos'][mode.key]
        assert ids[mode.geometry] == [mode.geometry_path], ids[mode.geometry]
        model = read(rp, mode.geometry_path)['minecraft:geometry'][0]
        for path in mode.paths:
            binding = read(rp, path)['minecraft:attachable']['description']
            player = path.endswith('.player.json')
            assert binding['identifier'] == mode.item + ('.player' if player else '')
            assert binding['geometry'] == {'default': mode.geometry}
            assert binding['textures'] == {'default': mode.texture} and binding['render_controllers'] == [RENDER]
            assert binding['materials'] == {'default': 'entity_alphatest', 'borda': 'entity_alphablend'}
            if player:
                assert binding['item'] == {mode.item: "query.owner_identifier == 'minecraft:player'"}
            for slot in mode.slots:
                assert mode.animation(slot) in binding['animations'].values()
        for slot in mode.slots:
            animation = read(rp, mode.animation_path(slot))['animations'][mode.animation(slot)]
            assert set(animation['bones']) <= {bone['name'] for bone in model['bones']}

        effects = timetables[actor['animations']['chinoike_gotas_' + mode.key]]['particle_effects']
        assert all(event['effect'] in actor['particle_effects']
                   and event['locator'] in {locator(name) for points in LOCATORS.values() for name in points}
                   for event in effects.values())

        png = rp.read(spec['textura'])
        with Image.open(BytesIO(png)) as texture:
            assert texture.size == (256, 256) and texture.mode == 'RGBA'
            assert texture.getchannel('A').getextrema() == (0, 255)
        project = json.loads((ROOT / 'Modelos_Blockbench' / mode.project).read_bytes())
        assert len(project['elements']) == spec['cubos'] and len(project['animations']) == len(mode.slots)
        assert b64decode(project['textures'][0]['source'].split(',')[1]) == png


def player_diff(old, new):
    before = read(old, PLAYER)
    after = read(new, PLAYER)
    actor = after['minecraft:client_entity']['description']
    old_actor = before['minecraft:client_entity']['description']
    actor['scripts']['animate'] = actor['scripts']['animate'][:-len(MODES)]
    actor['scripts']['pre_animation'] = actor['scripts']['pre_animation'][:-2]
    for mode in MODES:
        actor['animations'].pop('chinoike_gotas_' + mode.key)
    for size in FX:
        actor['particle_effects'].pop(f'chinoike_{size}')
    if 'particle_effects' not in old_actor:
        del actor['particle_effects']
    for layer in actor['render_controllers']:
        if isinstance(layer, dict):
            for key in COSMETIC_EYES.intersection(layer):
                suffix = f') && !{EYE_DRAW}'
                assert layer[key].startswith('(') and layer[key].endswith(suffix)
                layer[key] = layer[key][1:-len(suffix)]
    assert before == after, 'Definições do jogador alteradas fora dos efeitos Chinoike.'

    for path in PLAYER_MODELS:
        before = read(old, path)
        after = read(new, path)
        for bone in after['minecraft:geometry'][0]['bones']:
            for name in LOCATORS.get(bone['name'], {}):
                bone['locators'].pop(locator(name))
            if bone.get('locators') == {}:
                del bone['locators']
        assert before == after, f'Rig nativo alterado além dos locators Chinoike em {path}.'


def audit(base, output, manifest, check_geometry):
    before, after = open_packs(base), open_packs(output)
    family = manifest['bases'][sha256(base.read_bytes())]['base']
    overlay = read_overlay(ROOT, manifest)
    info = {}
    with ZipFile(base) as original, ZipFile(output) as revised:
        siblings = names(original) - {entry[0] for entry in before.values()}
        assert names(revised) == siblings | {entry[0] for entry in after.values()} | {NOTES}
        for path in siblings:
            data = revised.read(path)
            assert data == original.read(path), path
            if path.endswith('.mcpack'):
                with ZipFile(BytesIO(data)) as other:
                    names(other)
        assert revised.read(NOTES) == (ROOT / 'LEIA-ME.md').read_bytes()

    for kind in ('BP', 'RP'):
        with ZipFile(BytesIO(before[kind][2])) as old, ZipFile(BytesIO(after[kind][2])) as new:
            old_names, new_names = names(old), names(new)
            changes = changed_assets(kind, old, manifest, overlay if kind == 'RP' else {})
            assert new_names == old_names | set(changes)
            for path in new_names - {'manifest.json'}:
                expected = changes[path] if path in changes else old.read(path)
                assert new.read(path) == expected, (kind, path)
            assert read(new, 'manifest.json') == upgrade_manifest(before[kind][1], family)
            if kind == 'BP':
                assert not changes
                catalog_check(new)
            else:
                preserved = [ADMIN, MOTION_CONTROLLER_PATH, 'animations/nz_sennin_mitsuki.json']
                preserved += [f'animations/nz_ketsuryugan_bloodmoon.{slot}.json' for slot in ('andando', 'idle', 'shift')]
                assert all(path not in changes and new.read(path) == old.read(path) for path in preserved if path in old_names)
                player_diff(old, new)
                asset_check(new, manifest)
                if check_geometry:
                    avatar = {bone['name']: bone for bone in read(new, ORIGINAL_RIG)['minecraft:geometry'][0]['bones']}
                    modes = {}
                    for mode in MODES:
                        model = create_model(mode)
                        modes[mode.key] = {'limites': shape_audit(model, avatar), 'poses': motion_audit(model, new)}
                        print(f'{mode.name}: limites, encaixes e poses conferidos.', flush=True)
                    info['modos'] = modes
            affected = set(changes) | {'manifest.json'}
            info[kind] = {'total': len(new_names), 'preservados': len(old_names - affected),
                          'substituídos': sorted(affected & old_names), 'adicionados': sorted(affected - old_names)}
    info['sha256'] = sha256(output.read_bytes())
    return info


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'Integracao_Manifesto.json').read_bytes())
    result = {'versao': VERSION, 'minecraft_executado': False, 'edicoes': {}}
    for name, source in (('original', args.original), ('cumulativa', args.cumulativa)):
        output = ROOT / CATALOG[name][0]
        result['edicoes'][name] = audit(source, output, manifest, name == 'original')
        print(output.name, 'validado.')
    write_json(ROOT / 'Validacao.json', result)
