"""Transformações e interseções para conferir o alinhamento dos modelos."""

from itertools import product
from math import cos, radians, sin

import numpy as np


def rotation(angles):
    x, y, z = -radians(angles[0]), radians(angles[1]), -radians(angles[2])
    cx, sx, cy, sy, cz, sz = cos(x), sin(x), cos(y), sin(y), cos(z), sin(z)
    return np.array(((cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx),
                     (sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx), (-sy, cy * sx, cy * cx)))


def sample(channel, time):
    if isinstance(channel, list):
        return np.array(channel, dtype=float)
    if isinstance(channel, (int, float)):
        return np.full(3, channel, dtype=float)

    def vector(frame):
        if isinstance(frame, dict):
            frame = frame.get('post', frame.get('pre'))
        return np.array(frame, dtype=float)

    steps = sorted((float(key), vector(frame)) for key, frame in channel.items())
    if time <= steps[0][0]:
        return steps[0][1]
    for (start, a), (stop, b) in zip(steps, steps[1:]):
        if time <= stop:
            return a + (b - a) * (time - start) / (stop - start)
    return steps[-1][1]


def transforms(bones, idle, phase, action, time):
    world = {}
    for bone in bones:
        name, pivot = bone['name'], np.array(bone['pivot'])
        tracks, frame = (action[name], time) if name in action else (idle.get(name, {}), phase)
        offset = sample(tracks.get('position', [0, 0, 0]), frame)
        scale = sample(tracks.get('scale', [1, 1, 1]), frame)
        matrix = rotation(sample(tracks.get('rotation', [0, 0, 0]), frame)) * scale
        offset = pivot + offset - matrix @ pivot
        if 'parent' in bone:
            matrix_p, offset_p = world[bone['parent']]
            matrix, offset = matrix_p @ matrix, matrix_p @ offset + offset_p
        world[name] = matrix, offset
    return world


def cube_frame(cube):
    origin = np.array(cube['origin'])
    half = np.array(cube['size']) / 2
    pivot = np.array(cube.get('pivot', origin))
    matrix = rotation(cube.get('rotation', [0, 0, 0]))
    center = matrix @ (origin + half - pivot) + pivot
    return center, matrix, half


def frame_in_pose(cube, transform):
    center, axes, half = cube_frame(cube)
    matrix, shift = transform
    return matrix @ center + shift, matrix @ axes, half


def overlap(a, b, margin=.06):
    ac, am, ah = a
    bc, bm, bh = b
    axes = np.vstack((am.T, bm.T, np.cross(am.T[:, None, :], bm.T).reshape(-1, 3)))
    reach = np.abs(axes @ am) @ ah + np.abs(axes @ bm) @ bh
    return bool(np.all(np.abs(axes @ (bc - ac)) <= reach + margin * np.linalg.norm(axes, axis=1)))


def cube_points(cube):
    center, basis, half = cube_frame(cube)
    return (np.array(list(product((-1, 1), repeat=3))) * half) @ basis.T + center
