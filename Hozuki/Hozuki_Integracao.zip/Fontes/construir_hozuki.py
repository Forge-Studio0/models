#!/usr/bin/env python3
"""Monta os três modos Hōzuki na base original e na base cumulativa."""

import argparse
import copy
import io
import json
from pathlib import Path
import re
from zipfile import ZipFile

from aplicar_integracao import PACK_UUIDS, ROOT, apply, open_packs, sha256
from modelagem import MODES, RIG, SIZE, atlas, create_model


VERSION = [18, 11, 74]
PLAYER = 'entity/player.entity.json'
VISUALS = 'scripts/rp_v159_visual_rework.js'
SLOT = 'geometry.swbr.hozuki.slot'
SLOT_RC = 'controller.render.swbr.hozuki.slot'
COLLISION_RIG = 'models/entity/swbr39/custom.geo.json'
CAMERA_LIMITS = (2.0, 2.24, 2.62)
FADE_WIDTH = .42
LAYERS = ('core', 'surface')


def write_json(path, data, compact=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    options = {'separators': (',', ':')} if compact else {'indent': 2}
    path.write_text(json.dumps(data, ensure_ascii=False, **options) + '\n', encoding='utf-8')


def entry(path, root):
    return {'arquivo': path.relative_to(root).as_posix(), 'sha256': sha256(path.read_bytes())}


def geometry_slot():
    return {'format_version': '1.16.0', 'minecraft:geometry': [{
        'description': {'identifier': SLOT, 'texture_width': SIZE, 'texture_height': SIZE},
        'bones': [{'name': 'root', 'pivot': [0, 0, 0]}],
    }]}


def slot_attachable(original, mode):
    desc = original['minecraft:attachable']['description']
    body = {'identifier': desc['identifier'], 'materials': {'default': 'entity_alphablend'},
            'textures': {'default': mode.texture}, 'geometry': {'default': SLOT},
            'render_controllers': [SLOT_RC]}
    if 'item' in desc:
        body['item'] = desc['item']
    return {'format_version': '1.10.0', 'minecraft:attachable': {'description': body}}


def attachable_definitions(archive):
    matches = {m.item: {} for m in MODES}
    for path in archive.namelist():
        if not path.startswith('attachables/') or not path.endswith('.json'):
            continue
        data = archive.read(path)
        if not any(mode.item.encode() in data for mode in MODES):
            continue
        doc = json.loads(data)
        desc = doc['minecraft:attachable']['description']
        for mode in MODES:
            if desc['identifier'] in (mode.item, mode.item + '.player') or mode.item in (desc.get('item') or {}):
                matches[mode.item][path] = doc
    if any(not values for values in matches.values()):
        raise ValueError('Attachable Hōzuki original não localizado.')
    return matches


def camera_code():
    stages = '0'
    for mode in reversed(MODES):
        stages = f"q.is_item_name_any('slot.armor.head', 0, '{mode.item}') ? {mode.number} : ({stages})"
    alpha = f'math.clamp((q.distance_from_camera - v.swbr_hozuki_min) / {FADE_WIDTH}, 0, 1)'
    near, middle, far = CAMERA_LIMITS
    return [
        f'v.swbr_hozuki_stage = {stages};',
        'v.swbr_hozuki_world = !v.swbr_view_first_person && !v.swbr39_ui && !v.swbr_view_map_face && !q.is_spectator && !q.is_invisible;',
        f'v.swbr_hozuki_min = v.swbr_hozuki_stage == 3 ? {far} : (v.swbr_hozuki_stage == 2 ? {middle} : {near});',
        f'v.swbr_hozuki_fade = (v.swbr_hozuki_world && v.swbr_hozuki_stage > 0) ? {alpha} : 0.0;',
    ]


def render_definition(alias=None, texture=None, alpha=None):
    if alias is None:
        return {'geometry': 'Geometry.default', 'materials': [{'*': 'Material.default'}], 'textures': ['Texture.default']}
    return {'geometry': 'Geometry.' + alias, 'materials': [{'*': 'Material.swbr_hozuki_agua'}],
            'textures': ['Texture.' + texture], 'color': {'r': 1, 'g': 1, 'b': 1, 'a': alpha}}


def bind_player(data):
    desc = data['minecraft:client_entity']['description']
    code = desc['scripts']['pre_animation']
    for name in ('v.swbr39_ui', 'v.swbr_view_first_person', 'v.swbr_view_map_face'):
        if not any(line.startswith(name + ' =') for line in code):
            raise ValueError(f'Variável de câmera da base não encontrada: {name}.')
    if any(line.startswith('v.swbr_hozuki_') for line in code):
        raise ValueError('A base já tem a integração visual Hōzuki.')
    code.extend(camera_code())
    desc['materials']['swbr_hozuki_agua'] = 'entity_alphablend'
    for mode in MODES:
        prefix = 'swbr_hozuki_' + mode.key
        gate = f'v.swbr_hozuki_stage == {mode.number} && v.swbr_hozuki_fade > 0'
        desc['textures'][prefix] = mode.texture
        desc['animations'][prefix + '_fluxo'] = mode.animation
        desc['scripts']['animate'].append({prefix + '_fluxo': gate})
        for layer in LAYERS:
            desc['geometry'][prefix + '_' + layer] = mode.geometry + '.' + layer
            desc['render_controllers'].append({f'controller.render.swbr.hozuki.{mode.key}.{layer}': gate})
    return data


def patch_ambient_effect(data):
    """O modelo simula gotas localmente. A técnica lançada tem outro script."""
    text = data.decode('utf-8')
    activation_pattern = r'^  else if\(key==="hozuki"\)\{ ring\(p,"nz:agua"[^\n]*\}$'
    text, activation = re.subn(activation_pattern,
                              '  else if(key==="hozuki"){ sound(p,"random.splash",.8,1); }', text, flags=re.MULTILINE)
    passive_pattern = r'^  \} else if\(key==="hozuki"\)\{\n(?:    [^\n]+\n)+(?=^  \} else if\(key==="konan"\))'
    text, passive = re.subn(passive_pattern, '', text, flags=re.MULTILINE)
    before = 'else if(old&&old!=="mangekyou")burst'
    if activation != 1 or passive != 1 or text.count(before) != 1:
        raise ValueError('Os efeitos de equipar Hōzuki divergem da base esperada.')
    return text.replace(before, 'else if(old&&old!=="mangekyou"&&old!=="hozuki")burst').encode('utf-8')


def manifest_for(original, base):
    doc = copy.deepcopy(original)
    header = doc['header']
    header['version'] = VERSION
    header['name'] = 'Shinobi World BR 18.11.74 · Hōzuki'
    header['description'] = f'Shinobi World BR 18.11.74 | Três modos Hōzuki | Base {base}'
    for module in doc['modules']:
        module['version'] = VERSION
    for dep in doc.get('dependencies', []):
        if dep.get('uuid') in PACK_UUIDS.values():
            dep['version'] = VERSION
    return doc


def assert_native_rig(pack):
    geometry = json.loads(pack.read(COLLISION_RIG))['minecraft:geometry'][0]
    native = {b['name']: b for b in geometry['bones']}
    for name, parent, pivot in RIG:
        if native[name].get('parent') != parent or tuple(native[name]['pivot']) != pivot:
            raise ValueError(f'Rig do jogador divergente: {name}.')


def build(base64, base73, root=ROOT):
    bases = {'18.11.64': base64, '18.11.73': base73}
    out = root / 'Integracao'
    rp = out / 'RP'
    manifest = {'cla': 'Hōzuki', 'versao': VERSION, 'slot': 'slot.armor.head', 'modos': {}, 'bases': {}, 'arquivos': {}}
    renderer = {SLOT_RC: render_definition()}
    sources = {}
    for base, filename in bases.items():
        packs = open_packs(filename)
        with ZipFile(io.BytesIO(packs['RP'][2])) as pack:
            assert_native_rig(pack)
            sources[base] = attachable_definitions(pack)
        spec = {'nome': filename.name, 'sha256': sha256(filename.read_bytes()), 'packs': {}}
        for kind, (archive, original, data) in packs.items():
            if '.'.join(map(str, original['header']['version'])) != base:
                raise ValueError(f'Arquivo não corresponde à base {base}.')
            target = out / 'Versoes' / base / kind
            write_json(target / 'manifest.json', manifest_for(original, base))
            with ZipFile(io.BytesIO(data)) as pack:
                if kind == 'RP':
                    write_json(target / PLAYER, bind_player(json.loads(pack.read(PLAYER))), compact=True)
                else:
                    visual = target / VISUALS
                    visual.parent.mkdir(parents=True, exist_ok=True)
                    visual.write_bytes(patch_ambient_effect(pack.read(VISUALS)))
            spec['packs'][kind] = {
                'entrada': archive, 'saida': f'SWBR_{kind}_v18.11.74_HOZUKI.mcpack',
                'arquivos': {path.relative_to(target).as_posix(): entry(path, root) for path in sorted(target.rglob('*')) if path.is_file()},
            }
        manifest['bases'][base] = spec
    if sources['18.11.64'] != sources['18.11.73']:
        raise ValueError('Os vínculos originais dos itens diferem entre as bases.')
    for mode in MODES:
        model = create_model(mode)
        write_json(rp / mode.geometry_path, model.document())
        write_json(rp / mode.animation_path, model.animation())
        texture = rp / (mode.texture + '.png')
        texture.parent.mkdir(parents=True, exist_ok=True)
        atlas(mode.number).save(texture, optimize=True)
        prefix = 'swbr_hozuki_' + mode.key
        draw_paths = {}
        counts = {}
        for layer in LAYERS:
            path = mode.geometry_path.replace('.geo.json', f'.{layer}.geo.json')
            draw = model.document(layer)
            write_json(rp / path, draw)
            draw_paths[layer] = path
            counts[layer] = sum(len(b.get('cubes', [])) for b in draw['minecraft:geometry'][0]['bones'])
            renderer[f'controller.render.swbr.hozuki.{mode.key}.{layer}'] = render_definition(
                prefix + '_' + layer, prefix, 'v.swbr_hozuki_fade')
        attachables = sources['18.11.64'][mode.item]
        for path, document in attachables.items():
            write_json(rp / path, slot_attachable(document, mode))
        manifest['modos'][mode.key] = {
            'id': mode.item, 'nome': mode.name, 'requisito': mode.unlock, 'projeto': mode.project,
            'arquivo_geo': mode.geometry_path, 'geometria': mode.geometry, 'textura': mode.texture + '.png',
            'arquivo_anim': mode.animation_path, 'animacao': mode.animation, 'duracao': mode.length,
            'camadas': draw_paths, 'attachables': sorted(attachables), 'cubos': sum(counts.values()),
            'bones': len(model.bones), 'canais': len(model.motion), 'faces_por_camada': counts,
        }
    write_json(rp / 'models/entity/swbr/hozuki/slot.geo.json', geometry_slot())
    write_json(rp / 'render_controllers/swbr_hozuki.json', {'format_version': '1.8.0', 'render_controllers': renderer})
    for kind in PACK_UUIDS:
        target = out / kind
        manifest['arquivos'][kind] = {
            f.relative_to(target).as_posix(): entry(f, root) for f in sorted(target.rglob('*')) if f.is_file()
        }
    write_json(root / 'Integracao_Manifesto.json', manifest)
    for key, filename in (('18.11.64', 'Hozuki.mcaddon'), ('18.11.73', 'Hozuki_Cumulativo.mcaddon')):
        print(apply(bases[key], root / filename, root))
    for info in manifest['modos'].values():
        print(info['nome'], info['faces_por_camada'], f'{info["canais"]} bones animados')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base64', type=Path)
    parser.add_argument('base73', type=Path)
    args = parser.parse_args()
    build(args.base64, args.base73)
