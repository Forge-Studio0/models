#!/usr/bin/env python3
"""Gera as duas edições Hōzuki a partir dos pacotes da revisão anterior."""

import argparse
import copy
import io
import json
from pathlib import Path
import re
from zipfile import ZipFile

from aplicar_integracao import PACK_UUIDS, ROOT, apply, open_packs, sha256
from modelagem import MODES, RIG, SIZE, create_model


VERSION = [18, 11, 77]
PLAYER = 'entity/player.entity.json'
VISUALS = 'scripts/rp_v159_visual_rework.js'
SLOT = 'geometry.swbr.hozuki.slot'
SLOT_RC = 'controller.render.swbr.hozuki.slot'
COLLISION_RIG = 'models/entity/swbr39/custom.geo.json'
LAYERS = ('core', 'surface')
VANILLA_BODY = 'render_controllers/player.json'
SWBR_BODY = 'render_controllers/nzs_body_v1875.render_controllers.json'
RIGHT_ARM = ('rightArm',)
TORSO_AND_LIMBS = ('body', 'leftArm', 'rightLeg', 'leftLeg')


def write_json(path, data, compact=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    options = {'separators': (',', ':')} if compact else {'indent': 2}
    path.write_text(json.dumps(data, ensure_ascii=False, **options) + '\n', encoding='utf-8')


def entry(path, root):
    return {'arquivo': path.relative_to(root).as_posix(), 'sha256': sha256(path.read_bytes())}


def geometry_slot():
    return {'format_version': '1.16.0', 'minecraft:geometry': [{
        'description': {'identifier': SLOT, 'texture_width': SIZE, 'texture_height': SIZE},
        'bones': [{'name': 'root', 'pivot': [0, 0, 0]}],
    }]}


def slot_attachable(original, mode):
    desc = original['minecraft:attachable']['description']
    body = {'identifier': desc['identifier'], 'materials': {'default': 'entity_alphablend'},
            'textures': {'default': mode.texture}, 'geometry': {'default': SLOT},
            'render_controllers': [SLOT_RC]}
    if 'item' in desc:
        body['item'] = desc['item']
    return {'format_version': '1.10.0', 'minecraft:attachable': {'description': body}}


def attachable_definitions(archive):
    matches = {m.item: {} for m in MODES}
    for path in archive.namelist():
        if not path.startswith('attachables/') or not path.endswith('.json'):
            continue
        data = archive.read(path)
        if not any(mode.item.encode() in data for mode in MODES):
            continue
        doc = json.loads(data)
        desc = doc['minecraft:attachable']['description']
        for mode in MODES:
            if desc['identifier'] in (mode.item, mode.item + '.player') or mode.item in (desc.get('item') or {}):
                matches[mode.item][path] = doc
    if any(not values for values in matches.values()):
        raise ValueError('Attachable Hōzuki original não localizado.')
    return matches


def camera_code():
    stages = '0'
    for mode in reversed(MODES):
        stages = f"q.is_item_name_any('slot.armor.head', 0, '{mode.item}') ? {mode.number} : ({stages})"
    return [
        f'v.swbr_hozuki_stage = {stages};',
        'v.swbr_hozuki_world = !v.swbr_view_first_person && !v.swbr39_ui && !v.swbr_view_map_face '
        '&& !q.is_spectator && !q.is_invisible && !v.swbr_douma14 '
        '&& !(v.swbr_v1878_ape && v.swbr_v1878_draw) && !(v.nzs_vast_bleach ?? 0.0) '
        '&& !v.swbr_v18733_full_body '
        "&& !q.is_item_name_any('slot.armor.chest', 0, 'nz:modo_sukuna_admin', 'nz:modo_otsutsuki_pcd_admin');",
    ]


def render_definition(alias=None, texture=None):
    if alias is None:
        return {'geometry': 'Geometry.default', 'materials': [{'*': 'Material.default'}], 'textures': ['Texture.default']}
    return {'geometry': 'Geometry.' + alias, 'materials': [{'*': 'Material.swbr_hozuki_agua'}],
            'textures': ['Texture.' + texture]}


def remove_hozuki_bindings(data):
    desc = data['minecraft:client_entity']['description']
    for key in ('materials', 'textures', 'geometry', 'animations'):
        desc[key] = {name: value for name, value in desc[key].items() if not name.startswith('swbr_hozuki_')}
    scripts = desc['scripts']
    scripts['pre_animation'] = [line for line in scripts['pre_animation'] if not line.startswith('v.swbr_hozuki_')]
    scripts['animate'] = [row for row in scripts['animate'] if not isinstance(row, dict)
                          or not any(name.startswith('swbr_hozuki_') for name in row)]
    desc['render_controllers'] = [row for row in desc['render_controllers'] if not isinstance(row, dict)
                                 or not any(name.startswith('controller.render.swbr.hozuki.') for name in row)]
    return data


def bind_player(data):
    remove_hozuki_bindings(data)
    desc = data['minecraft:client_entity']['description']
    code = desc['scripts']['pre_animation']
    for name in ('v.swbr39_ui', 'v.swbr_view_first_person', 'v.swbr_view_map_face'):
        if not any(line.startswith(name + ' =') for line in code):
            raise ValueError(f'Variável de câmera da base não encontrada: {name}.')
    code.extend(camera_code())
    desc['materials']['swbr_hozuki_agua'] = 'entity_alphablend'
    for mode in MODES:
        prefix = 'swbr_hozuki_' + mode.key
        gate = f'v.swbr_hozuki_world && v.swbr_hozuki_stage == {mode.number}'
        desc['textures'][prefix] = mode.texture
        desc['animations'][prefix + '_fluxo'] = mode.animation
        desc['scripts']['animate'].append({prefix + '_fluxo': gate})
        for layer in LAYERS:
            desc['geometry'][prefix + '_' + layer] = mode.geometry + '.' + layer
            desc['render_controllers'].append({f'controller.render.swbr.hozuki.{mode.key}.{layer}': gate})
    return data


def body_visibility(doc, path):
    controllers = doc['render_controllers']
    if path == VANILLA_BODY:
        body = [controllers['controller.render.player.third_person']]
        arm = (*RIGHT_ARM, 'rightSleeve')
        mass = (*TORSO_AND_LIMBS, 'leftSleeve', 'jacket', 'rightPants', 'leftPants')
    else:
        body = [controller for controller in controllers.values() if controller['geometry'] == 'Geometry.custom']
        if not body:
            raise ValueError('Controladores do corpo SWBR não encontrados.')
        arm, mass = RIGHT_ARM, TORSO_AND_LIMBS
    for controller in body:
        parts = controller['part_visibility']
        if not parts or set(parts[0]) != {'*'}:
            raise ValueError('Visibilidade original do corpo diverge da base esperada.')
        visible = parts[0]['*']
        masks = []
        for bones, threshold in ((arm, 2), (mass, 3)):
            condition = f'({visible}) && !(v.swbr_hozuki_world && v.swbr_hozuki_stage >= {threshold})'
            masks.extend({bone: condition} for bone in bones)
        if parts[1:] and parts[1:] != masks:
            raise ValueError('Máscara anterior do corpo diverge da base esperada.')
        controller['part_visibility'] = [parts[0], *masks]
    return doc


def patch_ambient_effect(data):
    """O modelo simula gotas localmente. A técnica lançada tem outro script."""
    text = data.decode('utf-8')
    activation_pattern = r'^  else if\(key==="hozuki"\)\{ ring\(p,"nz:agua"[^\n]*\}$'
    text, activation = re.subn(activation_pattern,
                              '  else if(key==="hozuki"){ sound(p,"random.splash",.8,1); }', text, flags=re.MULTILINE)
    passive_pattern = r'^  \} else if\(key==="hozuki"\)\{\n(?:    [^\n]+\n)+(?=^  \} else if\(key==="konan"\))'
    text, passive = re.subn(passive_pattern, '', text, flags=re.MULTILINE)
    before = 'else if(old&&old!=="mangekyou")burst'
    if activation != 1 or passive != 1 or text.count(before) != 1:
        raise ValueError('Os efeitos de equipar Hōzuki divergem da base esperada.')
    return text.replace(before, 'else if(old&&old!=="mangekyou"&&old!=="hozuki")burst').encode('utf-8')


def manifest_for(original, base):
    doc = copy.deepcopy(original)
    header = doc['header']
    release = '.'.join(map(str, VERSION))
    header['version'] = VERSION
    header['name'] = f'Shinobi World BR {release} · Hōzuki'
    header['description'] = f'Shinobi World BR {release} | Revisão visual Hōzuki | Base {base}'
    for module in doc['modules']:
        module['version'] = VERSION
    for dep in doc.get('dependencies', []):
        if dep.get('uuid') in PACK_UUIDS.values():
            dep['version'] = VERSION
    return doc


def assert_native_rig(pack):
    geometry = json.loads(pack.read(COLLISION_RIG))['minecraft:geometry'][0]
    native = {b['name']: b for b in geometry['bones']}
    for name, parent, pivot in RIG:
        if native[name].get('parent') != parent or tuple(native[name]['pivot']) != pivot:
            raise ValueError(f'Rig do jogador divergente: {name}.')


def build(original, cumulative, previous_integration, root=ROOT):
    inputs = {'18.11.64': original, '18.11.73': cumulative}
    with ZipFile(previous_integration) as previous:
        prior = json.loads(previous.read('Integracao_Manifesto.json'))
    release = '.'.join(map(str, VERSION))
    source_release = '.'.join(map(str, prior['versao']))
    out = root / 'Integracao'
    rp = out / 'RP'
    manifest = {'cla': 'Hōzuki', 'versao': VERSION, 'slot': 'slot.armor.head', 'modos': {}, 'bases': {},
                'arquivos': {}, 'entradas_de_construcao': []}
    renderer = {SLOT_RC: render_definition()}
    sources = {}
    for base, filename in inputs.items():
        legacy = prior['bases'][base]
        packs = open_packs(filename)
        with ZipFile(io.BytesIO(packs['RP'][2])) as pack:
            assert_native_rig(pack)
            sources[base] = attachable_definitions(pack)
        variant = 'original' if base == '18.11.64' else 'cumulativa'
        revision = f'{source_release}-{variant}'
        spec = {'nome': filename.name, 'sha256': sha256(filename.read_bytes()), 'packs': {}}
        previous_packs = {}
        for kind, (archive, previous_manifest, data) in packs.items():
            if previous_manifest['header']['version'] != prior['versao'] or archive != legacy['packs'][kind]['saida']:
                raise ValueError(f'Arquivo não corresponde à revisão {revision}.')
            target = out / 'Versoes' / base / kind
            write_json(target / 'manifest.json', manifest_for(previous_manifest, base))
            with ZipFile(io.BytesIO(data)) as pack:
                for path, old in legacy['packs'][kind]['arquivos'].items():
                    if sha256(pack.read(path)) != old['sha256']:
                        raise ValueError(f'A entrada diverge da edição {revision}: {kind}/{path}.')
                if kind == 'RP':
                    write_json(target / PLAYER, bind_player(json.loads(pack.read(PLAYER))), compact=True)
                    for path in (VANILLA_BODY, SWBR_BODY):
                        write_json(target / path, body_visibility(json.loads(pack.read(path)), path))
                else:
                    visual = target / VISUALS
                    visual.parent.mkdir(parents=True, exist_ok=True)
                    visual.write_bytes(pack.read(VISUALS))
            entries = {path.relative_to(target).as_posix(): entry(path, root)
                       for path in sorted(target.rglob('*')) if path.is_file()}
            spec['packs'][kind] = {
                'entrada': archive, 'saida': f'SWBR_{kind}_v{release}_HOZUKI.mcpack',
                'arquivos': {path: info for path, info in entries.items() if path != VISUALS},
            }
            previous_packs[kind] = entries
        manifest['bases'][revision] = spec
        manifest['entradas_de_construcao'].append(revision)
        manifest_path = legacy['packs']['BP']['arquivos']['manifest.json']['arquivo']
        for key, older in prior['bases'].items():
            if older['packs']['BP']['arquivos']['manifest.json']['arquivo'] != manifest_path:
                continue
            compatible = {'nome': older['nome'], 'sha256': older['sha256'], 'packs': {}}
            for kind, old_pack in older['packs'].items():
                compatible['packs'][kind] = {
                    **spec['packs'][kind], 'entrada': old_pack['entrada'],
                    'arquivos': {path: previous_packs[kind][path] for path in old_pack['arquivos']},
                }
            manifest['bases'][key] = compatible
    if sources['18.11.64'] != sources['18.11.73']:
        raise ValueError('Os vínculos originais dos itens diferem entre as bases.')
    for mode in MODES:
        model = create_model(mode)
        write_json(rp / mode.geometry_path, model.document())
        write_json(rp / mode.animation_path, model.animation())
        texture = rp / (mode.texture + '.png')
        texture.parent.mkdir(parents=True, exist_ok=True)
        model.texture().save(texture, optimize=True)
        prefix = 'swbr_hozuki_' + mode.key
        draw_paths = {}
        counts = {}
        for layer in LAYERS:
            path = mode.geometry_path.replace('.geo.json', f'.{layer}.geo.json')
            draw = model.document(layer)
            write_json(rp / path, draw)
            draw_paths[layer] = path
            counts[layer] = sum(len(b.get('cubes', [])) for b in draw['minecraft:geometry'][0]['bones'])
            renderer[f'controller.render.swbr.hozuki.{mode.key}.{layer}'] = render_definition(prefix + '_' + layer, prefix)
        attachables = sources['18.11.64'][mode.item]
        for path, document in attachables.items():
            write_json(rp / path, slot_attachable(document, mode))
        manifest['modos'][mode.key] = {
            'id': mode.item, 'nome': mode.name, 'requisito': mode.unlock, 'projeto': mode.project,
            'arquivo_geo': mode.geometry_path, 'geometria': mode.geometry, 'textura': mode.texture + '.png',
            'arquivo_anim': mode.animation_path, 'animacao': mode.animation, 'duracao': mode.length,
            'camadas': draw_paths, 'attachables': sorted(attachables), 'cubos': sum(counts.values()),
            'bones': len(model.bones), 'canais': len(model.motion), 'faces_por_camada': counts, 'atlas': SIZE,
        }
    write_json(rp / 'models/entity/swbr/hozuki/slot.geo.json', geometry_slot())
    write_json(rp / 'render_controllers/swbr_hozuki.json', {'format_version': '1.8.0', 'render_controllers': renderer})
    for kind in PACK_UUIDS:
        target = out / kind
        manifest['arquivos'][kind] = {
            f.relative_to(target).as_posix(): entry(f, root) for f in sorted(target.rglob('*')) if f.is_file()
        }
    write_json(root / 'Integracao_Manifesto.json', manifest)
    for key, filename in (('18.11.64', 'Hozuki.mcaddon'), ('18.11.73', 'Hozuki_Cumulativo.mcaddon')):
        print(apply(inputs[key], root / filename, root))
    for info in manifest['modos'].values():
        print(info['nome'], info['faces_por_camada'], f'{info["canais"]} bones animados')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path, help='Hozuki.mcaddon 18.11.76')
    parser.add_argument('cumulativa', type=Path, help='Hozuki_Cumulativo.mcaddon 18.11.76')
    parser.add_argument('integracao_anterior', type=Path, help='Hozuki_Integracao.zip 18.11.76')
    args = parser.parse_args()
    build(args.original, args.cumulativa, args.integracao_anterior)
