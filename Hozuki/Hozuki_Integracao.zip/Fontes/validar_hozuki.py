#!/usr/bin/env python3
"""Confere os packs, os ciclos e quatro projeções da água em poses do SWBR."""

import argparse
import base64
from contextlib import ExitStack
import io
import json
from math import cos, radians, sin
from pathlib import Path
import subprocess
from zipfile import ZipFile

import numpy as np
from PIL import Image

from aplicar_integracao import ROOT, PACK_UUIDS, RELEASE_NOTES, base_spec, checked_file, open_packs
from construir_hozuki import (
    COLLISION_RIG, LAYERS, PLAYER, RIGHT_ARM, SLOT, SWBR_BODY, TORSO_AND_LIMBS, VANILLA_BODY, VISUALS,
    body_visibility, patch_ambient_effect, remove_hozuki_bindings, write_json,
)
from modelagem import MODES, RIG, SIZE, atlas, create_model


def require(ok, note):
    if not ok:
        raise AssertionError(note)


def files(archive):
    names = [entry.filename for entry in archive.infolist() if not entry.is_dir()]
    require(len(set(names)) == len(names), 'Entradas ZIP duplicadas.')
    require(all(not name.startswith('/') and '..' not in name.split('/') for name in names), 'Caminho inválido.')
    return set(names)


def read(pack, path):
    return json.loads(pack.read(path))


def read_disk(path):
    return json.loads(path.read_bytes())


def audit_addon(base, addon, manifest):
    key, source_spec = base_spec(base, manifest)
    previous, current = open_packs(base), open_packs(addon)
    spec = source_spec['packs']
    report = {}
    with ZipFile(base) as old, ZipFile(addon) as new, ExitStack() as stack:
        for container in (old, new):
            require(container.testzip() is None, 'CRC do arquivo externo inválido.')
        original_names = {spec[k]['entrada'] for k in PACK_UUIDS}
        addon_names = {spec[k]['saida'] for k in PACK_UUIDS}
        other = files(old) - original_names - {RELEASE_NOTES}
        require(files(new) == other | addon_names | {RELEASE_NOTES}, 'Arquivos externos divergentes.')
        require(new.read(RELEASE_NOTES) == (ROOT / 'LEIA-ME.md').read_bytes(), 'Documentação do addon divergente.')
        for name in other:
            require(old.read(name) == new.read(name), f'Arquivo externo alterado: {name}.')
        packs = {}
        for kind, uuid in PACK_UUIDS.items():
            source = stack.enter_context(ZipFile(io.BytesIO(previous[kind][2])))
            target = stack.enter_context(ZipFile(io.BytesIO(current[kind][2])))
            require(source.testzip() is None and target.testzip() is None, f'CRC do {kind} inválido.')
            packs[kind] = source, target
            source_files, target_files = files(source), files(target)
            overlay = {**manifest['arquivos'][kind], **spec[kind]['arquivos']}
            require(target_files == source_files | set(overlay), f'Entradas do {kind} diferem do manifesto.')
            changed = []
            for path in sorted(target_files):
                new_data = target.read(path)
                old_data = source.read(path) if path in source_files else None
                require(new_data == (checked_file(ROOT, overlay[path]) if path in overlay else old_data), f'Diferença em {kind}/{path}.')
                if new_data != old_data:
                    changed.append(path)
            require(set(changed) <= set(overlay), f'Alterações do {kind} fora do escopo.')
            prior = previous[kind][1]
            config = current[kind][1]
            require(config['header']['uuid'] == uuid and config['header']['version'] == manifest['versao'], f'UUID ou versão no {kind}.')
            require(config['header']['min_engine_version'] == prior['header']['min_engine_version'], f'Versão mínima {kind} alterada.')
            for original_module, module in zip(prior['modules'], config['modules']):
                require(module['uuid'] == original_module['uuid'], f'UUID de módulo {kind} alterado.')
                require(module['version'] == manifest['versao'], f'Módulo {kind} sem atualização de versão.')
            for dep in config.get('dependencies', []):
                if dep.get('uuid') in PACK_UUIDS.values():
                    require(dep['version'] == manifest['versao'], f'Dependência {kind} sem atualização.')
            report[kind] = {'total': len(target_files), 'alterados': changed, 'identicos': len(target_files) - len(changed)}

        old_bp, bp = packs['BP']
        old_rp, rp = packs['RP']
        before, after = [remove_hozuki_bindings(read(pack, PLAYER)) for pack in (old_rp, rp)]
        require(before == after, 'O RP do jogador tem alteração fora dos modos Hōzuki.')
        for path in (VANILLA_BODY, SWBR_BODY):
            require(read(rp, path) == body_visibility(read(old_rp, path), path), f'Máscaras divergentes em {path}.')
        actor = read(rp, PLAYER)['minecraft:client_entity']['description']
        require(actor['materials']['swbr_hozuki_agua'] == 'entity_alphablend', 'Material de água sem blend.')
        controllers = read(rp, 'render_controllers/swbr_hozuki.json')['render_controllers']
        changed_vfx = bp.read(VISUALS)
        old_vfx = old_bp.read(VISUALS)
        expected_vfx = patch_ambient_effect(old_vfx) if VISUALS in spec['BP']['arquivos'] else old_vfx
        allowed_bp = {'manifest.json'} | ({VISUALS} if expected_vfx != old_vfx else set())
        require(set(report['BP']['alterados']) == allowed_bp, 'O BP tem alterações fora do manifesto e dos efeitos de equipar.')
        require(changed_vfx == expected_vfx, 'Partículas alheias alteradas.')
        subprocess.run(['node', '--input-type=module', '--check'], input=changed_vfx, check=True)
        for mode, item_path in zip(MODES, ('items/modo_hozuki.json', 'items/nz_hozuki1.json', 'items/nz_hozuki2.json')):
            item = read(bp, item_path)['minecraft:item']
            require(item['description']['identifier'] == mode.item, f'ID em {item_path}.')
            require(item['components']['minecraft:wearable']['slot'] == manifest['slot'], f'Slot em {item_path}.')
            for path in manifest['modos'][mode.key]['attachables']:
                initial, updated = [read(p, path)['minecraft:attachable']['description'] for p in (old_rp, rp)]
                require(initial['identifier'] == updated['identifier'], f'Attachable alterou o ID {path}.')
                require(initial.get('item') == updated.get('item') and 'animations' not in updated, f'Vínculo inválido {path}.')
                require(updated['geometry']['default'] == SLOT, f'Attachable não aponta para a geometria de slot {path}.')
            require(actor['animations']['swbr_hozuki_' + mode.key + '_fluxo'] == mode.animation, 'Animação do jogador não resolvida.')
            require(actor['textures']['swbr_hozuki_' + mode.key] == mode.texture and mode.texture + '.png' in files(rp),
                    'Textura do jogador não resolvida.')
            animation_data = read(rp, mode.animation_path)
            require(mode.animation in animation_data['animations'], 'ID de animação ausente.')
            for layer, path in manifest['modos'][mode.key]['camadas'].items():
                runtime = read(rp, path)['minecraft:geometry'][0]['description']['identifier']
                alias = f'swbr_hozuki_{mode.key}_{layer}'
                require(actor['geometry'][alias] == runtime, 'Camada de jogador sem geometria.')
                render = controllers[f'controller.render.swbr.hozuki.{mode.key}.{layer}']
                require(render['geometry'] == 'Geometry.' + alias and render['textures'] == ['Texture.swbr_hozuki_' + mode.key]
                        and render['materials'] == [{'*': 'Material.swbr_hozuki_agua'}] and 'color' not in render,
                        'Camada de água com textura, material ou opacidade divergente.')
        native_before = read(old_rp, COLLISION_RIG)['minecraft:geometry'][0]['bones']
        native_after = read(rp, COLLISION_RIG)['minecraft:geometry'][0]['bones']
        require(native_before == native_after, 'Alteração do rig nativo.')
        require(bp.read('scripts/rp_v158_8_immersive_expansion.js') == old_bp.read('scripts/rp_v158_8_immersive_expansion.js'), 'Suika alterado.')
        require(bp.read('items/jutsu_hozuki.json') == old_bp.read('items/jutsu_hozuki.json'), 'Item Suika alterado.')
        report['poses'] = pose_audit(rp)
    return key, report


def rotation(angles):
    x, y, z = (-radians(angles[0]), radians(angles[1]), -radians(angles[2]))
    cx, sx, cy, sy, cz, sz = cos(x), sin(x), cos(y), sin(y), cos(z), sin(z)
    return np.array(((cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx),
                     (sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx), (-sy, cy * sx, cy * cx)))


def sample(channel, t):
    if isinstance(channel, list):
        return np.array(channel, dtype=float)
    seq = sorted((float(key), np.array(val, dtype=float)) for key, val in channel.items())
    if t <= seq[0][0]:
        return seq[0][1]
    for (a, p), (b, q) in zip(seq, seq[1:]):
        if t <= b:
            return p + (q - p) * (t - a) / (b - a)
    return seq[-1][1]


def all_transforms(bones, native, time, action, pose_time):
    matrices = {}
    for bone in bones:
        name, pivot = bone['name'], np.array(bone['pivot'])
        tracks = native.get(name, {})
        at = time
        if name in action:
            tracks, at = action[name], pose_time
        scale = sample(tracks.get('scale', [1, 1, 1]), at)
        shift = sample(tracks.get('position', [0, 0, 0]), at)
        rot = rotation(sample(tracks.get('rotation', [0, 0, 0]), at)) * scale
        translation = pivot + shift - rot @ pivot
        if 'parent' in bone:
            inherited, offset = matrices[bone['parent']]
            translation = inherited @ translation + offset
            rot = inherited @ rot
        matrices[name] = rot, translation
    return matrices


def pose_audit(pack):
    native = read(pack, COLLISION_RIG)['minecraft:geometry'][0]['bones']
    base_lookup = {bone['name']: bone for bone in native}
    standing = {b[0] for b in RIG}
    table = read(pack, 'animations/player.json')['animations']
    corrida = read(pack, 'animations/correndo.json')['animations']['animation.player_new.correndo']
    poses = {'repouso': {'animation_length': 0, 'bones': {}}, 'caminhada': table['animation.player_new.andando'],
             'corrida': corrida, 'salto': table['animation.player_new.pulo'], 'combate': table['animation.player_new.soco']}
    report = {}
    models = [create_model(mode) for mode in MODES]
    for name, action in poses.items():
        count = 0
        for t in np.linspace(0.0, action['animation_length'], 9):
            for model in models:
                transforms = all_transforms(model.bones, model.motion, model.mode.length * .37, action['bones'], t)
                for bone in model.bones:
                    parent = bone.get('parent')
                    if parent not in standing or bone['name'] in standing:
                        continue
                    source = base_lookup[parent]['cubes'][0]
                    root = np.array(bone['pivot'])
                    position = transforms[parent][0] @ root + transforms[parent][1]
                    pivot_move = transforms[bone['name']][0] @ root + transforms[bone['name']][1]
                    require(np.linalg.norm(position - pivot_move) < .65, f'Pivô deslocado: {bone["name"]}/{name}.')
                    local = np.linalg.solve(transforms[parent][0], pivot_move - transforms[parent][1])
                    min_point = np.array(source['origin']) - .70
                    max_point = np.array(source['origin']) + np.array(source['size']) + .70
                    require(np.all((local >= min_point) & (local <= max_point)), f'Âncora fora do corpo: {bone["name"]}/{name}.')
                    count += 1
        report[name] = {'quadros': 9, 'ancoras': count}
    return report


class Projection:
    def __init__(self, axes, sign, skin):
        self.axes = axes
        self.sign = sign
        self.grid = 3
        self.width = 108
        self.height = 132
        self.base_x = self.width / 2
        self.base_y = 9
        self.transmittance = np.ones((self.height, self.width), dtype=float)
        self.opaque_depth = np.full_like(self.transmittance, np.inf)
        self.visible_faces = 0
        horizontal, vertical = axes
        unshown = 2 if horizontal == 0 else 0
        gx = (np.arange(self.width) + .5 - self.base_x) / self.grid
        gy = (np.arange(self.height) + .5 - self.base_y) / self.grid
        for box in skin:
            base, end = np.array(box['origin']), np.array(box['origin']) + np.array(box['size'])
            x = (gx >= base[horizontal]) & (gx <= end[horizontal])
            y = (gy >= base[vertical]) & (gy <= end[vertical])
            region = y[:, None] & x[None, :]
            depth = min(base[unshown] * sign, end[unshown] * sign)
            self.opaque_depth[region] = np.minimum(depth, self.opaque_depth[region])

    def draw(self, points, texture, uv, uv_size):
        horizontal, vertical = self.axes
        unshown = 2 if horizontal == 0 else 0
        normal = np.cross(points[1] - points[0], points[2] - points[0])
        # A face north usa o negativo do produto vetorial.
        if normal[unshown] * self.sign <= .00001:
            return
        pixels = points[:, [horizontal, vertical]] * self.grid + (self.base_x, self.base_y)
        b, x, y = pixels
        a = np.column_stack((x - b, y - b))
        if abs(np.linalg.det(a)) < .0001:
            return
        half_x, half_y = (min(np.min(pixels[:, i]), (x + y - b)[i]) for i in (0, 1))
        max_x, max_y = (max(np.max(pixels[:, i]), (x + y - b)[i]) for i in (0, 1))
        x0, x1 = max(0, int(np.floor(half_x))), min(self.width, int(np.ceil(max_x)))
        y0, y1 = max(0, int(np.floor(half_y))), min(self.height, int(np.ceil(max_y)))
        if x0 >= x1 or y0 >= y1:
            return
        yy, xx = np.mgrid[y0:y1, x0:x1]
        samples = np.stack((xx + .5 - b[0], yy + .5 - b[1]))
        coeff = np.einsum('ij,jyx->iyx', np.linalg.inv(a), samples)
        u, v = coeff
        inside = (u >= 0) & (u < 1) & (v >= 0) & (v < 1)
        depths = points[:, unshown] * self.sign
        depth = depths[0] + u * (depths[1] - depths[0]) + v * (depths[2] - depths[0])
        inside &= depth < self.opaque_depth[y0:y1, x0:x1]
        if not np.any(inside):
            return
        tx = np.clip((uv[0] + u * uv_size[0]).astype(int), 0, SIZE - 1)
        ty = np.clip((uv[1] + (1 - v) * uv_size[1]).astype(int), 0, SIZE - 1)
        patch = np.where(inside, texture[ty, tx] / 255, 0)
        self.transmittance[y0:y1, x0:x1] *= 1 - patch
        self.visible_faces += 1

    def summary(self, label):
        coverage = 1 - self.transmittance
        y, x = np.nonzero(coverage > .075)
        require(len(x) > 95, 'Projeção sem volume de água suficiente.')
        p50, p95 = np.percentile(coverage[y, x], (50, 95))
        require(.24 < p50 < .93 and .36 < p95 < .995, f'Alfa acumulado em {label}: {p50:.3f}/{p95:.3f}.')
        return {'faces': self.visible_faces, 'amostras_cobertas': int(len(x)), 'alfa_mediano': round(p50, 3), 'alfa_p95': round(p95, 3),
                'dimensoes_blocos': [round((int(np.ptp(x)) + 1) / (16 * self.grid), 3),
                                     round((int(np.ptp(y)) + 1) / (16 * self.grid), 3)]}

    def alpha_at(self, horizontal, vertical, radius=1):
        x = round(self.base_x + horizontal * self.grid)
        y = round(self.base_y + vertical * self.grid)
        return 1 - float(np.mean(self.transmittance[y-radius:y+radius+1, x-radius:x+radius+1]))


def inspect_views(model, texture, skin):
    views = {'frente': ((0, 1), 1), 'costas': ((0, 1), -1), 'perfil_direito': ((2, 1), 1), 'perfil_esquerdo': ((2, 1), -1)}
    report = {name: [] for name in views}
    for ratio in (.02, .18, .28, .51, .74, .91):
        time = model.mode.length * ratio
        matrices = all_transforms(model.bones, model.motion, time, {}, 0)
        images = {name: Projection(*axis, skin) for name, axis in views.items()}
        for bone in model.bones:
            mat, shift = matrices[bone['name']]
            for cube in bone.get('cubes', []):
                origin, pivot = np.array(cube['origin']), np.array(cube['pivot'])
                width, height, _ = cube['size']
                local = np.array((origin, origin + (width, 0, 0), origin + (0, height, 0)))
                turned = (local - pivot) @ rotation(cube['rotation']).T + pivot
                points = turned @ mat.T + shift
                face = cube['uv']['north']
                for screen in images.values():
                    screen.draw(points, texture, face['uv'], face['uv_size'])
        for name, screen in images.items():
            row = screen.summary(f'{model.mode.key}/{name}/{time:.2f}s')
            row['tempo'] = round(time, 3)
            if name in ('frente', 'costas'):
                if model.mode.key == 'hidrico':
                    require(min(screen.alpha_at(side * 6.2, 15.4) for side in (-1, 1)) > .25,
                            'Liquefação dos antebraços pouco visível.')
                    require(screen.alpha_at(0, 17.0) < .08, 'Corpo Hídrico cobriu o centro do tronco.')
                if model.mode.key == 'hand':
                    require(screen.alpha_at(-9.3, 15.1) > .52, 'Volume do Grande Braço pouco visível.')
                    require(screen.alpha_at(0, 17) < .07, 'Água Hand cobriu o tronco.')
                if model.mode.key == 'gigante':
                    require(screen.alpha_at(0, 20) > .53, 'Tronco gigante sem massa de água.')
                    require(screen.alpha_at(0, 4) < .15, 'As duas pernas perderam a separação.')
                    if name == 'frente':
                        require(.10 < screen.alpha_at(0, 28.5) < .60, 'Película no rosto ausente ou opaca.')
            report[name].append(row)
    return report


def audit_models(manifest, skin):
    rp = ROOT / 'Integracao/RP'
    summary = {}
    for mode in MODES:
        spec = manifest['modos'][mode.key]
        model = create_model(mode)
        master = read_disk(rp / spec['arquivo_geo'])
        require(master == model.document(), 'Modelo do pack diverge da fonte.')
        animation = read_disk(rp / spec['arquivo_anim'])
        require(animation == model.animation(), 'Animação do pack diverge da fonte.')
        for layer in LAYERS:
            require(read_disk(rp / spec['camadas'][layer]) == model.document(layer), 'Divisão de camadas incorreta.')
        names = {bone['name'] for bone in model.bones}
        require(len(names) == spec['bones'] and spec['cubos'] <= 500, 'Quantidade de faces ou bones inválida.')
        for bone in model.bones:
            require(bone.get('parent', bone['name']) in names, 'Bone sem pai no modelo.')
            for cube in bone.get('cubes', []):
                require(min(cube['size']) > 0 and set(cube['uv']) == {'north'}, 'Face degenerada ou duplicada.')
                data = cube['uv']['north']
                require(all(0 <= start <= SIZE and 0 <= start + span <= SIZE for start, span in zip(data['uv'], data['uv_size'])), 'UV fora da textura.')
        for bone, channels in model.motion.items():
            require(bone in names and bone not in {item[0] for item in RIG}, 'Animação alterou o rig humano.')
            for channel, frames in channels.items():
                times = sorted(map(float, frames))
                require(times[0] == 0 and times[-1] == mode.length, 'Ciclo incompleto.')
                require(np.allclose(sample(frames, times[0]), sample(frames, times[-1])), 'Corte entre ciclos.')
                if channel == 'scale':
                    require(all(0 < v < 1.25 for coord in frames.values() for v in coord), 'Escala fora do limite visual.')
            if '_gota_' in bone:
                require(min(coord[1] for coord in channels['position'].values()) < -2.0, 'Gota sem queda.')
                require(max(sample(channels['scale'], 0)) < .01 and max(sample(channels['scale'], mode.length)) < .01, 'Gota não some.')
        tex_path = rp / spec['textura']
        with Image.open(tex_path) as png:
            require(png.mode == 'RGBA' and png.size == (SIZE, SIZE), 'Atlas inválido.')
            lowest, highest = png.getchannel('A').getextrema()
            require(lowest == 0 and 180 < highest < 245 and np.array_equal(np.asarray(png), np.asarray(atlas(mode.number))),
                    'Alfa/atlas inválido.')
            masked = () if mode.number == 1 else (RIGHT_ARM if mode.number == 2 else RIGHT_ARM + TORSO_AND_LIMBS)
            visible_skin = [cube for name, cubes in skin.items() if name not in masked for cube in cubes]
            views = inspect_views(model, np.asarray(png)[:, :, 3], visible_skin)
        project = read_disk(ROOT / 'Modelos_Blockbench' / spec['projeto'])
        require(project['meta']['model_format'] == 'bedrock' and len(project['elements']) == spec['cubos'], 'Projeto Blockbench incompleto.')
        require(len(project['animations']) == 1 and project['animations'][0]['name'] == mode.animation, 'Projeto perdeu a animação.')
        require(base64.b64decode(project['textures'][0]['source'].split(',', 1)[1]) == tex_path.read_bytes(), 'Projeto contém outra textura.')
        summary[mode.key] = {'faces': spec['faces_por_camada'], 'canais': len(model.motion), 'projecoes': views}
    for view in ('frente', 'costas'):
        for partial, hand, giant in zip(*(row['projecoes'][view] for row in summary.values())):
            small, medium, large = [row['dimensoes_blocos'] for row in (partial, hand, giant)]
            require(small[0] < 1.2 and medium[0] - small[0] > .22 and large[0] - medium[0] > .23
                    and large[1] > 2.32, f'Silhuetas pouco diferenciadas em {view}.')
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    parser.add_argument('--cumulativa-18-11-73', type=Path)
    args = parser.parse_args()
    manifest = read_disk(ROOT / 'Integracao_Manifesto.json')
    with ZipFile(io.BytesIO(open_packs(args.original)['RP'][2])) as pack:
        bones = read(pack, COLLISION_RIG)['minecraft:geometry'][0]['bones']
        skin = {b['name']: b.get('cubes', []) for b in bones if b['name'] in {item[0] for item in RIG}}
    report = {'minecraft_executado': False, 'geometrias_e_projecoes': audit_models(manifest, skin), 'bases': {}}
    for mode, info in report['geometrias_e_projecoes'].items():
        print(mode, {key: states[0] for key, states in info['projecoes'].items()})
    for base, result in ((args.original, 'Hozuki.mcaddon'), (args.cumulativa, 'Hozuki_Cumulativo.mcaddon'),
                         (args.cumulativa_18_11_73, 'Hozuki_Cumulativo.mcaddon')):
        if base is not None:
            key, audit = audit_addon(base, ROOT / result, manifest)
            report['bases'][key] = audit
            print(key, {kind: report['bases'][key][kind]['identicos'] for kind in PACK_UUIDS})
    write_json(ROOT / 'Validacao.json', report)


if __name__ == '__main__':
    main()
