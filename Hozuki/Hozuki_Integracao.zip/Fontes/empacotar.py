#!/usr/bin/env python3
"""Embala a entrega Hōzuki e verifica as duas integrações a partir do ZIP."""

import argparse
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZIP_STORED, ZipFile

from aplicar_integracao import ROOT, sha256, zip_item


def write_zip(destination, names):
    with ZipFile(destination, 'w') as archive:
        for name in names:
            meta = zip_item(name)
            if name.endswith(('.mcaddon', '.zip')):
                meta.compress_type = ZIP_STORED
            archive.writestr(meta, (ROOT / name).read_bytes())
    with ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == names
        for name in names:
            assert archive.read(name) == (ROOT / name).read_bytes(), name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path, help='Hozuki.mcaddon 18.11.75')
    parser.add_argument('cumulativa', type=Path, help='Hozuki_Cumulativo.mcaddon 18.11.75')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'Integracao_Manifesto.json').read_text())
    assert len(manifest['modos']) == 3
    filenames = ['LEIA-ME.md', 'Integracao_Manifesto.json', 'Validacao.json',
                 'Validacao_Blockbench.json', 'Validacao_Molang.json']
    for directory in ('Integracao', 'Fontes'):
        filenames.extend(sorted(file.relative_to(ROOT).as_posix() for file in (ROOT / directory).rglob('*')
                                if file.is_file() and '__pycache__' not in file.parts))
    integration_name = 'Hozuki_Integracao.zip'
    write_zip(ROOT / integration_name, filenames)
    projects = ['Modelos_Blockbench/' + spec['projeto'] for spec in manifest['modos'].values()]
    write_zip(ROOT / 'Hozuki.zip', ['LEIA-ME.md', 'Hozuki.mcaddon', integration_name, *projects])
    with tempfile.TemporaryDirectory(prefix='hozuki-integracao-') as folder:
        dest = Path(folder)
        with ZipFile(ROOT / 'Hozuki.zip') as outer, ZipFile(io.BytesIO(outer.read(integration_name))) as overlay:
            overlay.extractall(dest)
        for base, expected in ((args.original, 'Hozuki.mcaddon'), (args.cumulativa, 'Hozuki_Cumulativo.mcaddon')):
            output = dest / expected
            subprocess.run([sys.executable, str(dest / 'Fontes/aplicar_integracao.py'), str(base.resolve()), str(output)], check=True)
            assert sha256(output.read_bytes()) == sha256((ROOT / expected).read_bytes()), expected
    for name in ('Hozuki.mcaddon', 'Hozuki_Cumulativo.mcaddon', integration_name, 'Hozuki.zip'):
        content = (ROOT / name).read_bytes()
        print(f'{name}: {len(content):,} bytes · SHA-256 {sha256(content)}')


if __name__ == '__main__':
    main()
