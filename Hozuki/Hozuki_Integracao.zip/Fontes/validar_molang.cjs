/* Simula o render por slot, troca de item e estados de câmera em ambas as bases. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
if (!process.env.HOZUKI_MOLANG_MODULE) throw Error('Informe HOZUKI_MOLANG_MODULE com o lib/molang.umd.js do Blockbench.');
const Molang = require(process.env.HOZUKI_MOLANG_MODULE);
const parser = new Molang();
const root = path.resolve(__dirname, '..');
const read = file => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
const manifest = read('Integracao_Manifesto.json');
const modes = Object.entries(manifest.modos);
const prefix = 'v.swbr_hozuki_';
const activeRange = [0, 2.0, 2.24, 2.62];
const report = {};
const views = [
  {}, { first: 1 }, { ui: 1 }, { paper: 1 }, { map: 1 }, { spectator: 1 }, { invisible: 1 },
  { first: 1, ui: 1 },
];

for (const base of Object.keys(manifest.bases)) {
  const player = read(`Integracao/Versoes/${base}/RP/entity/player.entity.json`)['minecraft:client_entity'].description;
  const nativeVars = ['v.swbr39_ui', 'v.swbr_view_first_person', 'v.swbr_view_map_face'];
  const code = player.scripts.pre_animation.filter(line => line.startsWith(prefix) || nativeVars.some(v => line.startsWith(v + ' =')));
  assert.equal(code.length, 7, 'variáveis da câmera');
  const renders = Object.assign({}, ...player.render_controllers.filter(s => typeof s === 'object'));
  const anims = Object.assign({}, ...player.scripts.animate.filter(s => typeof s === 'object'));
  let total = 0;
  for (const view of views) {
    for (const inventory of ['minecraft:air', ...modes.map(([, info]) => info.id), 'nz:kaguya_bracken_dance']) {
      const idx = modes.findIndex(([, info]) => info.id === inventory) + 1;
      for (const distance of [.4, 1.6, 1.99, 2, 2.14, 2.24, 2.4, 2.62, 2.83, 3.1, 4, 16]) {
        const world = !view.first && !view.ui && !view.paper && !view.map && !view.spectator && !view.invisible;
        const expected = idx > 0 && world ? Math.min(1, Math.max(0, (distance - activeRange[idx]) / .42)) : 0;
        const env = item => ({
          'variable.is_first_person': view.first || 0, 'variable.is_paperdoll': view.paper || 0,
          'variable.map_face_icon': view.map || 0, 'variable.swbr_hozuki_stage': 3, 'variable.swbr_hozuki_fade': 1,
          'query.is_spectator': view.spectator || 0, 'query.is_in_ui': view.ui || 0, 'query.is_invisible': view.invisible || 0,
          'query.distance_from_camera': distance,
          'query.is_item_name_any': (slot, i, ...items) => Number(slot === 'slot.armor.head' && i === 0 && items.includes(item)),
        });
        const program = code.join('');
        const evaluate = (expression, item = inventory) => parser.parse(program + `return ${expression};`, env(item));
        assert.equal(evaluate('v.swbr_hozuki_stage'), idx);
        assert.ok(Math.abs(evaluate('v.swbr_hozuki_fade') - expected) < 1e-7);
        let draws = 0, loops = 0;
        for (const [i, [key]] of modes.entries()) {
          const enabled = i + 1 === idx && expected > 0;
          for (const layer of ['core', 'surface']) {
            const gate = renders[`controller.render.swbr.hozuki.${key}.${layer}`];
            assert.equal(Boolean(evaluate(gate)), enabled);
            draws += Number(Boolean(evaluate(gate)));
          }
          const animate = evaluate(anims[`swbr_hozuki_${key}_fluxo`]);
          assert.equal(Boolean(animate), enabled);
          loops += Number(Boolean(animate));
        }
        assert.equal(draws, expected > 0 ? 2 : 0);
        assert.equal(loops, expected > 0 ? 1 : 0);
        assert.equal(evaluate('v.swbr_hozuki_fade', 'minecraft:air'), 0);
        assert.equal(evaluate('v.swbr_hozuki_stage', 'minecraft:air'), 0);
        total++;
      }
    }
  }
  report[base] = { contextos: total, retirada_imediata_simulada: total };
}

fs.writeFileSync(path.join(root, 'Validacao_Molang.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
