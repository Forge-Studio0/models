/* Exercita os controladores reais de água e de pele com o parser MoLang do Blockbench. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
if (!process.env.HOZUKI_MOLANG_MODULE) throw Error('Informe HOZUKI_MOLANG_MODULE com o lib/molang.umd.js do Blockbench.');
const Molang = require(process.env.HOZUKI_MOLANG_MODULE);
const parser = new Molang();
const root = path.resolve(__dirname, '..');
const read = file => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
const manifest = read('Integracao_Manifesto.json');
const modes = Object.entries(manifest.modos);
const prefix = 'v.swbr_hozuki_';
const report = {};
const views = [
  {}, { first: 1 }, { ui: 1 }, { paper: 1 }, { map: 1 }, { spectator: 1 }, { invisible: 1 },
  { first: 1, ui: 1 }, { douma: 1 }, { ape: 1, drawApe: 1 }, { ape: 1 },
  { vast: 1 }, { fullBody: 1 }, { chest: 'nz:modo_sukuna_admin' },
  { chest: 'nz:modo_otsutsuki_pcd_admin' }, { chest: 'minecraft:iron_chestplate' },
];
const nativeVars = ['v.swbr39_ui', 'v.swbr_view_first_person', 'v.swbr_view_map_face'];

function checkBodyMasks(doc, select, arm, torso) {
  const controllers = Object.values(doc.render_controllers).filter(select);
  assert.ok(controllers.length > 0, 'controladores de pele');
  const masks = controllers.map(controller => Object.assign({}, ...controller.part_visibility));
  const expected = ['*', ...arm, ...torso].sort();
  for (const bones of masks) assert.deepEqual(Object.keys(bones).sort(), expected, 'partes substituídas');
  return masks;
}

for (const [base, spec] of Object.entries(manifest.bases)) {
  if (!base.startsWith('18.11.74-')) continue;
  const entry = name => read(spec.packs.RP.arquivos[name].arquivo);
  const player = entry('entity/player.entity.json')['minecraft:client_entity'].description;
  const code = player.scripts.pre_animation.filter(line => line.startsWith(prefix) ||
    nativeVars.some(v => line.startsWith(v + ' =')));
  assert.equal(code.length, 5, 'variáveis da câmera');
  assert.ok(!code.join('').includes('distance_from_camera'), 'o zoom não regula a opacidade');
  const renders = Object.assign({}, ...player.render_controllers.filter(s => typeof s === 'object'));
  const anims = Object.assign({}, ...player.scripts.animate.filter(s => typeof s === 'object'));
  const vanilla = entry('render_controllers/player.json').render_controllers;
  const swbr = entry('render_controllers/nzs_body_v1875.render_controllers.json');
  const vanillaMasks = checkBodyMasks(
    { render_controllers: { body: vanilla['controller.render.player.third_person'] } }, () => true,
    ['rightArm', 'rightSleeve'], ['body', 'leftArm', 'rightLeg', 'leftLeg', 'leftSleeve', 'jacket', 'rightPants', 'leftPants']);
  const swbrMasks = checkBodyMasks(swbr, c => c.geometry === 'Geometry.custom',
    ['rightArm'], ['body', 'leftArm', 'rightLeg', 'leftLeg']);
  for (const c of Object.values(swbr.render_controllers).filter(c => c.geometry === 'Geometry.custom_b')) {
    assert.ok(!JSON.stringify(c).includes(prefix), 'controlador de primeira pessoa alterado');
  }
  // Cada expressão de máscara é igual para as 44 peles do SWBR.
  for (const mask of swbrMasks) assert.deepEqual(mask, swbrMasks[0]);
  const masks = [...vanillaMasks, swbrMasks[0]];
  let total = 0;
  for (const view of views) {
    for (const inventory of ['minecraft:air', ...modes.map(([, info]) => info.id), 'nz:kaguya_bracken_dance']) {
      const idx = modes.findIndex(([, info]) => info.id === inventory) + 1;
      const blockedChest = ['nz:modo_sukuna_admin', 'nz:modo_otsutsuki_pcd_admin'].includes(view.chest);
      const world = !(view.first || view.ui || view.paper || view.map || view.spectator || view.invisible ||
        view.douma || (view.ape && view.drawApe) || view.vast || view.fullBody || blockedChest);
      for (const distance of [.4, 1.6, 2.24, 2.62, 3.04, 4, 16]) {
        const env = (item, skin = 0) => ({
          'variable.is_first_person': view.first || 0, 'variable.is_paperdoll': view.paper || 0,
          'variable.map_face_icon': view.map || 0, 'variable.swbr_hozuki_stage': 3,
          'variable.swbr_douma14': view.douma || 0, 'variable.swbr_v1878_ape': view.ape || 0,
          'variable.swbr_v1878_draw': view.drawApe || 0, 'variable.nzs_vast_bleach': view.vast || 0,
          'variable.swbr_v18733_full_body': view.fullBody || 0,
          'query.is_spectator': view.spectator || 0, 'query.is_in_ui': view.ui || 0,
          'query.is_invisible': view.invisible || 0, 'query.distance_from_camera': distance,
          'query.property': name => name === 'test:custom' ? skin : 0,
          'query.is_item_name_any': (slot, i, ...items) => Number(i === 0 &&
            items.includes(slot === 'slot.armor.head' ? item : view.chest)),
        });
        const program = code.join('');
        const evaluate = (expression, item = inventory, skin = 0) =>
          parser.parse(program + `return ${expression};`, env(item, skin));
        assert.equal(evaluate('v.swbr_hozuki_stage'), idx);
        assert.equal(Boolean(evaluate('v.swbr_hozuki_world')), world);
        for (const [i, [key]] of modes.entries()) {
          const enabled = world && i + 1 === idx;
          for (const layer of ['core', 'surface']) {
            const gate = renders[`controller.render.swbr.hozuki.${key}.${layer}`];
            assert.equal(Boolean(evaluate(gate)), enabled, 'camada do modo selecionado');
            assert.equal(Boolean(evaluate(gate, 'minecraft:air')), false, 'camada removida ao desequipar');
          }
          const animation = anims[`swbr_hozuki_${key}_fluxo`];
          assert.equal(Boolean(evaluate(animation)), enabled);
          assert.equal(Boolean(evaluate(animation, 'minecraft:air')), false);
        }
        for (const [skin, bones] of masks.entries()) {
          const visible = Boolean(evaluate(bones['*'], inventory, skin));
          for (const [bone, mask] of Object.entries(bones)) {
            if (bone === '*') continue;
            const threshold = ['rightArm', 'rightSleeve'].includes(bone) ? 2 : 3;
            assert.equal(Boolean(evaluate(mask, inventory, skin)), visible && !(world && idx >= threshold), bone);
            assert.equal(Boolean(evaluate(mask, 'minecraft:air', skin)), visible, `${bone} restaurado`);
          }
        }
        total++;
      }
    }
  }
  report[base] = { contextos: total, retirada_imediata_simulada: total, controladores_de_pele: swbrMasks.length + vanillaMasks.length };
}

fs.writeFileSync(path.join(root, 'Validacao_Molang.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
