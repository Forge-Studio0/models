"""Volumes, textura RGBA e animações de água do clã Hōzuki."""

from dataclasses import dataclass
from math import asin, atan2, cos, degrees, pi, sin, sqrt

import numpy as np
from PIL import Image


SIZE = 1024
TILE = 44
MARGIN = 4
TILE_UV = TILE - 2 * MARGIN
RIG = (
    ('root', None, (0, 0, 0)), ('waist', 'root', (0, 12, 0)),
    ('body', 'waist', (0, 24, 0)), ('head', 'body', (0, 24, 0)),
    ('rightArm', 'body', (-5, 22, 0)), ('leftArm', 'body', (5, 22, 0)),
    ('rightLeg', 'root', (-1.9, 12, 0)), ('leftLeg', 'root', (1.9, 12, 0)),
)


@dataclass(frozen=True)
class Modo:
    number: int
    key: str
    item: str
    name: str
    project: str
    unlock: str
    length: float

    @property
    def geometry(self):
        return f'geometry.swbr.hozuki.{self.key}'

    @property
    def animation(self):
        return f'animation.swbr.hozuki.{self.key}.fluxo'

    @property
    def texture(self):
        return f'textures/entity/swbr/hozuki/{self.key}'

    @property
    def geometry_path(self):
        return f'models/entity/swbr/hozuki/{self.key}.geo.json'

    @property
    def animation_path(self):
        return f'animations/swbr/hozuki/{self.key}.animation.json'


MODES = (
    Modo(1, 'hidrico', 'nz:modo_hozuki_hidrico', 'Corpo Hídrico', 'Hozuki_01_Corpo_Hidrico.bbmodel', '28.000 TP', 4.8),
    Modo(2, 'hand', 'nz:hozuki1', 'Água Hand', 'Hozuki_02_Agua_Hand.bbmodel', 'Nível 10', 4.4),
    Modo(3, 'gigante', 'nz:hozuki2', 'Água Gigante', 'Hozuki_03_Agua_Gigante.bbmodel', 'Nível 15', 5.6),
)


def smoothstep(value):
    value = np.clip(value, 0, 1)
    return value * value * (3 - 2 * value)


def water_color(points, rows, stage, density):
    """Pinta veios contínuos a partir da posição 3D, inclusive nas junções."""
    x, y, z = np.moveaxis(points, -1, 0)
    phase = .54 * y - .41 * x + .61 * z
    phase += .74 * np.sin(.37 * y + .81 * z) + .35 * np.cos(.58 * x - .24 * y)
    fold = .77 * x + .24 * y + .38 * z + .55 * np.sin(.49 * y - .57 * z)
    ripple = np.exp(-(np.sin(phase) / .27) ** 2)
    glint = np.exp(-(np.sin(fold) / .21) ** 2)
    glint *= .47 + .53 * (.5 + .5 * np.sin(phase))
    light = np.clip(.12 + .075 * np.sin(phase + .77) + .38 * ripple + .29 * glint, .035, .91)

    body_color = np.array((26, 148, 184))
    alpha = (.58, .74, .68)[stage - 1]
    if density == 'deep':
        body_color = np.array((23, 115, 154))
        alpha = .31
    elif density == 'drop':
        body_color = np.array((66, 185, 215))
        alpha = .64
    elif stage == 3:
        profile = np.array(rows)
        cx = np.interp(y, profile[:, 1], profile[:, 0])
        rx = np.interp(y, profile[:, 1], profile[:, 3])
        alpha -= .16 * smoothstep(np.abs(x - cx) / rx)
        if density == 'face':
            cz = np.interp(y, profile[:, 1], profile[:, 2])
            alpha *= 1 - .72 * smoothstep((cz - z - 1.05) / 2.65)

    rgb = body_color + (np.array((181, 239, 249)) - body_color) * light[..., None]
    return rgb, np.clip(alpha + .026 * np.sin(phase) + .072 * light, .03, .86)


def vec(items):
    return [round(n, 5) for n in items]


def minus(a, b):
    return tuple(x - y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def unit(a):
    length = sqrt(sum(component * component for component in a))
    return tuple(component / length for component in a)


def center(*points):
    return tuple(sum(component) / len(points) for component in zip(*points))


def rotation_of(u, v, w):
    # R = Rz(-Bedrock Z) * Ry(Bedrock Y) * Rx(-Bedrock X).
    pitch = -asin(max(-1, min(1, u[2])))
    if abs(cos(pitch)) > .000001:
        roll = atan2(v[2], w[2])
        yaw = atan2(u[1], u[0])
    else:
        roll = 0
        yaw = atan2(-v[0], v[1])
    return vec((-degrees(roll), degrees(pitch), -degrees(yaw)))


def rings_for(rows, sides, seed):
    """Anéis semelhantes mantêm plana cada face entre duas alturas."""
    aspect = sum(rx * rz for _, _, _, rx, rz in rows) / sum(rx ** 2 for _, _, _, rx, _ in rows)
    offsets = []
    for side in range(sides):
        phi = 2 * pi * (side + .5) / sides
        variation = 1 + .058 * sin(3 * phi + seed) + .034 * cos(2 * phi + seed)
        offsets.append((variation * cos(phi), variation * aspect * sin(phi)))
    return [tuple((x + rx * dx, y, z + rx * dz) for dx, dz in offsets) for x, y, z, rx, _ in rows]


def loop_channels(length, phase, amount=(.042, .024, .035), slide=(.05, .14, .09), sweep=1.2):
    keys = {key: {} for key in ('scale', 'position', 'rotation')}
    for index in range(9):
        theta = phase + (index % 8) * pi / 4
        frame = f'{index * length / 8:.2f}'
        keys['scale'][frame] = vec(1 + amp * sin(theta + k * .82) for k, amp in enumerate(amount))
        keys['position'][frame] = vec(delta * sin(theta + k * 1.65) for k, delta in enumerate(slide))
        keys['rotation'][frame] = vec((sin(theta) * sweep * .58, sin(theta + 1.12) * sweep, cos(theta) * sweep * .55))
    return keys


class WaterModel:
    def __init__(self, mode):
        self.mode = mode
        self.bones = []
        self.roles = {}
        self.motion = {}
        self.panels = []
        self.pixels = np.zeros((SIZE, SIZE, 4), dtype=np.uint8)
        for name, parent, pivot in RIG:
            self.bone(name, parent, pivot, raw=True)

    def bone(self, name, parent, pivot, *, raw=False, cubes=(), role=None, channels=None):
        key = name if raw else f'hzk{self.mode.number}_{name}'
        data = {'name': key, 'pivot': vec(pivot)}
        if parent:
            data['parent'] = parent
        if cubes:
            data['cubes'] = cubes
            self.roles[key] = role
        if channels:
            self.motion[key] = channels
        self.bones.append(data)
        return key

    def wave(self, phase, **kwargs):
        return loop_channels(self.mode.length, phase, **kwargs)

    def panel(self, points, joins, feather, rows, density):
        """Recorta o polígono exato na face norte de um cubo fino."""
        pivot = np.array(center(*points))
        u = unit(minus(points[1], points[0]))
        w = unit(cross(u, minus(points[-1], points[0])))
        v = cross(w, u)
        relative = np.array(points) - pivot
        if np.max(np.abs(relative @ w)) > .00001:
            raise ValueError('Face de água fora do plano.')
        polygon = relative @ np.array([u, v]).T
        start = polygon.min(axis=0) - feather
        end = polygon.max(axis=0) + feather
        width, height = end - start

        columns = SIZE // TILE
        row, col = divmod(len(self.panels), columns)
        if row >= columns:
            raise ValueError('Atlas Hōzuki sem espaço para todas as faces.')
        uv = [col * TILE + MARGIN, row * TILE + MARGIN]
        cube = {'origin': vec((pivot[0] + start[0], pivot[1] + start[1], pivot[2])),
                'size': vec((width, height, .035)), 'pivot': vec(pivot), 'rotation': rotation_of(u, v, w),
                'uv': {'north': {'uv': uv, 'uv_size': [TILE_UV, TILE_UV]}}}

        sample = (np.arange(TILE) + .5 - MARGIN) / TILE_UV
        yy, xx = np.meshgrid(start[1] + height * (1 - sample), start[0] + width * sample, indexing='ij')
        coverage = np.ones_like(xx)
        for a, b, joined in zip(polygon, np.roll(polygon, -1, axis=0), joins):
            dx, dy = b - a
            distance = ((yy - a[1]) * dx - (xx - a[0]) * dy) / np.hypot(dx, dy)
            coverage *= smoothstep((distance + feather) / (2 * feather) if joined else distance / feather)
        samples = pivot + xx[..., None] * np.array(u) + yy[..., None] * np.array(v)
        rgb, alpha = water_color(samples, rows, self.mode.number, density)
        # A soma das contribuições de dois lados preserva a transmissão na emenda.
        alpha = 1 - (1 - alpha) ** coverage
        pixels = np.dstack((rgb, alpha * 255))
        self.pixels[row * TILE:(row + 1) * TILE, col * TILE:(col + 1) * TILE] = np.rint(pixels).astype(np.uint8)
        self.panels.append((cube, np.array(points), joins, feather))
        return cube

    def texture(self):
        return Image.fromarray(self.pixels, 'RGBA')

    def loft(self, name, parent, rows, *, sides=8, include=None, density='surface', role='surface',
             channels=None, seed=0, origin=None):
        rings = rings_for(rows, sides, seed)
        active = tuple(range(sides)) if include is None else include
        closed = include is None
        feather = min(.255, max(row[3] for row in rows) * .17)
        cubes = []
        for index, (lower, upper) in enumerate(zip(rings, rings[1:])):
            for side in active:
                nxt = (side + 1) % sides
                points = lower[side], lower[nxt], upper[nxt], upper[side]
                joins = (index > 0 or closed, nxt in active,
                         index < len(rings) - 2 or closed, (side - 1) % sides in active)
                cubes.append(self.panel(points, joins, feather, rows, density))
        if closed:
            for rim in (rings[0][::-1], rings[-1]):
                cubes.append(self.panel(rim, (True,) * sides, feather, rows, density))
        pivot = origin or (rows[-1][0], rows[-1][1], rows[-1][2])
        return self.bone(name, parent, pivot, cubes=cubes, role=role, channels=channels)

    def drop(self, name, parent, xyz, size, start, fall, outward):
        x, y, z = xyz
        rows = [(x, y - size * .72, z, .10 * size, .10 * size),
                (x, y - .26 * size, z, .50 * size, .45 * size),
                (x - .07 * outward, y + .20 * size, z, .35 * size, .32 * size),
                (x - .13 * outward, y + .68 * size, z, .07 * size, .08 * size)]
        keys = {key: {'0.00': first, f'{self.mode.length:.2f}': first} for key, first in (
            ('scale', [.001] * 3), ('position', [0] * 3), ('rotation', [0] * 3),
        )}
        frames = ((0, .001, 0, 0), (.18, .76, .025, 0), (.34, 1, .12, 4),
                  (.66, .67, .48, 10), (.95, .001, 1, 14), (1.00, .001, 0, 0))
        duration = .79 if self.mode.number < 3 else .94
        for time, scale, travel, turn in frames:
            frame = f'{start + time * duration:.2f}'
            keys['scale'][frame] = vec((max(.001, scale * .91), scale, max(.001, scale * .88)))
            keys['position'][frame] = vec((travel * outward, -travel * fall, .17 * travel))
            keys['rotation'][frame] = vec((turn * .41, turn * .32 * outward, -turn * outward))
        self.loft(name, parent, rows, sides=5, density='drop', channels=keys, origin=xyz)

    def document(self, role=None):
        bones = self.bones
        identity = self.mode.geometry
        if role:
            bones = [bone for bone in bones if bone['name'] not in self.roles or self.roles[bone['name']] == role]
            identity += '.' + role
            live = {b['name'] for b in bones}
            if any(b.get('parent', b['name']) not in live for b in bones):
                raise ValueError(f'Vínculo entre camadas em {self.mode.key}/{role}.')
        return {'format_version': '1.16.0', 'minecraft:geometry': [{
            'description': {'identifier': identity, 'texture_width': SIZE, 'texture_height': SIZE,
                            'visible_bounds_width': 4, 'visible_bounds_height': 5, 'visible_bounds_offset': [0, 1.12, 0]},
            'bones': bones,
        }]}

    def animation(self):
        return {'format_version': '1.8.0', 'animations': {self.mode.animation: {
            'loop': True, 'animation_length': self.mode.length, 'bones': self.motion,
        }}}


def scaled_rows(rows, rx, rz, shift_x=0, shift_z=0):
    return [(x + shift_x, y, z + shift_z, a * rx, b * rz) for x, y, z, a, b in rows]


def slim_arm(model, side, short=False):
    arm, label = ('rightArm', 'd') if side < 0 else ('leftArm', 'e')
    gain = .82 if short else 1
    depth = .94 if short else 1
    phase = 1.90 if side < 0 else 2.84
    root = model.bone('braco_leve_' + label, arm, (side * 6, 19.0, .18), channels=model.wave(phase,
                         amount=(.026, .021, .039), slide=(.026, .105, .054), sweep=.69))
    rows = [(side * 6.62, 11.67, -.02, .75 * gain, 1.07 * depth),
            (side * 6.19, 13.04, -.05, 2.28 * gain, 2.67 * depth),
            (side * 6.30, 15.45, .10 * side, 2.43 * gain, 2.89 * depth),
            (side * 6.29, 17.82, .14 * side, 2.18 * gain, 2.72 * depth)]
    if short:
        rows.append((side * 6.23, 19.54, -.12, 1.28 * gain, 1.68 * depth))
    else:
        rows.extend([
            (side * 6.43, 19.85, -.05, 2.10, 2.54),
            (side * 6.64, 21.58, -.10, 2.12, 2.59),
            (side * 6.50, 23.13, -.06, 2.09, 2.54),
            (side * 6.40, 24.08, .14, .45, .58),
        ])
    # Abertura voltada para o tronco, acompanhando o mesmo braço do pulso ao ombro.
    traces = (1, 2, 3, 4, 5) if side < 0 else (5, 6, 7, 0, 1)
    model.loft('antebraco_' + label, root, rows, include=traces, seed=phase)
    model.loft('filete_interno_' + label, root, scaled_rows(rows[1:4], .91, .83, side * .37),
               include=(3, 4) if side < 0 else (7, 0), seed=phase, density='deep', role='core')
    model.drop('gota_punho_' + label, root, (side * (7.65 if not short else 7.31), 12.40, -.85),
               .64 if not short else .49, .28 + phase * .26, 3.6, side * .62)
    if not short:
        model.drop('gota_dedos_' + label, root, (side * 6.26, 12.03, -1.13), .43, 2.89 - phase * .17, 2.86, side * .43)


def hidrification(model):
    for side in (-1, 1):
        slim_arm(model, side)
        label = 'd' if side < 0 else 'e'
        phase = .85 if side < 0 else 3.18
        rows = [(side * 3.61, 13.42 + .31 * side, 1.39, .24, .29),
                (side * 3.42, 15.92, .29, 1.05, 2.48), (side * 3.11, 18.31 - .17 * side, -.12, 1.17, 3.10),
                (side * 3.27, 20.64 + .29 * side, -.54, .91, 2.55), (side * 3.05, 22.39, -1.46, .37, .74)]
        model.loft('faixa_costal_' + label, 'body', rows, sides=8,
                   include=(1, 2, 3, 4, 5) if side < 0 else (5, 6, 7, 0, 1),
                   seed=phase, channels=model.wave(phase, amount=(.024, .032, .046), slide=(.04, .13, .034), sweep=1.1))


def fingers(model, base, side, palm_x, y, z, factor):
    for i, (offset, length, width) in enumerate(((-1.75, 1.54, .48), (-.59, 2.01, .55),
                                                (.58, 2.19, .59), (1.86, 1.72, .53))):
        x = palm_x + side * offset * factor
        y0 = y + (.16 if i in (0, 3) else 0)
        z0 = z + (.17 - .13 * i) * factor
        spread = side * (i - 1.45) * .19 * factor
        rows = [(x + spread, y0 - length * factor, z0 - .36 * factor, width * .47 * factor, width * .41 * factor),
                (x + spread * .48, y0 - length * .70 * factor, z0 - .33 * factor, width * .94 * factor, width * .84 * factor),
                (x + spread * .22, y0 - length * .24 * factor, z0 - .08 * factor, width * factor, width * .91 * factor),
                (x, y0 + .71 * factor, z0 + .13 * factor, width * 1.06 * factor, width * .96 * factor)]
        model.loft(f'dedo_{i+1}_{"d" if side < 0 else "e"}', base, rows, sides=6, seed=.7 + i)
    x = palm_x - side * 2.06 * factor
    rows = [(x - side * 1.19 * factor, y - .88 * factor, z - .49 * factor, .22 * factor, .21 * factor),
            (x - side * .98 * factor, y - .21 * factor, z - .45 * factor, .55 * factor, .47 * factor),
            (x - side * .51 * factor, y + .84 * factor, z - .43 * factor, .65 * factor, .57 * factor),
            (x + side * .04 * factor, y + 1.68 * factor, z - .38 * factor, .67 * factor, .68 * factor)]
    model.loft('polegar_' + ('d' if side < 0 else 'e'), base, rows, sides=6, seed=2.6)


def hand_mode(model):
    root = model.bone('braco_ampliado', 'rightArm', (-6.04, 22, .09), channels=model.wave(.35,
                         amount=(.066, .012, .073), slide=(.094, .096, .105), sweep=.75))
    rows = [(-9.50, 9.25, -.87, 1.98, 1.25), (-9.36, 10.66, -.68, 3.33, 2.63),
            (-9.42, 12.36, -.54, 3.70, 3.15), (-9.24, 14.93, -.14, 5.08, 4.05),
            (-8.91, 17.17, .44, 4.75, 4.19), (-8.31, 19.13, .41, 3.69, 3.23),
            (-7.21, 21.03, .07, 3.10, 2.63), (-6.14, 22.74, .14, 2.50, 2.31),
            (-5.62, 24.06, .31, 1.58, 1.49), (-5.51, 24.78, .34, .23, .21)]
    model.loft('superficie_braco', root, rows, sides=10, seed=1.18)
    model.loft('massa_braco', root, scaled_rows(rows[1:-1:2], .73, .71, -.29, .16), sides=7,
               seed=2.5, density='deep', role='core', channels=model.wave(2.15, amount=(.037, .026, .039),
                                                                           slide=(.066, .37, .075), sweep=1.0))
    fingers(model, root, -1, -9.48, 10.26, -.64, 1.25)
    for name, xyz, size, start, fall, sway in (
        ('gota_cotovelo', (-13.55, 17.03, .80), .86, .44, 5.11, -1.08),
        ('gota_pulso', (-12.69, 12.45, -.56), .73, 1.76, 4.62, -.66),
        ('gota_dedo', (-10.61, 7.86, -.55), .55, 2.78, 3.41, -.63),
    ):
        model.drop(name, root, xyz, size, start, fall, sway)
    slim_arm(model, 1, short=True)


def hulk(model):
    torso = model.bone('peito_ondulante', 'body', (0, 18, .29), channels=model.wave(1.04,
                          amount=(.046, .036, .067), slide=(.12, .23, .20), sweep=1.05))
    rows = [(.08, 10.80, .29, 3.87, 2.83), (-.16, 13.39, .24, 5.26, 3.76),
            (.23, 16.42, .44, 6.08, 4.62), (-.20, 20.16, .86, 7.53, 5.82),
            (-.08, 23.16, 1.20, 8.18, 6.05), (.19, 25.62, 1.49, 6.03, 4.87),
            (.14, 27.61, 1.45, 3.51, 2.73)]
    model.loft('tronco_superficie', torso, rows, sides=8, seed=2.4)
    model.loft('tronco_fluxo_profundo', torso, scaled_rows(rows[1:-1:2], .76, .72, 0, .28), sides=7,
               density='deep', role='core', seed=.97,
               channels=model.wave(2.77, amount=(.049, .042, .068), slide=(.11, .32, .20), sweep=1.44))
    head = model.bone('cabeca_agua', 'head', (0, 27.4, .32), channels=model.wave(2.12,
                         amount=(.036, .039, .053), slide=(.065, .14, .077), sweep=1.42))
    # A crista se curva para trás. O centro da face continua legível.
    crown = [(0, 24.58, .60, 3.04, 3.36), (.14, 26.38, .49, 4.64, 5.83),
             (-.08, 29.19, .80, 5.34, 6.75), (-.25, 32.01, 1.12, 5.32, 6.40),
             (-.49, 34.66, 2.66, 4.42, 4.21), (-.64, 36.92, 4.51, 2.91, 2.66),
             (-.46, 38.34, 6.06, 1.31, 1.39), (-.32, 38.79, 6.98, .16, .17)]
    model.loft('superficie_cabeca', head, crown, sides=8, density='face', seed=1.96)
    for side in (-1, 1):
        label = 'd' if side < 0 else 'e'
        arm, leg = ('rightArm', 'rightLeg') if side < 0 else ('leftArm', 'leftLeg')
        phase = .86 if side < 0 else 2.91
        root = model.bone('braco_gigante_' + label, arm, (side * 6.35, 22.13, .11), channels=model.wave(phase,
                             amount=(.061, .037, .060), slide=(.09, .24, .139), sweep=1.26))
        arm_rows = [(side * 10.63, 7.56, -.80, 1.70, 1.55), (side * 10.42, 9.34, -.73, 3.74, 3.03),
                    (side * 10.32, 12.26, -.32, 4.48, 3.71), (side * 10.03, 16.02, .36, 4.81, 4.33),
                    (side * 9.43, 19.65, .71, 5.03 + .13 * side, 4.45),
                    (side * 8.34, 22.32, .91, 4.62, 4.27), (side * 6.96, 25.03, 1.16, 3.11, 3.23),
                    (side * 6.25, 26.84, 1.38, .38, .42)]
        model.loft('manga_' + label, root, arm_rows, sides=8, seed=phase)
        model.loft('massa_braco_' + label, root, scaled_rows(arm_rows[1:6:2], .72, .68, side * .25),
                   sides=6, seed=phase, density='deep', role='core',
                   channels=model.wave(phase + .64, amount=(.052, .028, .050), slide=(.11, .42, .10), sweep=1.35))
        for j in range(3):
            x = side * (8.58 + j * 1.74)
            y = 7.25 + (.38 if j != 1 else 0)
            model.loft(f'lobo_mao_{label}_{j+1}', root, [(x, y - .64, -.91, .24, .24), (x, y + .16, -.87, 1.02, .93),
                       (x - side * .10, y + 2.43, -.59, 1.18, 1.19)], sides=5, seed=j * .50 + phase)
        lower = [(side * 3.54, .17, -1.09, 1.09, 1.53), (side * 3.51, 1.15, -.83, 2.77, 3.01),
                 (side * 3.44, 3.50, -.21, 2.67, 2.83), (side * 3.54, 6.51, .32, 2.78, 3.11),
                 (side * 3.29, 9.89, .29, 3.02, 2.83), (side * 2.88, 12.68, .05, 3.24, 2.76),
                 (side * 2.26, 14.37, .20, 1.77, 1.92)]
        leg_part = model.bone('perna_agua_' + label, leg, (side * 2.34, 9.51, .05), channels=model.wave(phase + 1.44,
                             amount=(.034, .021, .055), slide=(.046, .104, .077), sweep=1.12))
        model.loft('perna_superficie_' + label, leg_part, lower, sides=6, seed=phase)
        model.drop('gota_mao_' + label, root, (side * 13.25, 8.95, -.78), .84, .44 + phase * .46, 4.1, side * 1.13)
        model.drop('gota_tornozelo_' + label, leg_part, (side * 5.61, 2.49, -.85), .66, 2.67 + phase * .24, 2.12, side * .43)



def create_model(mode):
    model = WaterModel(mode)
    builders = (hidrification, hand_mode, hulk)
    builders[mode.number - 1](model)
    return model
