"""Volumes, textura RGBA e animações de água do clã Hōzuki."""

from dataclasses import dataclass
from math import asin, atan2, cos, degrees, hypot, pi, sin, sqrt

import numpy as np
from PIL import Image


SIZE = 512
RATIOS = (1.0, .86, .72, .58, .45, .31, .19, .08)
RIG = (
    ('root', None, (0, 0, 0)), ('waist', 'root', (0, 12, 0)),
    ('body', 'waist', (0, 24, 0)), ('head', 'body', (0, 24, 0)),
    ('rightArm', 'body', (-5, 22, 0)), ('leftArm', 'body', (5, 22, 0)),
    ('rightLeg', 'root', (-1.9, 12, 0)), ('leftLeg', 'root', (1.9, 12, 0)),
)


@dataclass(frozen=True)
class Modo:
    number: int
    key: str
    item: str
    name: str
    project: str
    unlock: str
    length: float

    @property
    def geometry(self):
        return f'geometry.swbr.hozuki.{self.key}'

    @property
    def animation(self):
        return f'animation.swbr.hozuki.{self.key}.fluxo'

    @property
    def texture(self):
        return f'textures/entity/swbr/hozuki/{self.key}'

    @property
    def geometry_path(self):
        return f'models/entity/swbr/hozuki/{self.key}.geo.json'

    @property
    def animation_path(self):
        return f'animations/swbr/hozuki/{self.key}.animation.json'


MODES = (
    Modo(1, 'hidrico', 'nz:modo_hozuki_hidrico', 'Corpo Hídrico', 'Hozuki_01_Corpo_Hidrico.bbmodel', '28.000 TP', 4.8),
    Modo(2, 'hand', 'nz:hozuki1', 'Água Hand', 'Hozuki_02_Agua_Hand.bbmodel', 'Nível 10', 4.4),
    Modo(3, 'gigante', 'nz:hozuki2', 'Água Gigante', 'Hozuki_03_Agua_Gigante.bbmodel', 'Nível 15', 5.6),
)


def atlas(stage):
    """Cada coluna recorta um trapézio. As linhas controlam densidade e reflexo."""
    palettes = (
        (46, 158, 197), (79, 188, 219), (27, 120, 177), (118, 210, 228),
        (26, 106, 168), (147, 220, 235), (78, 191, 219), (55, 171, 207),
    )
    densities = (
        (124, 137, 118, 45, 104, 0, 153, 101),
        (185, 196, 178, 49, 121, 0, 163, 147),
        (175, 140, 162, 53, 102, 0, 171, 136),
    )[stage - 1]
    # Four pixels of padding repeat the sampled edge, keeping opposite tiles out of mipmaps.
    p = np.clip(np.arange(64, dtype=float), 4, 59)
    v, u = np.meshgrid((p - 4) / 55, (p - 31.5) / 27.5, indexing='ij')
    pixels = np.empty((SIZE, SIZE, 4), dtype=np.uint8)
    highlight = np.array((222, 249, 253))
    for row, (color, density) in enumerate(zip(palettes, densities)):
        for col, taper in enumerate(RATIOS):
            phase = 1.17 * row + stage * .81 + col * .38
            width = taper + (1 - taper) * v
            x = u / np.maximum(width, .06)
            edge = np.clip((1.025 - np.abs(x)) * (18 if taper == 1 else 14), 0, 1)
            wave = np.sin(6.4 * v + 3.1 * x + phase) + .42 * np.sin(11 * v - 7 * x + phase * 1.4)
            bend = .30 * np.sin(5.4 * v + phase) + .10 * np.cos(11.2 * v + phase)
            light = np.exp(-((x - bend - .22) / .087) ** 2)
            light *= .40 + .60 * np.maximum(0, np.sin(8.6 * v + phase)) ** .65
            bright_fold = np.exp(-((x - bend + .30 + .13 * np.sin(7.1 * v)) / .13) ** 2)
            bright_fold *= .49 + .33 * np.maximum(0, np.cos(13 * v - phase))
            shine = np.clip(light * .87 + bright_fold * .57, 0, 1)
            mix = np.clip(.13 + .057 * wave + shine * .86, 0, .94)
            if row == 5:
                alpha = (13 + 165 * np.maximum(light, bright_fold)) * edge * np.sin(pi * v) ** .48
                mix = np.clip(.43 + shine, 0, .96)
            else:
                alpha = (density + 11 * wave + 40 * shine) * edge
            rgb = color + (highlight - color) * mix[..., None]
            tile = np.dstack((np.clip(rgb, 0, 255), np.clip(alpha, 0, 233))).astype(np.uint8)
            pixels[row * 64:(row + 1) * 64, col * 64:(col + 1) * 64] = tile
    return Image.fromarray(pixels, 'RGBA')


def vec(items):
    return [round(n, 5) for n in items]


def plus(a, b):
    return tuple(x + y for x, y in zip(a, b))


def minus(a, b):
    return tuple(x - y for x, y in zip(a, b))


def scaled(a, multiplier):
    return tuple(x * multiplier for x in a)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def norm(a):
    return sqrt(dot(a, a))


def unit(a):
    return scaled(a, 1 / norm(a))


def center(*points):
    return tuple(sum(component) / len(points) for component in zip(*points))


def rotation_of(u, v, w):
    # R = Rz(-Bedrock Z) * Ry(Bedrock Y) * Rx(-Bedrock X).
    pitch = -asin(max(-1, min(1, u[2])))
    if abs(cos(pitch)) > .000001:
        roll = atan2(v[2], w[2])
        yaw = atan2(u[1], u[0])
    else:
        roll = 0
        yaw = atan2(-v[0], v[1])
    return vec((-degrees(roll), degrees(pitch), -degrees(yaw)))


def facet(a, b, c, d, row, *, gloss=False):
    """Aproxima um quadrilátero do volume por uma face de cubo rotacionada."""
    mid = center(a, b, c, d)
    across = plus(minus(b, a), minus(d, c))
    u = unit(across)
    vertical = minus(center(c, d), center(a, b))
    v = unit(minus(vertical, scaled(u, dot(u, vertical))))
    w = cross(u, v)
    bottom, top = norm(minus(b, a)), norm(minus(d, c))
    width = max(top, bottom) * (1.036 if gloss else 1.064)
    height = dot(vertical, v) * (1.012 if gloss else 1.040)
    ratio = min(bottom, top) / max(bottom, top)
    col = min(range(8), key=lambda i: abs(RATIOS[i] - ratio))
    flip = bottom < top
    return {'origin': vec((mid[0] - width / 2, mid[1] - height / 2, mid[2])),
            'size': vec((width, height, .024 if gloss else .056)),
            'pivot': vec(mid), 'rotation': rotation_of(u, v, w),
            'uv': {'north': {'uv': [col * 64 + 4, row * 64 + (60 if flip else 4)],
                             'uv_size': [56, -56 if flip else 56]}}}


def rings_for(rows, sides, seed):
    result = []
    for ring, (x, y, z, rx, rz) in enumerate(rows):
        points = []
        for side in range(sides):
            phi = 2 * pi * (side + .5) / sides
            variation = 1 + .062 * sin(3 * phi + seed) + .037 * cos(2 * phi + ring * .63 + seed)
            taper = min(1, rx / 1.15, rz / 1.15)
            points.append((x + rx * variation * cos(phi), y + .18 * taper * sin(2 * phi + seed + .55 * ring),
                           z + rz * variation * sin(phi)))
        result.append(points)
    return result


def loop_channels(length, phase, amount=(.042, .024, .035), slide=(.05, .14, .09), sweep=1.2):
    keys = {key: {} for key in ('scale', 'position', 'rotation')}
    for index in range(9):
        theta = phase + (index % 8) * pi / 4
        frame = f'{index * length / 8:.2f}'
        keys['scale'][frame] = vec(1 + amp * sin(theta + k * .82) for k, amp in enumerate(amount))
        keys['position'][frame] = vec(delta * sin(theta + k * 1.65) for k, delta in enumerate(slide))
        keys['rotation'][frame] = vec((sin(theta) * sweep * .58, sin(theta + 1.12) * sweep, cos(theta) * sweep * .55))
    return keys


class WaterModel:
    def __init__(self, mode):
        self.mode = mode
        self.bones = []
        self.roles = {}
        self.motion = {}
        self.parts = {}
        for name, parent, pivot in RIG:
            self.bone(name, parent, pivot, raw=True)

    def bone(self, name, parent, pivot, *, raw=False, cubes=(), role=None, channels=None):
        key = name if raw else f'hzk{self.mode.number}_{name}'
        data = {'name': key, 'pivot': vec(pivot)}
        if parent:
            data['parent'] = parent
        if cubes:
            data['cubes'] = cubes
            self.roles[key] = role
        if channels:
            self.motion[key] = channels
        self.bones.append(data)
        return key

    def wave(self, phase, **kwargs):
        return loop_channels(self.mode.length, phase, **kwargs)

    def loft(self, name, parent, rows, *, sides=8, include=None, density='surface', role='surface',
             fixed_row=None, channels=None, seed=0, origin=None):
        section = rings_for(rows, sides, seed)
        cubes = []
        for ring, (lower, upper) in enumerate(zip(section, section[1:])):
            for side in range(sides):
                if include is not None and side not in include:
                    continue
                nxt = (side + 1) % sides
                phi = 2 * pi * (side + 1) / sides
                row = 1 if cos(phi) > .42 else (2 if sin(phi) > .40 else 0)
                if density == 'face' and sin(phi) < -.82:
                    row = 3
                if density == 'edge':
                    row = 7 if (side + ring) % 3 != 0 else 0
                if self.mode.number == 3 and abs(cos(phi)) > .70:
                    row = 1
                if density == 'deep':
                    row = 4
                if fixed_row is not None:
                    row = fixed_row
                cubes.append(facet(lower[side], lower[nxt], upper[side], upper[nxt], row))
        pivot = origin or (rows[-1][0], rows[-1][1], rows[-1][2])
        key = self.bone(name, parent, pivot, cubes=cubes, role=role, channels=channels)
        self.parts[key] = {'sides': sides, 'rings': len(rows), 'role': role, 'profile': rows}
        return key

    def current(self, name, parent, rows, *, sides, idx, phase, segment=slice(None), seed=0, downward=.20):
        """Reflexo estreito apoiado nos próprios anéis da superfície."""
        surfaces = rings_for(rows, sides, seed)[segment]
        cubes = []
        for ring, (lower, upper) in enumerate(zip(surfaces, surfaces[1:])):
            i = (idx + int(ring / 2)) % sides
            n = (i + 1) % sides
            theta = 2 * pi * (i + 1) / sides
            bump = (.089 * cos(theta), 0, .089 * sin(theta))
            s = .26 + .12 * sin(ring * .82 + phase)
            t = .30 + .12 * sin((ring + 1) * .82 + phase)
            a = plus(plus(lower[i], scaled(minus(lower[n], lower[i]), s)), bump)
            b = plus(plus(lower[i], scaled(minus(lower[n], lower[i]), s + .30)), bump)
            c = plus(plus(upper[i], scaled(minus(upper[n], upper[i]), t)), bump)
            d = plus(plus(upper[i], scaled(minus(upper[n], upper[i]), t + .30)), bump)
            cubes.append(facet(a, b, c, d, 5, gloss=True))
        pivot = center(*surfaces[0], *surfaces[-1])
        self.bone(name, parent, pivot, cubes=cubes, role='surface', channels=self.wave(
            phase, amount=(.005, .018, .005), slide=(.025, downward, .024), sweep=.38))

    def drop(self, name, parent, xyz, size, start, fall, outward):
        x, y, z = xyz
        rows = [(x, y - size * .72, z, .10 * size, .10 * size),
                (x, y - .26 * size, z, .50 * size, .45 * size),
                (x - .07 * outward, y + .20 * size, z, .35 * size, .32 * size),
                (x - .13 * outward, y + .68 * size, z, .07 * size, .08 * size)]
        keys = {key: {'0.00': first, f'{self.mode.length:.2f}': first} for key, first in (
            ('scale', [.001] * 3), ('position', [0] * 3), ('rotation', [0] * 3),
        )}
        frames = ((0, .001, 0, 0), (.18, .76, .025, 0), (.34, 1, .12, 4),
                  (.66, .67, .48, 10), (.95, .001, 1, 14), (1.00, .001, 0, 0))
        duration = .79 if self.mode.number < 3 else .94
        for time, scale, travel, turn in frames:
            frame = f'{start + time * duration:.2f}'
            keys['scale'][frame] = vec((max(.001, scale * .91), scale, max(.001, scale * .88)))
            keys['position'][frame] = vec((travel * outward, -travel * fall, .17 * travel))
            keys['rotation'][frame] = vec((turn * .41, turn * .32 * outward, -turn * outward))
        self.loft(name, parent, rows, sides=5, fixed_row=6, channels=keys, origin=xyz)

    def document(self, role=None):
        bones = self.bones
        identity = self.mode.geometry
        if role:
            bones = [bone for bone in bones if bone['name'] not in self.roles or self.roles[bone['name']] == role]
            identity += '.' + role
            live = {b['name'] for b in bones}
            if any(b.get('parent', b['name']) not in live for b in bones):
                raise ValueError(f'Vínculo entre camadas em {self.mode.key}/{role}.')
        return {'format_version': '1.16.0', 'minecraft:geometry': [{
            'description': {'identifier': identity, 'texture_width': SIZE, 'texture_height': SIZE,
                            'visible_bounds_width': 4, 'visible_bounds_height': 5, 'visible_bounds_offset': [0, 1.12, 0]},
            'bones': bones,
        }]}

    def animation(self):
        return {'format_version': '1.8.0', 'animations': {self.mode.animation: {
            'loop': True, 'animation_length': self.mode.length, 'bones': self.motion,
        }}}


def scaled_rows(rows, rx, rz, shift_x=0, shift_z=0):
    return [(x + shift_x, y, z + shift_z, a * rx, b * rz) for x, y, z, a, b in rows]


def slim_arm(model, side, short=False):
    arm, label = ('rightArm', 'd') if side < 0 else ('leftArm', 'e')
    gain = .82 if short else 1
    depth = .94 if short else 1
    phase = 1.90 if side < 0 else 2.84
    root = model.bone('braco_leve_' + label, arm, (side * 6, 19.0, .18), channels=model.wave(phase,
                         amount=(.026, .021, .039), slide=(.026, .105, .054), sweep=.69))
    rows = [(side * 6.62, 11.67, -.02, .75 * gain, 1.07 * depth),
            (side * 6.19, 13.04, -.05, 2.28 * gain, 2.67 * depth),
            (side * 6.30, 15.45, .10 * side, 2.43 * gain, 2.89 * depth),
            (side * 6.29, 17.82, .14 * side, 2.18 * gain, 2.72 * depth),
            (side * 6.10, 19.4 if short else 20.70, -.16, 1.42 * gain, 1.85 * depth)]
    # A fenda na face interna mantém o antebraço reconhecível sob a água.
    traces = (1, 2, 3, 4, 5) if side < 0 else (5, 6, 7, 0, 1)
    model.loft('antebraco_' + label, root, rows, include=traces, seed=phase, density='edge')
    model.loft('filete_interno_' + label, root, scaled_rows(rows[1:4], .91, .83, side * .37),
               include=(3, 4) if side < 0 else (7, 0), seed=phase, density='deep', role='core')
    model.current('onda_braco_' + label, root, rows, sides=8, idx=4 if side < 0 else 5,
                  phase=phase, segment=slice(1, 4), seed=phase)
    if not short:
        shoulder = [(side * 7.56, 19.37, -1.79, .34, .32), (side * 7.17, 21.21, -.41, 1.57, 2.20),
                    (side * 6.79, 23.02, -.14, 1.91, 2.47), (side * 6.62, 24.34, .01, .86, .91)]
        model.loft('ombro_molhado_' + label, arm, shoulder, sides=6, density='edge', seed=phase,
                   channels=model.wave(phase + .7, amount=(.052, .042, .061), slide=(.021, .18, .044), sweep=1.3))
    model.drop('gota_punho_' + label, root, (side * (7.65 if not short else 7.31), 12.40, -.85),
               .64 if not short else .49, .28 + phase * .26, 3.6, side * .62)
    if not short:
        model.drop('gota_dedos_' + label, root, (side * 6.26, 12.03, -1.13), .43, 2.89 - phase * .17, 2.86, side * .43)


def hidrification(model):
    for side in (-1, 1):
        slim_arm(model, side)
        label = 'd' if side < 0 else 'e'
        phase = .85 if side < 0 else 3.18
        rows = [(side * 3.61, 13.42 + .31 * side, 1.39, .24, .29),
                (side * 3.42, 15.92, .29, 1.05, 2.48), (side * 3.11, 18.31 - .17 * side, -.12, 1.17, 3.10),
                (side * 3.27, 20.64 + .29 * side, -.54, .91, 2.55), (side * 3.05, 22.39, -1.46, .37, .74)]
        model.loft('faixa_costal_' + label, 'body', rows, sides=8,
                   include=(1, 2, 3, 4, 5) if side < 0 else (5, 6, 7, 0, 1),
                   seed=phase, density='edge', channels=model.wave(phase, amount=(.024, .032, .046), slide=(.04, .13, .034), sweep=1.1))


def fingers(model, base, side, palm_x, y, z, factor):
    for i, (offset, length, width) in enumerate(((-1.75, 1.87, .49), (-.59, 2.45, .57),
                                                (.58, 2.56, .61), (1.86, 2.07, .55))):
        x = palm_x + side * offset * factor
        y0 = y + (.16 if i in (0, 3) else 0)
        z0 = z + (.17 - .13 * i) * factor
        spread = side * (i - 1.45) * .19 * factor
        rows = [(x + spread, y0 - length * factor, z0 - .36 * factor, width * .29 * factor, width * .27 * factor),
                (x + spread * .48, y0 - length * .70 * factor, z0 - .33 * factor, width * .94 * factor, width * .84 * factor),
                (x + spread * .22, y0 - length * .24 * factor, z0 - .08 * factor, width * factor, width * .91 * factor),
                (x, y0 + .71 * factor, z0 + .13 * factor, width * 1.06 * factor, width * .96 * factor)]
        model.loft(f'dedo_{i+1}_{"d" if side < 0 else "e"}', base, rows, sides=6, density='edge', seed=.7 + i)
    x = palm_x - side * 2.06 * factor
    rows = [(x - side * 1.19 * factor, y - .88 * factor, z - .49 * factor, .22 * factor, .21 * factor),
            (x - side * .98 * factor, y - .21 * factor, z - .45 * factor, .55 * factor, .47 * factor),
            (x - side * .51 * factor, y + .84 * factor, z - .43 * factor, .65 * factor, .57 * factor),
            (x + side * .04 * factor, y + 1.68 * factor, z - .38 * factor, .67 * factor, .68 * factor)]
    model.loft('polegar_' + ('d' if side < 0 else 'e'), base, rows, sides=6, density='edge', seed=2.6)


def hand_mode(model):
    root = model.bone('braco_ampliado', 'rightArm', (-6.04, 22, .09), channels=model.wave(.35,
                         amount=(.066, .012, .073), slide=(.094, .096, .105), sweep=.75))
    rows = [(-9.50, 9.25, -.87, 1.98, 1.25), (-9.36, 10.66, -.68, 3.33, 2.63),
            (-9.42, 12.36, -.54, 3.70, 3.15), (-9.24, 14.93, -.14, 5.08, 4.05),
            (-8.91, 17.17, .44, 4.75, 4.19), (-8.31, 19.13, .41, 3.69, 3.23),
            (-7.21, 21.03, .07, 3.10, 2.63), (-6.14, 22.74, .14, 2.50, 2.31),
            (-5.62, 24.06, .31, 1.58, 1.49), (-5.51, 24.78, .34, .23, .21)]
    model.loft('superficie_braco', root, rows, sides=10, seed=1.18)
    model.loft('massa_braco', root, scaled_rows(rows[1:-1], .80, .78, -.39, .16), sides=8, include=(2, 3, 4, 5, 6),
               seed=2.5, density='deep', role='core', channels=model.wave(2.15, amount=(.037, .026, .039),
                                                                           slide=(.066, .37, .075), sweep=1.0))
    model.current('corrente_dianteira', root, rows, sides=10, idx=6, phase=.57, segment=slice(1, -1), seed=1.18)
    model.current('corrente_lateral', root, rows, sides=10, idx=2, phase=1.81, segment=slice(2, -1), seed=1.18)
    fingers(model, root, -1, -9.48, 10.26, -.64, 1.25)
    for name, xyz, size, start, fall, sway in (
        ('gota_cotovelo', (-13.55, 17.03, .80), .86, .44, 5.11, -1.08),
        ('gota_pulso', (-12.69, 12.45, -.56), .73, 1.76, 4.62, -.66),
        ('gota_dedo', (-10.61, 7.86, -.55), .55, 2.78, 3.41, -.63),
    ):
        model.drop(name, root, xyz, size, start, fall, sway)
    slim_arm(model, 1, short=True)


def hulk(model):
    torso = model.bone('peito_ondulante', 'body', (0, 18, .29), channels=model.wave(1.04,
                          amount=(.046, .036, .067), slide=(.12, .23, .20), sweep=1.05))
    rows = [(.08, 10.80, .29, 3.87, 2.83), (-.16, 13.39, .24, 5.26, 3.76),
            (.23, 16.42, .44, 6.08, 4.62), (-.20, 20.16, .86, 7.53, 5.82),
            (-.08, 23.16, 1.20, 8.18, 6.05), (.19, 25.62, 1.49, 6.03, 4.87),
            (.14, 27.61, 1.45, 3.51, 2.73)]
    model.loft('tronco_superficie', torso, rows, sides=8, seed=2.4)
    model.loft('tronco_fluxo_profundo', torso, scaled_rows(rows[1:-1], .81, .76, 0, .28), sides=8,
               include=(0, 2, 4, 6), density='deep', role='core', seed=.97,
               channels=model.wave(2.77, amount=(.049, .042, .068), slide=(.11, .32, .20), sweep=1.44))
    model.current('corrente_peito', torso, rows, sides=8, idx=4, phase=.28, segment=slice(1, -1), seed=2.4)
    model.current('onda_costas', torso, rows, sides=8, idx=0, phase=2.16, segment=slice(2, None), seed=2.4)
    head = model.bone('cabeca_agua', 'head', (0, 27.4, .32), channels=model.wave(2.12,
                         amount=(.036, .039, .053), slide=(.065, .14, .077), sweep=1.42))
    # A crista se curva para trás. O centro da face continua legível.
    crown = [(0, 24.58, .60, 3.04, 3.36), (.14, 26.38, .49, 4.64, 5.83),
             (-.08, 29.19, .80, 5.34, 6.75), (-.25, 32.01, 1.12, 5.32, 6.40),
             (-.49, 34.66, 2.66, 4.42, 4.21), (-.64, 36.92, 4.51, 2.91, 2.66),
             (-.46, 38.34, 6.06, 1.31, 1.39), (-.32, 38.79, 6.98, .16, .17)]
    model.loft('superficie_cabeca', head, crown, sides=8, density='face', seed=1.96)
    model.current('onda_temporal', head, crown, sides=8, idx=0, phase=.75, segment=slice(2, 7), seed=1.96)
    for side in (-1, 1):
        label = 'd' if side < 0 else 'e'
        arm, leg = ('rightArm', 'rightLeg') if side < 0 else ('leftArm', 'leftLeg')
        phase = .86 if side < 0 else 2.91
        root = model.bone('braco_gigante_' + label, arm, (side * 6.35, 22.13, .11), channels=model.wave(phase,
                             amount=(.061, .037, .060), slide=(.09, .24, .139), sweep=1.26))
        arm_rows = [(side * 10.63, 7.56, -.80, 1.70, 1.55), (side * 10.42, 9.34, -.73, 3.74, 3.03),
                    (side * 10.32, 12.26, -.32, 4.48, 3.71), (side * 10.03, 16.02, .36, 4.81, 4.33),
                    (side * 9.43, 19.65, .71, 5.03 + .13 * side, 4.45),
                    (side * 8.34, 22.32, .91, 4.62, 4.27), (side * 6.96, 25.03, 1.16, 3.11, 3.23),
                    (side * 6.25, 26.84, 1.38, .38, .42)]
        model.loft('manga_' + label, root, arm_rows, sides=8, seed=phase)
        model.loft('massa_braco_' + label, root, scaled_rows(arm_rows[1:6], .76, .71, side * .36),
                   sides=6, include=(2, 4) if side < 0 else (0, 4), seed=phase, density='deep', role='core',
                   channels=model.wave(phase + .64, amount=(.052, .028, .050), slide=(.11, .42, .10), sweep=1.35))
        model.current('onda_braco_' + label, root, arm_rows, sides=8, idx=4 if side < 0 else 5,
                      phase=phase + .45, segment=slice(1, 6), seed=phase)
        for j in range(3):
            x = side * (8.58 + j * 1.74)
            y = 7.25 + (.38 if j != 1 else 0)
            model.loft(f'lobo_mao_{label}_{j+1}', root, [(x, y - .64, -.91, .24, .24), (x, y + .16, -.87, 1.02, .93),
                       (x - side * .10, y + 2.43, -.59, 1.18, 1.19)], sides=5, density='edge', seed=j * .50 + phase)
        lower = [(side * 3.54, .17, -1.09, 1.09, 1.53), (side * 3.51, 1.15, -.83, 2.77, 3.01),
                 (side * 3.44, 3.50, -.21, 2.67, 2.83), (side * 3.54, 6.51, .32, 2.78, 3.11),
                 (side * 3.29, 9.89, .29, 3.02, 2.83), (side * 2.88, 12.68, .05, 3.24, 2.76),
                 (side * 2.26, 14.37, .20, 1.77, 1.92)]
        leg_part = model.bone('perna_agua_' + label, leg, (side * 2.34, 9.51, .05), channels=model.wave(phase + 1.44,
                             amount=(.034, .021, .055), slide=(.046, .104, .077), sweep=1.12))
        model.loft('perna_superficie_' + label, leg_part, lower, sides=6, density='edge', seed=phase)
        model.current('onda_tornozelo_' + label, leg_part, lower, sides=6, idx=2 if side < 0 else 4,
                      phase=phase, segment=slice(None, 4), seed=phase)
        model.drop('gota_mao_' + label, root, (side * 13.25, 8.95, -.78), .84, .44 + phase * .46, 4.1, side * 1.13)
        model.drop('gota_tornozelo_' + label, leg_part, (side * 5.61, 2.49, -.85), .66, 2.67 + phase * .24, 2.12, side * .43)
        bubble = [(side * 4.65, 20.11, 5.20, .23, .27), (side * 4.40, 21.36, 6.03, 1.25, 1.04),
                  (side * 4.06, 23.01, 6.71, 1.49, 1.24), (side * 3.92, 24.42, 6.14, .36, .38)]
        model.loft('massa_retorna_' + label, torso, bubble, sides=5, density='edge', seed=.19 + phase,
                   channels=model.wave(phase + .63, amount=(.18, .12, .15), slide=(side * .63, .51, 1.05), sweep=6.2))


def create_model(mode):
    model = WaterModel(mode)
    builders = (hidrification, hand_mode, hulk)
    builders[mode.number - 1](model)
    return model
