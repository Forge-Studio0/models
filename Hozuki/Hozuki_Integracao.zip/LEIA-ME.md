# Shinobi World BR · Hōzuki 18.11.74

Três modelos de água translúcida com volumes facetados, camada interna, superfície e reflexos animados. As gotas fazem parte do modelo e acompanham os membros. A visibilidade das duas camadas depende do item equipado na cabeça e da distância da câmera.

| Modo | Item | Desbloqueio | Forma |
| --- | --- | --- | --- |
| Corpo Hídrico | `nz:modo_hozuki_hidrico` | 28.000 TP | Liquefação parcial dos antebraços, ombros e flancos |
| Água Hand | `nz:hozuki1` | Nível 10 | Braço direito ampliado com cinco dedos e água concentrada no antebraço |
| Água Gigante | `nz:hozuki2` | Nível 15 | Cabeça, tronco, braços e pernas com volumes diferentes e rosto parcialmente visível |

## Instalação

- `Hozuki.mcaddon` atualiza a base original `SWBR_v18.11.64_GUI_VILA_CORRIGIDA.mcaddon` indicada no briefing.
- `Hozuki_Cumulativo.mcaddon` é a edição para quem já usa a 18.11.73 com Iburi, Aburame e Kaguya. [Baixar edição cumulativa no GitHub](https://github.com/Forge-Studio0/models/raw/refs/heads/main/Hozuki/Hozuki_Cumulativo.mcaddon)

Importe a edição que corresponde ao seu mundo e ative o BP e o RP juntos. As duas edições têm os mesmos UUIDs e a mesma versão de pack. O Desmaio Nativo já presente em cada base acompanha o arquivo de importação.

## Edição e integração

Os três `.bbmodel` incluem as texturas de 512 × 512 e os ciclos animados. Abra os projetos no Blockbench como modelos de entidade Bedrock. `Hozuki_Integracao.zip` contém geometrias, animações, PNGs, attachables, controladores, os arquivos BP/RP específicos de cada base e os relatórios.

Para aplicar o overlay, extraia o ZIP de integração e execute com Python 3. O manifesto identifica as bases compatíveis pelo SHA-256.

```sh
python Fontes/aplicar_integracao.py /caminho/para/base.mcaddon Hozuki_Integrado.mcaddon
```

O render do jogador seleciona a geometria pelo item no slot da cabeça e usa os pivôs do próprio SWBR. `nz:jutsu_corpo_hidrico_rp` e seus recursos fazem parte do pacote a partir da base utilizada. O Tate Eboshi serviu de referência para o volume da Água Gigante equipada.

## Referências

O Grande Braço orientou a transição entre ombro, antebraço e mão. [Episódio 115](https://www.crunchyroll.com/watch/GY5VEJ2DY/zabuzas-blade), [quadro oficial do episódio 115](https://naruto-official.com/en/anime/naruto2/list/01_559), [Técnica do Grande Braço de Água](https://naruto.fandom.com/wiki/Water_Release:_Great_Water_Arm_Technique).

As curvas da massa, a transparência e os reflexos do Tate Eboshi orientaram a forma avançada. [Episódio 143](https://www.crunchyroll.com/watch/GYK5PKEPR/the-eight-tails-vs-sasuke), [página oficial do episódio 143](https://naruto-official.com/en/anime/naruto2/list/01_587), [Tate Eboshi](https://naruto.fandom.com/wiki/Water_Release:_Tate_Eboshi), [quadro da técnica](https://wiki.jcdn.ru/w/images/a/a5/Suigetsu_fish.jpg).

## Validação

A entrega inclui checagem dos packs, reabertura e exportação no Blockbench, amostras de poses do SWBR e validação das condições de câmera. A confirmação dentro do Minecraft fica pendente para frente, costas e perfil, encaixe com os movimentos do jogador, ordem da transparência e troca e retirada dos itens.
