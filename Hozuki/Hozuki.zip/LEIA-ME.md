# Shinobi World BR · Hōzuki 18.11.77

Três modelos de água translúcida com superfícies ligadas pelas mesmas arestas e veios pintados ao longo dos volumes. A revisão completa os percursos das ondulações e das massas que se desprendem e voltam ao corpo. As gotas fazem parte do modelo e acompanham os membros. A opacidade da água em terceira pessoa vem da textura e se mantém ao aproximar a câmera.

## Comparação com o anime

| Modo | Referência | Forma e movimento |
| --- | --- | --- |
| Corpo Hídrico | Suigetsu liquefaz partes do corpo e mantém a forma humana. | A película azul-clara cobre antebraços, ombros e flancos. Ondas descem nos dois braços e gotas se desprendem das mãos. |
| Água Hand | No Grande Braço de Água, o volume se concentra em um braço. | O volume pulsa no braço direito. Ondulações atravessam o antebraço até a palma de cinco dedos. O outro braço tem liquefação parcial. |
| Água Gigante | O Tate Eboshi tem uma massa aquática ampla, com dorso curvo. | Tronco, membros e crista formam uma silhueta humanoide ampla, com parte do rosto visível. Pequenos volumes se desprendem das costas e voltam ao tronco durante o ciclo. |

| Modo | Item no slot da cabeça | Desbloqueio |
| --- | --- | --- |
| Corpo Hídrico | `nz:modo_hozuki_hidrico` | 28.000 TP |
| Água Hand | `nz:hozuki1` | Nível 10 |
| Água Gigante | `nz:hozuki2` | Nível 15 |

## Instalação

- `Hozuki.mcaddon` atualiza a edição baseada na SWBR original 18.11.64.
- `Hozuki_Cumulativo.mcaddon` atualiza a edição com Iburi, Aburame e Kaguya da base 18.11.73.

Importe a edição que corresponde ao seu mundo e confirme BP e RP na versão 18.11.77. As duas edições têm os mesmos UUIDs. O Desmaio Nativo já presente em cada base acompanha o arquivo de importação.

## Edição e integração

Os três `.bbmodel` incluem as texturas de 1024 × 1024 e os ciclos animados. Abra os projetos no Blockbench como modelos de entidade Bedrock. `Hozuki_Integracao.zip` contém geometrias, animações, PNGs, attachables, controladores, os arquivos BP/RP específicos de cada base e os relatórios.

Para aplicar o overlay, extraia o ZIP de integração e execute com Python 3. O manifesto identifica pelo SHA-256 as edições 18.11.74 a 18.11.76 e suas bases originais.

```sh
python Fontes/aplicar_integracao.py /caminho/para/base.mcaddon Hozuki_Integrado.mcaddon
```

O render do jogador seleciona a geometria e as partes visíveis da pele pelo item no slot da cabeça e usa os pivôs do SWBR. A máscara visual atua nos mesmos enquadramentos que a água. `nz:jutsu_corpo_hidrico_rp` e seus recursos fazem parte do pacote a partir da base utilizada.

Para regenerar a revisão, passe a `Fontes/construir_hozuki.py` os arquivos `Hozuki.mcaddon`, `Hozuki_Cumulativo.mcaddon` e `Hozuki_Integracao.zip` da 18.11.76, nessa ordem, a partir de uma pasta de saída separada.

## Referências

O Grande Braço orientou a transição entre ombro, antebraço e mão. [Episódio 115](https://www.crunchyroll.com/watch/GY5VEJ2DY/zabuzas-blade), [quadro oficial do episódio 115](https://naruto-official.com/en/anime/naruto2/list/01_559), [Técnica do Grande Braço de Água](https://naruto.fandom.com/wiki/Water_Release:_Great_Water_Arm_Technique).

As curvas da massa, a transparência e os reflexos do Tate Eboshi orientaram a forma avançada. [Episódio 143](https://www.crunchyroll.com/watch/GYK5PKEPR/the-eight-tails-vs-sasuke), [página oficial do episódio 143](https://naruto-official.com/en/anime/naruto2/list/01_587), [Tate Eboshi](https://naruto.fandom.com/wiki/Water_Release:_Tate_Eboshi), [quadro da técnica](https://wiki.jcdn.ru/w/images/a/a5/Suigetsu_fish.jpg).

## Validação

A entrega inclui auditoria dos packs, das emendas e dos ciclos das ondas, reabertura e exportação no Blockbench, projeções em seis ângulos, amostras de poses do SWBR e simulação de câmera, troca e retirada dos itens. A confirmação dentro do Minecraft fica pendente para enquadramento, encaixe com os movimentos, transparência e desequipamento.
