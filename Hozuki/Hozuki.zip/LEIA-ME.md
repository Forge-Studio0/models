# Shinobi World BR · Hōzuki 18.11.76

Três modelos de água translúcida com superfícies ligadas pelas mesmas arestas e veios pintados ao longo dos volumes. As gotas fazem parte do modelo e acompanham os membros. A opacidade da água em terceira pessoa vem da textura e se mantém ao aproximar a câmera.

## Comparação com o anime

| Modo | Referência | Capturas da 18.11.75 | Revisão 18.11.76 |
| --- | --- | --- | --- |
| Corpo Hídrico | Suigetsu liquefaz partes do corpo e mantém a forma humana. | O líquido aparece em faixas separadas sobre os braços. | A película acompanha cada braço do ombro ao pulso, com gotas e filetes nos flancos. |
| Água Hand | No Grande Braço de Água, o volume se concentra em um braço. | O antebraço ampliado tem emendas visíveis e pontas finas na mão. | O líquido forma um volume fechado e contínuo do ombro à palma, com cinco dedos arredondados. |
| Água Gigante | O Tate Eboshi tem uma massa aquática ampla, com dorso curvo. | As divisões entre as faces dão ao tronco e aos membros aspecto de placas. | Tronco, membros e crista têm veios contínuos. Os volumes internos translúcidos dão profundidade e o rosto continua visível. |

| Modo | Item no slot da cabeça | Desbloqueio |
| --- | --- | --- |
| Corpo Hídrico | `nz:modo_hozuki_hidrico` | 28.000 TP |
| Água Hand | `nz:hozuki1` | Nível 10 |
| Água Gigante | `nz:hozuki2` | Nível 15 |

## Instalação

- `Hozuki.mcaddon` atualiza a edição baseada na SWBR original 18.11.64.
- `Hozuki_Cumulativo.mcaddon` atualiza a edição com Iburi, Aburame e Kaguya da base 18.11.73.

Importe a edição que corresponde ao seu mundo e confirme BP e RP na versão 18.11.76. As duas edições têm os mesmos UUIDs. O Desmaio Nativo já presente em cada base acompanha o arquivo de importação.

## Edição e integração

Os três `.bbmodel` incluem as texturas de 1024 × 1024 e os ciclos animados. Abra os projetos no Blockbench como modelos de entidade Bedrock. `Hozuki_Integracao.zip` contém geometrias, animações, PNGs, attachables, controladores, os arquivos BP/RP específicos de cada base e os relatórios.

Para aplicar o overlay, extraia o ZIP de integração e execute com Python 3. O manifesto identifica pelo SHA-256 as edições 18.11.74 e 18.11.75 e suas bases originais.

```sh
python Fontes/aplicar_integracao.py /caminho/para/base.mcaddon Hozuki_Integrado.mcaddon
```

O render do jogador seleciona a geometria e as partes visíveis da pele pelo item no slot da cabeça e usa os pivôs do SWBR. A máscara visual atua nos mesmos enquadramentos que a água. `nz:jutsu_corpo_hidrico_rp` e seus recursos fazem parte do pacote a partir da base utilizada.

Para regenerar a revisão, passe a `Fontes/construir_hozuki.py` os arquivos `Hozuki.mcaddon`, `Hozuki_Cumulativo.mcaddon` e `Hozuki_Integracao.zip` da 18.11.75, nessa ordem, a partir de uma pasta de saída separada.

## Referências

O Grande Braço orientou a transição entre ombro, antebraço e mão. [Episódio 115](https://www.crunchyroll.com/watch/GY5VEJ2DY/zabuzas-blade), [quadro oficial do episódio 115](https://naruto-official.com/en/anime/naruto2/list/01_559), [Técnica do Grande Braço de Água](https://naruto.fandom.com/wiki/Water_Release:_Great_Water_Arm_Technique).

As curvas da massa, a transparência e os reflexos do Tate Eboshi orientaram a forma avançada. [Episódio 143](https://www.crunchyroll.com/watch/GYK5PKEPR/the-eight-tails-vs-sasuke), [página oficial do episódio 143](https://naruto-official.com/en/anime/naruto2/list/01_587), [Tate Eboshi](https://naruto.fandom.com/wiki/Water_Release:_Tate_Eboshi), [quadro da técnica](https://wiki.jcdn.ru/w/images/a/a5/Suigetsu_fish.jpg).

## Validação

A entrega inclui auditoria dos packs e das emendas, reabertura e exportação no Blockbench, projeções de frente, costas, perfis e ângulos oblíquos, amostras de poses do SWBR e simulação da câmera, troca e retirada dos itens. A confirmação dentro do Minecraft fica pendente para enquadramento, encaixe com os movimentos, transparência e desequipamento.
