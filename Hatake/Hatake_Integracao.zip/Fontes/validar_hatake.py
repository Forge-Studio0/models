"""Confere os recursos Hatake, as poses e a preservação dos dois packs."""

import argparse
from base64 import b64decode
from io import BytesIO
import json
from pathlib import Path
import re
from zipfile import ZipFile

import numpy as np
from PIL import Image

from aplicar_integracao import (AURA_LINES, DRAW, FX, HAIR, LOCATORS, NOTES, PLAYER, PLAYER_MODELS,
                                 PLAYER_RENDER, ROOT, RUNTIME, VERSION, changed_assets, open_packs,
                                 read_overlay, sha256, upgrade_manifest)
from construir_hatake import (CATALOG, ORIGINAL_RIG, RENDER, RENDER_PATH, SLOT, SPARK_ANIMATION_PATH,
                               VISIBLE, write_json)
from geometria import cube_points, frame_in_pose, overlap, sample, transforms
from modelagem import MODES, RIG, create_model


def read(archive, path):
    return json.loads(archive.read(path))


def names(archive):
    entries = archive.namelist()
    assert len(set(entries)) == len(entries), 'Entradas duplicadas no ZIP.'
    assert archive.testzip() is None, 'CRC inválido.'
    return set(entries)


def contacts(model, avatar):
    pivots = {name for name, _, _ in RIG}
    grouped = {}
    for name, bone in model.bones.items():
        if not bone.get('cubes') or name.startswith('ht_fx_'):
            continue
        host = name
        while host not in pivots:
            host = model.bones[host]['parent']
        grouped.setdefault(host, []).extend((name, i, cube) for i, cube in enumerate(bone['cubes']))
    for phase in np.linspace(0, model.mode.length, 5):
        world = transforms(list(model.bones.values()), model.channels, phase, {}, 0)
        for host, parts in grouped.items():
            pending = [(name, i, frame_in_pose(cube, world[name])) for name, i, cube in parts]
            connected = [frame_in_pose(cube, world[host]) for cube in avatar[host]['cubes']]
            while pending:
                next_round = []
                for name, i, bounds in pending:
                    if any(overlap(bounds, anchor) for anchor in connected):
                        connected.append(bounds)
                    else:
                        next_round.append((name, i, bounds))
                if len(next_round) == len(pending):
                    loose = [(name, i, np.round(bounds[0], 2).tolist()) for name, i, bounds in pending]
                    raise AssertionError(f'Peças sem apoio em {model.mode.key}/{host} à fase {phase:.2f}: {loose}')
                pending = next_round


def check_poses(model, rp):
    native = read(rp, 'animations/player.json')['animations']
    sprint = read(rp, 'animations/correndo.json')['animations']['animation.player_new.correndo']
    # A pose vanilla de agachamento não está serializada nos packs da base.
    crouch = {'animation_length': 1., 'bones': {
        'root': {'position': {'0.0': [0, 0, 0], '1.0': [0, -2.2, 0]}},
        'body': {'rotation': {'0.0': [0, 0, 0], '1.0': [25, 0, 0]}},
        'head': {'rotation': {'0.0': [0, 0, 0], '1.0': [-22, 0, 0]}},
        'rightLeg': {'rotation': {'0.0': [0, 0, 0], '1.0': [-14, 0, 0]}},
        'leftLeg': {'rotation': {'0.0': [0, 0, 0], '1.0': [-14, 0, 0]}},
    }}
    poses = {'repouso': {'animation_length': 0., 'bones': {}},
             'caminhada': native['animation.player_new.andando'], 'corrida': sprint,
             'salto': native['animation.player_new.pulo'], 'combate': native['animation.player_new.soco'],
             'agachamento_simulado': crouch}
    joints = [bone for bone in model.bones.values() if bone['name'] in model.channels]
    report = {}
    for label, pose in poses.items():
        checked = 0
        for time in np.linspace(0, pose['animation_length'], 7):
            for phase in np.linspace(0, model.mode.length, 6):
                world = transforms(list(model.bones.values()), model.channels, phase, pose['bones'], time)
                for bone in joints:
                    point = np.array(bone['pivot'])
                    matrix, offset = world[bone['name']]
                    parent, parent_offset = world[bone['parent']]
                    assert np.allclose(matrix @ point + offset, parent @ point + parent_offset), bone['name']
                    checked += 1
        report[label] = {'quadros': 7, 'fases': 6, 'encaixes_animados': checked}
    return report


def check_shape(model, avatar):
    part_bones = [bone for bone in model.bones.values() if not bone['name'].startswith('ht_fx_')]
    points = np.concatenate([cube_points(cube) for bone in part_bones for cube in bone.get('cubes', [])])
    limits = np.round([points.min(axis=0), points.max(axis=0)], 3)
    assert np.all(limits[0] >= [-9, .4, -6.2]) and np.all(limits[1] <= [9, 38, 6.6]), limits
    contacts(model, avatar)
    for label, pulses in model.mode.pulses.items():
        track = model.channels['ht_fx_' + label]['scale']
        assert np.allclose(sample(track, 0), 0) and np.allclose(sample(track, model.mode.length), 0)
        for start, end in pulses:
            assert np.allclose(sample(track, (start + end) / 2), 1)
        assert sum(end - start for start, end in pulses) < model.mode.length / 3
        arm = 'rightArm' if label.startswith('d_') else 'leftArm'
        bone = model.bones['ht_fx_' + label]
        assert bone['parent'] == arm
        for cube in bone['cubes']:
            distances = np.linalg.norm(cube_points(cube) - np.array(bone['pivot']), axis=1)
            assert max(distances) < 3.72, f'Efeito grande demais em {model.mode.key}/{label}.'
    return limits.tolist()


def asset_tests(rp, manifest):
    assets = set(rp.namelist())
    controllers = read(rp, RENDER_PATH)['render_controllers']
    assert controllers[RENDER]['materials'] == [{'*': 'Material.default'}, {'ht_fx_*': 'Material.eletricidade'}]
    assert controllers[RENDER]['part_visibility'] == [{'*': VISIBLE}]
    original_ids = {f'geometry.modo_{name}' for name in ('lobo_branco', 'presa_relampago', 'lobo_amaldicoado')}
    new_ids = {mode.geometry for mode in MODES}
    declaration = {name: [] for name in new_ids}
    for name in assets:
        if not name.startswith(('models/', 'attachables/', 'entity/', 'render_controllers/')) or not name.endswith('.json'):
            continue
        content = rp.read(name)
        assert not any(identifier.encode() in content for identifier in original_ids), (name, 'geometria antiga ainda usada')
        if name.startswith('models/'):
            for identifier in new_ids:
                if f'"{identifier}"'.encode() in content:
                    declaration[identifier].append(name)

    player = read(rp, PLAYER)['minecraft:client_entity']['description']
    for rig_path in PLAYER_MODELS:
        bones = {bone['name']: bone for bone in read(rp, rig_path)['minecraft:geometry'][0]['bones']}
        for arm, (name, point) in LOCATORS.items():
            assert bones[arm]['locators'][name] == point
    sparks = read(rp, SPARK_ANIMATION_PATH)['animations']
    for color, effect in FX.items():
        particle = read(rp, f'particles/swbr_hatake_{color}.json')['particle_effect']
        assert particle['description']['identifier'] == player['particle_effects'][f'hatake_{color}'] == effect
        assert particle['description']['basic_render_parameters']['texture'] + '.png' in assets
        assert particle['components']['minecraft:emitter_local_space']['position'] is True
        assert particle['components']['minecraft:particle_lifetime_expression']['max_lifetime'] <= .15
        png = Image.open(BytesIO(rp.read(f'textures/particle/swbr_hatake_{color}.png')))
        assert png.mode == 'RGBA' and png.size == (16, 16) and png.getchannel('A').getextrema() == (0, 255)

    for mode in MODES:
        spec = manifest['modos'][mode.key]
        desc = read(rp, mode.attachable)['minecraft:attachable']['description']
        assert desc['identifier'] == mode.item and desc['geometry'] == {'default': mode.geometry}
        assert desc['animations'] == {'idle': mode.animation} and desc['render_controllers'] == [RENDER]
        assert desc['textures'] == {'default': mode.texture} and desc['materials']['eletricidade'] == 'entity_emissive_alpha'
        assert declaration[mode.geometry] == [mode.geometry_path], declaration[mode.geometry]
        assert set(read(rp, mode.animation_path)['animations']) == {mode.animation}
        if mode.color:
            anim = sparks[player['animations']['hatake_faiscas_' + mode.key]]
            for label, pulses in mode.pulses.items():
                arm = 'rightArm' if label.startswith('d_') else 'leftArm'
                event = {'effect': f'hatake_{mode.color}', 'locator': LOCATORS[arm][0]}
                assert all(event in anim['particle_effects'][str(round(start + .02, 3))] for start, _ in pulses)
        png_bytes = rp.read(spec['textura'])
        with Image.open(BytesIO(png_bytes)) as image:
            assert image.mode == 'RGBA' and image.size == (spec['atlas'], spec['atlas'])
            assert image.getchannel('A').getextrema() == (0, 255)
        project = json.loads((ROOT / 'Modelos_Blockbench' / mode.project).read_bytes())
        assert len(project['elements']) == spec['cubos']
        assert b64decode(project['textures'][0]['source'].split(',')[1]) == png_bytes


def mechanics_test(bp):
    config = bp.read('scripts/menu/config.js').decode()
    multipliers = bp.read('scripts/rp_v130_mode_multipliers.js').decode()
    for mode in MODES:
        item = read(bp, mode.bp_item)['minecraft:item']
        assert item['description']['identifier'] == mode.item and item['components']['minecraft:wearable']['slot'] == SLOT
        rules, = (line for line in config.splitlines() if f'{{ id: "{mode.item}",' in line)
        if mode.level_line:
            assert f'lvl: {mode.requirement},' in rules
        else:
            assert f'tp: {mode.requirement},' in rules
            assert ('["nz:raio_roxo"]' if mode.stage == 1 else '["nz:raio_roxo", "nz:chidori"]') in rules
            if mode.stage > 1:
                assert f'unlocked_{MODES[mode.stage - 2].item[3:]}' in rules
        category = 'kekkei:hatake2' if mode.level_line else 'kekkei:hatake'
        assert any(f'"{category}"' in line and f'"{mode.item}"' in line for line in multipliers.splitlines())
    return {'ids': 6, 'slots': 6, 'requisitos': 6, 'listas_de_itens_temporarios': 3, 'categorias_de_multiplicadores': 2}


def audit_pack(base, output, manifest, geometry_audit):
    before, after = open_packs(base), open_packs(output)
    family = manifest['bases'][sha256(base.read_bytes())]['base']
    overlay = read_overlay(ROOT, manifest)
    results = {}
    with ZipFile(base) as original, ZipFile(output) as modified:
        siblings = names(original) - {entry[0] for entry in before.values()}
        assert names(modified) == siblings | {entry[0] for entry in after.values()} | {NOTES}
        for name in siblings:
            contents = modified.read(name)
            assert contents == original.read(name), name
            if name.endswith('.mcpack'):
                with ZipFile(BytesIO(contents)) as support:
                    names(support)
        assert modified.read(NOTES) == (ROOT / 'LEIA-ME.md').read_bytes()

    for kind in ('BP', 'RP'):
        with ZipFile(BytesIO(before[kind][2])) as old, ZipFile(BytesIO(after[kind][2])) as new:
            old_names, new_names = names(old), names(new)
            files = changed_assets(kind, old, manifest, overlay if kind == 'RP' else {})
            assert new_names == old_names | set(files)
            for name in new_names - {'manifest.json'}:
                expected = files[name] if name in files else old.read(name)
                assert new.read(name) == expected, f'{kind}/{name}'
            assert read(new, 'manifest.json') == upgrade_manifest(before[kind][1], family)
            assert after[kind][1]['header']['version'] == VERSION
            if kind == 'BP':
                assert set(files) == {RUNTIME}
                removed = [line for line in old.read(RUNTIME).splitlines() if line not in new.read(RUNTIME).splitlines()]
                assert tuple(removed) == AURA_LINES
                results['mecânicas'] = mechanics_test(new)
            else:
                asset_tests(new, manifest)
                for name in (PLAYER, PLAYER_RENDER, *PLAYER_MODELS):
                    assert name in files
                if geometry_audit:
                    avatar = {bone['name']: bone for bone in read(new, ORIGINAL_RIG)['minecraft:geometry'][0]['bones']}
                    geometries = {}
                    shapes = set()
                    for mode in MODES:
                        model = create_model(mode)
                        limits = check_shape(model, avatar)
                        geometries[mode.key] = {'limites': limits, 'poses': check_poses(model, new), 'encaixes': True}
                        shapes.add(json.dumps([{k: v for k, v in cube.items() if k != 'uv'}
                                               for bone in model.bones.values() for cube in bone.get('cubes', [])], sort_keys=True))
                    assert len(shapes) == len(MODES)
                    results['modelos'] = geometries
            changed = set(files) | {'manifest.json'}
            results[kind] = {'arquivos': len(new_names), 'preservados_byte_a_byte': len(old_names - changed),
                             'substituídos': sorted(changed & old_names), 'adicionados': sorted(changed - old_names)}
    results['sha256'] = sha256(output.read_bytes())
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'Integracao_Manifesto.json').read_bytes())
    result = {'versao': VERSION, 'minecraft_executado': False, 'edicoes': {}}
    for family, source in (('original', args.original), ('cumulativa', args.cumulativa)):
        name = CATALOG[family][0]
        result['edicoes'][family] = audit_pack(source, ROOT / name, manifest, family == 'original')
        print(f'{name}: packs, referências Hatake e mecânicas conferidos.')
    write_json(ROOT / 'Validacao.json', result)


if __name__ == '__main__':
    main()
