"""Empacota os projetos e reproduz os dois addons a partir da integração."""

import argparse
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from aplicar_integracao import ROOT, sha256, zip_item
from construir_hatake import CATALOG


def package(original, cumulative):
    report = json.loads((ROOT / 'Validacao_Blockbench.json').read_bytes())['resultados']
    if len(report) != 6 or any(not (entry['reaberto'] and entry['exportacao_identica']) for entry in report):
        raise ValueError('Falta a validação de um projeto no Blockbench.')
    included = ['LEIA-ME.md', 'Relatorio.md', 'Integracao_Manifesto.json', 'Validacao.json',
                'Validacao_Molang.json', 'Validacao_Blockbench.json']
    for folder in ('Fontes', 'Integracao', 'Modelos_Blockbench'):
        included.extend(sorted(file.relative_to(ROOT).as_posix() for file in (ROOT / folder).rglob('*')
                               if file.is_file() and '__pycache__' not in file.parts))
    destination = ROOT / 'Hatake_Integracao.zip'
    with ZipFile(destination, 'w') as archive:
        for name in included:
            archive.writestr(zip_item(name), (ROOT / name).read_bytes())
    with TemporaryDirectory(prefix='hatake-integracao-') as folder:
        stage = Path(folder)
        with ZipFile(destination) as archive:
            if archive.testzip() is not None or archive.namelist() != included:
                raise ValueError('ZIP de integração inválido.')
            archive.extractall(stage)
        for variant, source in (('original', original), ('cumulativa', cumulative)):
            name = CATALOG[variant][0]
            target = stage / name
            subprocess.run([sys.executable, str(stage / 'Fontes/aplicar_integracao.py'), str(source), str(target)], check=True)
            if sha256(target.read_bytes()) != sha256((ROOT / name).read_bytes()):
                raise ValueError(f'O ZIP não reproduziu {name}.')
    for file in (*[ROOT / name for name, _ in CATALOG.values()], destination):
        print(file.name, file.stat().st_size, sha256(file.read_bytes()))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    args = parser.parse_args()
    package(args.original, args.cumulativa)
