"""Gera os recursos Hatake e empacota as edições original e cumulativa."""

import argparse
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

from aplicar_integracao import FX, LOCATORS, ROOT, VERSION, apply, manifest_bytes, open_packs, sha256
from modelagem import MODES, RIG, create_model
from texturas import SIZE, atlas, spark_texture


CATALOG = {
    'original': ('Hatake.mcaddon', '18.11.64 com Hōzuki'),
    'cumulativa': ('Hatake_Cumulativo.mcaddon', '18.11.80 cumulativa'),
}
LEGACY_HASH = 'c3ef05c2446e2fb8dd359aa7de98761b8623189c94804cb66c2bdd8c79aa21a2'
GATE = ("context.item_slot == 'head' && !(context.is_first_person ?? 0.0)"
        ' && !(context.owning_entity -> q.is_spectator) && !(context.owning_entity -> q.is_invisible)')
VISIBLE = 'v.swbr_hatake_attachable'
AGE = "(context.owning_entity -> q.property('nzs:body_age'))"
SCALE = f'0.9375 * ({AGE} == 1 ? 0.87 : ({AGE} == 2 ? 0.70 : 1.0))'
RENDER = 'controller.render.swbr.hatake'
RENDER_PATH = 'render_controllers/swbr_hatake.json'
SPARK_ANIMATION_PATH = 'animations/swbr/hatake/faiscas.animation.json'
SLOT = 'slot.armor.head'
ORIGINAL_RIG = 'models/entity/swbr39/custom.geo.json'


def write_json(path, document):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(manifest_bytes(document))


def attachable(mode):
    return {'format_version': '1.10.0', 'minecraft:attachable': {'description': {
        'identifier': mode.item, 'geometry': {'default': mode.geometry},
        'textures': {'default': mode.texture},
        'materials': {'default': 'entity_alphatest', 'eletricidade': 'entity_emissive_alpha'},
        'animations': {'idle': mode.animation},
        'scripts': {'parent_setup': 'variable.helmet_layer_visible = 0.0;',
                    'pre_animation': [f'{VISIBLE} = ({GATE}) ? 1.0 : 0.0;'],
                    'scale': SCALE, 'animate': [{'idle': VISIBLE}]},
        'render_controllers': [RENDER],
    }}}


def spark_particle(color):
    return {'format_version': '1.10.0', 'particle_effect': {
        'description': {'identifier': FX[color], 'basic_render_parameters': {
            'material': 'particles_blend', 'texture': f'textures/particle/swbr_hatake_{color}'}},
        'components': {
            'minecraft:emitter_local_space': {'position': True, 'rotation': True, 'velocity': False},
            'minecraft:emitter_rate_instant': {'num_particles': 2},
            'minecraft:emitter_lifetime_once': {'active_time': .10},
            'minecraft:emitter_shape_sphere': {'radius': .047, 'direction': 'outwards'},
            'minecraft:particle_initial_speed': .18,
            'minecraft:particle_initial_spin': {'rotation': 'math.random(0, 360)', 'rotation_rate': 'math.random(-240, 240)'},
            'minecraft:particle_motion_dynamic': {'linear_drag_coefficient': 3.1},
            'minecraft:particle_lifetime_expression': {'max_lifetime': .145},
            'minecraft:particle_appearance_billboard': {
                'size': [.023, .035], 'facing_camera_mode': 'lookat_xyz',
                'uv': {'texture_width': 16, 'texture_height': 16, 'uv': [0, 0], 'uv_size': [16, 16]},
            },
            'minecraft:particle_appearance_tinting': {'color': [1, 1, 1,
                'math.clamp(1 - (v.particle_age / math.max(v.particle_lifetime, 0.001)), 0, 1)']},
        },
    }}


def spark_animations():
    animations = {}
    for mode in MODES:
        if not mode.color:
            continue
        events = {}
        for label, windows in mode.pulses.items():
            arm = 'rightArm' if label.startswith('d_') else 'leftArm'
            locator = LOCATORS[arm][0]
            for start, _ in windows:
                time = str(round(start + .02, 3))
                events.setdefault(time, []).append({'effect': 'hatake_' + mode.color, 'locator': locator})
        animations[f'animation.swbr.hatake.{mode.key}.faiscas'] = {
            'loop': True, 'animation_length': mode.length, 'particle_effects': events,
        }
    return {'format_version': '1.8.0', 'animations': animations}


def source_check(source):
    packs = open_packs(source)
    if any(info[1]['header']['version'] != [18, 11, 80] for info in packs.values()):
        raise ValueError('Use as duas edições Sarutobi 18.11.80 para gerar os pacotes publicados.')
    with ZipFile(BytesIO(packs['BP'][2])) as bp, ZipFile(BytesIO(packs['RP'][2])) as rp:
        native = {bone['name']: bone for bone in json.loads(rp.read(ORIGINAL_RIG))['minecraft:geometry'][0]['bones']}
        for name, parent, pivot in RIG:
            if native[name].get('parent') != parent or tuple(native[name]['pivot']) != pivot:
                raise ValueError(f'Pivô original alterado em {name}.')
        assert bp.testzip() is None and rp.testzip() is None
        for mode in MODES:
            item = json.loads(bp.read(mode.bp_item))['minecraft:item']
            old = json.loads(rp.read(mode.attachable))['minecraft:attachable']['description']
            before = json.loads(rp.read(mode.geometry_path))['minecraft:geometry'][0]['description']['identifier']
            assert item['description']['identifier'] == old['identifier'] == mode.item
            assert item['components']['minecraft:wearable']['slot'] == SLOT
            assert old['geometry']['default'] == before


def generate(original, cumulative):
    rp = ROOT / 'Integracao' / 'RP'
    bases = {LEGACY_HASH: {'arquivo': 'SWBR_v18.11.64_GUI_VILA_CORRIGIDA.mcaddon', 'base': '18.11.64 original'}}
    for family, source in (('original', original), ('cumulativa', cumulative)):
        source_check(source)
        bases[sha256(source.read_bytes())] = {'arquivo': source.name, 'base': CATALOG[family][1]}
    manifest = {'cla': 'Hatake', 'versao': VERSION, 'bases': bases, 'slot': SLOT, 'modos': {}, 'recursos': {}}
    for mode in MODES:
        model = create_model(mode)
        write_json(rp / mode.geometry_path, model.geometry())
        write_json(rp / mode.animation_path, model.animation())
        write_json(rp / mode.attachable, attachable(mode))
        texture = rp / (mode.texture + '.png')
        texture.parent.mkdir(parents=True, exist_ok=True)
        atlas(mode).save(texture, optimize=True)
        manifest['modos'][mode.key] = {
            'chave': mode.key, 'id': mode.item, 'nome': mode.name, 'requisito': mode.requirement,
            'linha': 'nível' if mode.level_line else 'TP', 'cor': mode.color, 'projeto': mode.project,
            'attachable': mode.attachable, 'arquivo_geo': mode.geometry_path, 'geometria': mode.geometry,
            'arquivo_anim': mode.animation_path, 'animacao': mode.animation, 'textura': mode.texture + '.png',
            'cubos': sum(len(bone.get('cubes', [])) for bone in model.bones.values()),
            'bones': len(model.bones), 'atlas': SIZE,
        }

    write_json(rp / SPARK_ANIMATION_PATH, spark_animations())
    for color in FX:
        write_json(rp / f'particles/swbr_hatake_{color}.json', spark_particle(color))
        target = rp / f'textures/particle/swbr_hatake_{color}.png'
        target.parent.mkdir(parents=True, exist_ok=True)
        spark_texture(color).save(target, optimize=True)
    write_json(rp / RENDER_PATH, {'format_version': '1.8.0', 'render_controllers': {RENDER: {
        'geometry': 'Geometry.default', 'textures': ['Texture.default'],
        'materials': [{'*': 'Material.default'}, {'ht_fx_*': 'Material.eletricidade'}],
        'part_visibility': [{'*': VISIBLE}],
    }}})
    manifest['recursos'] = {path.relative_to(rp).as_posix(): sha256(path.read_bytes())
                            for path in sorted(rp.rglob('*')) if path.is_file()}
    write_json(ROOT / 'Integracao_Manifesto.json', manifest)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original', type=Path)
    parser.add_argument('cumulativa', type=Path)
    parser.add_argument('--somente-recursos', action='store_true')
    args = parser.parse_args()
    generate(args.original, args.cumulativa)
    if not args.somente_recursos:
        for family, source in (('original', args.original), ('cumulativa', args.cumulativa)):
            print(apply(source, ROOT / CATALOG[family][0]))


if __name__ == '__main__':
    main()
