"""Máscaras e peças Hatake alinhadas aos pivôs do avatar Shinobi World BR."""

from dataclasses import dataclass
from math import asin, atan2, degrees, dist

from texturas import SIZE, TILE, TILES


RIG = (
    ('root', None, (0, 0, 0)), ('waist', 'root', (0, 12, 0)),
    ('body', 'waist', (0, 24, 0)), ('head', 'body', (0, 24, 0)),
    ('rightArm', 'body', (-5, 22, 0)), ('leftArm', 'body', (5, 22, 0)),
    ('rightLeg', 'root', (-1.9, 12, 0)), ('leftLeg', 'root', (1.9, 12, 0)),
)
SIDES = ((-1, 'd', 'rightArm', 'rightLeg'), (1, 'e', 'leftArm', 'leftLeg'))
FACES = ('north', 'east', 'south', 'west', 'up', 'down')
NAMES = ('Lobo Branco', 'Presa do Relâmpago', 'Lobo Amaldiçoado')
ITEM_NAMES = ('lobo_branco', 'presa_relampago', 'lobo_amaldicoado')


@dataclass(frozen=True)
class Mode:
    index: int
    key: str
    stage: int
    level_line: bool
    requirement: int
    length: float

    @property
    def name(self):
        return NAMES[self.stage - 1] + (' 2.0' if self.level_line else '')

    @property
    def item(self):
        family = '' if self.level_line else 'hatake_'
        return f'nz:modo_{family}{ITEM_NAMES[self.stage - 1]}'

    @property
    def base_filename(self):
        if self.stage == 3 and self.level_line:
            return 'modo_lobo_amaldi#U00e7oado'
        return 'modo_' + ITEM_NAMES[self.stage - 1]

    @property
    def attachable(self):
        if self.level_line:
            return f'attachables/{self.base_filename}.json'
        return f'attachables/nz170/{self.item[3:]}.json'

    @property
    def bp_item(self):
        if not self.level_line:
            return f'items/nz170/clan_modes/{self.item[3:]}.json'
        if self.stage == 1:
            return 'items/nz_modo_lobo_branco.json'
        return f'items/{self.base_filename}.json'

    @property
    def project(self):
        return f'Hatake_{self.index:02d}_{self.key}.bbmodel'

    @property
    def geometry(self):
        return f'geometry.swbr.hatake.{self.key}'

    @property
    def geometry_path(self):
        prefix = '' if self.level_line else 'nz170/hatake/'
        return f'models/entity/{prefix}{self.base_filename}.geo.json'

    @property
    def texture(self):
        return f'textures/entity/swbr/hatake/{self.key}'

    @property
    def animation(self):
        return f'animation.swbr.hatake.{self.key}.idle'

    @property
    def animation_path(self):
        return f'animations/swbr/hatake/{self.key}.animation.json'

    @property
    def color(self):
        return {1: None, 2: 'azul', 3: 'roxo'}[self.stage]

    @property
    def pulses(self):
        # Cada entrada liga uma ramificação em um dos pulsos do ciclo.
        return {
            'tp_presa_relampago': {'d_a': ((.16, .28), (1.32, 1.48)), 'd_b': ((.40, .52), (1.53, 1.64))},
            'tp_lobo_amaldicoado': {'d_a': ((.17, .32), (1.20, 1.32)), 'd_b': ((.38, .51), (1.91, 2.04)),
                                     'e_a': ((.48, .65), (1.33, 1.47)), 'e_b': ((.77, .89), (1.95, 2.07))},
            'nivel_presa_relampago': {'d_a': ((.16, .28), (1.42, 1.52)), 'd_b': ((.36, .47), (1.61, 1.72)),
                                       'e_a': ((.22, .34), (1.47, 1.58))},
            'nivel_lobo_amaldicoado': {'d_a': ((.13, .25), (1.08, 1.21)), 'd_b': ((.40, .52), (1.45, 1.58)),
                                        'e_a': ((.23, .35), (1.20, 1.33)), 'e_b': ((.58, .70), (1.58, 1.70))},
        }.get(self.key, {})


MODES = (
    Mode(1, 'tp_lobo_branco', 1, False, 22000, 2.8),
    Mode(2, 'tp_presa_relampago', 2, False, 44000, 2.25),
    Mode(3, 'tp_lobo_amaldicoado', 3, False, 74000, 2.52),
    Mode(4, 'nivel_lobo_branco', 1, True, 8, 2.8),
    Mode(5, 'nivel_presa_relampago', 2, True, 12, 2.44),
    Mode(6, 'nivel_lobo_amaldicoado', 3, True, 18, 2.14),
)


def rounded(values):
    return [round(value, 5) + 0.0 for value in values]


def midpoint(a, b):
    return tuple((x + y) / 2 for x, y in zip(a, b))


class Wearable:
    def __init__(self, mode):
        self.mode = mode
        self.bones = {}
        self.channels = {}
        for name, parent, pivot in RIG:
            self.bone(name, parent, pivot)

    def bone(self, name, parent, pivot):
        data = {'name': name, 'pivot': rounded(pivot)}
        if parent:
            data['parent'] = parent
        self.bones[name] = data
        return name

    def box(self, bone, center, size, texture, rotation=None, **faces):
        cube = {'origin': rounded(c - s / 2 for c, s in zip(center, size)), 'size': rounded(size), 'uv': {}}
        if rotation and any(rotation):
            cube.update(pivot=rounded(center), rotation=rounded(rotation))
        for face in FACES:
            row, col = divmod(TILES[faces.get(face, texture)], SIZE // TILE)
            cube['uv'][face] = {'uv': [col * TILE + 1, row * TILE + 1], 'uv_size': [TILE - 2, TILE - 2]}
        self.bones[bone].setdefault('cubes', []).append(cube)

    def card(self, bone, center, size, front, back=None, rotation=None):
        self.box(bone, center, size, 'transparente', rotation, north=front, south=back or front)

    def strand(self, bone, start, end, width, depth, texture, *, cutout=False):
        length = dist(start, end)
        dx, dy, dz = (b - a for a, b in zip(start, end))
        rotation = (-degrees(asin(dz / length)), 0, degrees(atan2(dx, dy)))
        center = midpoint(start, end)
        size = width, length + .07, depth
        if cutout:
            self.card(bone, center, size, texture, rotation=rotation)
        else:
            self.box(bone, center, size, texture, rotation)

    def sway(self, bone, pitch, roll):
        end = self.mode.length
        self.channels[bone] = {'rotation': {
            '0.0': [0, 0, 0], str(round(end * .27, 2)): [pitch, 0, roll],
            str(round(end * .68, 2)): [-pitch * .65, 0, -roll * .70], str(end): [0, 0, 0],
        }}

    def geometry(self):
        return {'format_version': '1.16.0', 'minecraft:geometry': [{
            'description': {'identifier': self.mode.geometry, 'texture_width': SIZE, 'texture_height': SIZE,
                            'visible_bounds_width': 4, 'visible_bounds_height': 4, 'visible_bounds_offset': [0, 1, 0]},
            'bones': list(self.bones.values()),
        }]}

    def animation(self):
        return {'format_version': '1.8.0', 'animations': {self.mode.animation: {
            'loop': True, 'animation_length': self.mode.length, 'bones': self.channels,
        }}}


def hair(model, head):
    mode = model.mode
    dark = mode.stage == 3
    model.box(head, (0, 32.05, .49), (7.64, .92, 6.84), 'sombra' if dark else 'prata', up='gelo')
    model.box(head, (-1.71, 32.09, -2.41), (3.35, .81, 1.52), 'sombra' if dark else 'prata', (3, 0, 3), up='gelo')
    model.box(head, (1.13, 32.28, -2.33), (3.45, .77, 1.77), 'prata', (2, 0, -6), up='gelo')
    model.box(head, (0, 31.36, 3.62), (6.70, 1.58, .82), 'pelo_frio' if dark else 'prata', (10, 0, 0))
    if mode.level_line:
        strands = (
            ((-2.30, 32.13, -2.34), (-2.11, 34.12, -.24), 1.71),
            ((-1.22, 32.13, -2.59), (-.93, 35.11, .24), 2.06),
            ((.60, 32.23, -2.56), (1.63, 35.82, .61), 2.38),
            ((1.77, 32.16, -.91), (2.99, 34.76, 2.43), 2.14),
        )
    else:
        strands = (
            ((-2.22, 32.06, -2.24), (-2.54, 34.56, -.59), 1.73),
            ((-1.42, 32.10, -2.68), (-1.77, 35.43, -.52), 2.15),
            ((.03, 32.16, -2.51), (.24, 36.52, .22), 2.46),
            ((1.62, 32.10, -1.77), (2.48, 35.70, 1.59), 2.48),
            ((2.25, 32.10, -.54), (3.02, 34.81, 2.48), 2.06),
        )
    for index, (base, point, width) in enumerate(strands):
        surface = 'tufo_gelo' if index % 2 == 0 else 'tufo_prata'
        model.strand(head, base, point, width, .59, surface, cutout=True)
        inside = (base[0], base[1] - .12, base[2] + .37)
        middle = midpoint(base, point)
        model.strand(head, inside, middle, width * .52, .86, 'prata' if dark else 'gelo')
    back_height = 2.48 if mode.level_line else 3.20
    for side, _, _, _ in SIDES:
        model.strand(head, (side * 1.34, 32.01, 2.36), (side * 2.82, 31.62 + back_height, 5.24),
                     2.61, .49, 'tufo_sombra' if dark else 'tufo_prata', cutout=True)
        y = 30.58 if mode.level_line else 29.86
        model.strand(head, (side * 2.99, y, 3.73), (side * 3.17, 32.43, 3.48),
                     1.57, .93, 'tufo_cinza' if dark else 'tufo_prata', cutout=True)
    if not mode.level_line:
        model.box(head, (0, 31.13, 4.26), (2.08, .86, 1.24), 'faixa', (16, 0, 0))
        model.strand(head, (0, 28.27 if dark else 28.69, 5.31), (0, 31.56, 4.48),
                     2.36, 1.02, 'tufo_cinza' if dark else 'tufo_prata', cutout=True)


def ears(model, head):
    mode = model.mode
    height, width, pitch, roll, z = {
        'tp_lobo_branco': (3.53, 2.58, -9, 16, -1.96),
        'tp_presa_relampago': (4.23, 2.49, -25, 13, -1.69),
        'tp_lobo_amaldicoado': (4.11, 2.51, -30, 18, -1.65),
        'nivel_lobo_branco': (2.37, 2.15, -13, 12, -2.03),
        'nivel_presa_relampago': (3.32, 1.82, -22, 14, -1.88),
        'nivel_lobo_amaldicoado': (3.87, 2.02, -33, 21, -1.59),
    }[mode.key]
    face = ('orelha_branca', 'orelha_prata', 'orelha_escura')[mode.stage - 1]
    for side, label, _, _ in SIDES:
        root = (side * 3.36, 31.98, z)
        ear = model.bone(f'ht_orelha_{label}', head, root)
        model.box(ear, (root[0], root[1] + .21, z), (width * .79, .84, 1.55), 'pelo', (pitch, 0, side * roll))
        center = (root[0] + side * height * .16, root[1] + height * .45, z + height * (-pitch) / 125)
        model.card(ear, center, (width, height, .54), face, 'orelha_costas', (pitch, side * 8, side * roll))
        model.strand(ear, (root[0], 32.11, z + .63), (center[0] + side * .28, center[1] + height * .27, center[2] + .24),
                     width * .45, .47, 'tufo_prata', cutout=True)
        if mode.stage != 2 or not mode.level_line:
            model.strand(ear, (root[0] + side * .42, 32.09, z - .16),
                         (root[0] + side * 1.42, 33.40, z + .26), 1.15, .25, 'tufo_gelo', cutout=True)
        model.sway(ear, 3.1 + mode.stage * .61, side * (2.9 if mode.stage == 1 else 2.2))


def mask(model, head):
    mode = model.mode
    stage = mode.stage
    if stage == 1 and mode.level_line:
        model.box(head, (0, 30.95, -4.18), (7.52, 1.15, .47), 'naval')
        model.card(head, (0, 31.11, -4.47), (6.48, 1.50, .09), 'placa_shinobi')
    elif stage == 3:
        length = 1.26 if mode.level_line else 1.09
        model.box(head, (0, 26.02, -3.97), (7.71, 2.74, .81), 'chumbo')
        model.box(head, (0, 26.20, -4.58), (5.10, 1.91, length), 'grafite', (11, 0, 0))
        model.card(head, (0, 26.24, -4.76 - length / 2), (4.83, 2.03, .12), 'focinho', rotation=(11, 0, 0))
        model.box(head, (0, 26.79, -5.0 - length / 2), (1.40, .55, .35), 'nariz', (13, 0, 0))
        model.card(head, (0, 31.27, -4.00), (6.89 if mode.level_line else 5.73, 1.55, .26),
                   'tufo_prata' if mode.level_line else 'tufo_cinza', rotation=(0, 0, -5))
        for side, _, _, _ in SIDES:
            model.strand(head, (side * 2.48, 26.37, -4.35), (side * 1.30, 25.88, -5.50),
                         .67, .49, 'grafite')
    else:
        wide = 7.72 if stage == 1 else 7.49
        model.box(head, (0, 25.94, -4.02), (wide, 2.58, .54), 'carvao' if stage == 1 else 'chumbo')
        model.card(head, (0, 26.08, -4.33), (wide - .11, 2.63, .10), 'máscara' if stage == 1 else 'máscara_cinza')
        if stage == 2 and not mode.level_line:
            model.box(head, (0, 30.98, -4.18), (7.41, 1.21, .61), 'sombra')
            model.card(head, (0, 31.08, -4.53), (6.64, 1.42, .09), 'placa_shinobi')
    for side, _, _, _ in SIDES:
        x = side * (3.75 if stage < 3 else 3.66)
        cheek_y = 28.95 if stage == 1 and mode.level_line else 27.04
        height = 3.65 if stage == 2 else 3.45 if mode.level_line else 2.79
        color = 'faixa' if stage == 1 and not mode.level_line else 'chumbo' if stage == 3 else 'prata'
        model.box(head, (x, cheek_y + .32, -3.12), (.91, height, 2.01), color, (3, 0, side * -12))
        if stage != 1 or mode.level_line:
            texture = 'bochecha' if stage == 2 else 'tufo_cinza' if stage == 3 else 'tufo_prata'
            model.card(head, (x - side * .19, cheek_y - .16, -4.39), (.99 if stage == 1 else 1.42, height, .14),
                       texture, rotation=(0, -side * 11, side * -15))
        if stage == 2:
            model.strand(head, (x - side * .44, 27.65, -4.55), (x + side * .06, 28.78, -4.24),
                         .22, .13, 'azul')
        if stage != 1 or not mode.level_line:
            fang_height = 1.83 if stage == 3 and mode.level_line else 1.39 if stage == 3 else 1.16
            spacing = 2.41 if stage == 3 else 3.44
            z = -5.14 if stage == 3 else -4.52
            model.card(head, (side * spacing, 25.16 + .18 * (1.60 - fang_height), z),
                       (.82 if stage == 3 else .68, fang_height, .14), 'presa', rotation=(-7, 0, side * -10))


def shoulder_fur(model, bone, side, y, z, dense=False, short=False):
    color = 'pelo_escuro' if dense else 'pelo'
    model.box(bone, (side * 6.04, y, z), (3.82, 1.01, 4.12), color, (0, 0, side * 9), up='pelo_frio' if dense else 'prata')
    tufts = (
        ((5.02, y + .13, z - 1.87), (4.44, y - 1.16, z - 2.09), 1.30),
        ((6.25, y + .25, z - 1.96), (6.08, y - 1.52, z - 2.28), 1.59),
        ((7.18, y + .20, z + .22), (8.27 if dense else 8.10, y - .61, z - .16), 1.59),
        ((6.23, y + .33, z + 1.90), (6.73, y - 1.41, z + 2.24), 1.91),
    )
    if short:
        tufts = (tufts[0], tufts[3])
    for index, (root, tip, width) in enumerate(tufts):
        texture = ('tufo_cinza', 'tufo_marfim', 'tufo_escuro', 'tufo_sombra')[index] if dense else 'tufo_prata'
        start = (side * root[0], root[1], root[2])
        end = (side * tip[0], tip[1], tip[2])
        model.strand(bone, start, end, width, .39, texture, cutout=True)


def torso(model):
    mode = model.mode
    y = 21.9
    if mode.stage == 1 and mode.level_line:
        model.box('body', (0, 22.74, .01), (7.72, 1.01, 4.38), 'naval')
        model.box('body', (0, 18.08, 1.97), (7.68, 7.28, .44), 'naval', up='naval_claro')
        for side, _, _, _ in SIDES:
            model.box('body', (side * 2.49, 19.27, -2.10), (2.69, 6.75, .40), 'naval', (0, 0, side * -6))
            model.card('body', (side * 2.51, 19.41, -2.34), (2.65, 5.86, .09), 'tecido_colete', rotation=(0, 0, side * -6))
            model.box('body', (side * 2.56, 22.19, -2.36), (1.49, .69, .43), 'costura', (0, 0, side * -6))
    elif mode.stage == 2 and mode.level_line:
        model.box('body', (0, 22.97, -1.94), (6.87, 1.38, .42), 'naval')
        model.box('body', (1.57, 22.54, -2.15), (2.13, .33, .17), 'faixa', (0, 0, -12))
    elif mode.stage == 3:
        mantle = model.bone('ht_manto_dorso', 'body', (0, 22.49, 2.04))
        model.box(mantle, (0, 21.65, 2.02), (6.61, 3.11 if mode.level_line else 2.32, .91), 'pelo_escuro')
        for side, _, _, _ in SIDES:
            extra = .43 if mode.level_line else 0
            model.strand(mantle, (side * 2.69, 22.91, 2.19), (side * 2.49, 18.21 - extra, 2.78),
                         2.87, .73, 'tufo_cinza', cutout=True)
            model.strand(mantle, (side * 1.07, 22.61, 2.48), (side * .95, 19.84, 2.88), 2.18, .47, 'tufo_sombra', cutout=True)
            model.box('body', (side * 3.53, 21.41, -1.79), (1.54, 4.36, .91), 'chumbo', (0, 0, side * -9))
            model.strand('body', (side * 3.41, y + 1.43, -2.22), (side * 2.75, y - 3.37, -2.51),
                         2.31 if mode.level_line else 1.91, .48, 'tufo_escuro', cutout=True)
            model.strand('body', (side * 3.55, y + 1.46, -2.24), (side * 2.60, y - 1.62, -2.63),
                         1.64, .27, 'tufo_sombra' if mode.level_line else 'tufo_cinza', cutout=True)
            model.strand('body', (side * 3.71, y - .83, -2.49), (side * 3.20, y - 2.28, -2.61), .20, .14, 'violeta')
        model.sway(mantle, 1.05, .6)


def sleeves(model):
    mode = model.mode
    for side, label, arm, _ in SIDES:
        if mode.stage == 1:
            shoulder_fur(model, arm, side, 23.36 if mode.level_line else 23.69, 0, short=mode.level_line)
            cuff = 'carvao' if mode.level_line else 'faixa'
            model.box(arm, (side * 5.96, 15.26, 0), (4.18, 2.37, 4.21), cuff)
            model.box(arm, (side * 5.96, 14.29, -.01), (4.25, .44, 4.27), 'faixa' if mode.level_line else 'bandagem')
            if not mode.level_line:
                model.strand(arm, (side * 7.72, 14.88, -1.41), (side * 8.14, 13.55, -1.91), 1.21, .36, 'tufo_prata', cutout=True)
            continue
        if mode.stage == 2:
            collar = 'sombra' if mode.level_line else 'prata'
            model.box(arm, (side * 6.10, 23.56, -.03), (3.95, 1.06, 4.38), 'naval', (3, 0, side * 10), up=collar)
            model.box(arm, (side * 6.18, 22.98, -2.18), (3.49, .47, .33), collar, (3, 0, side * 10))
            if mode.level_line and side == -1:
                model.box(arm, (side * 6.40, 23.53, -.48), (2.99, .62, 3.29), 'sombra', (8, 0, -12), up='prata')
            model.box(arm, (side * 5.98, 15.43, .01), (4.37, 2.94, 4.39), 'carvao' if mode.level_line else 'naval')
            model.box(arm, (side * 5.98, 14.18, 0), (4.45, .58, 4.48), 'sombra')
            point_x = side * (6.99 if mode.level_line else 7.25)
            height = 2.36 if mode.level_line else 2.77
            model.box(arm, (point_x, 15.13, -2.32), (1.18, .91, .52), 'prata', (0, 0, side * 13))
            model.card(arm, (point_x, 14.47, -2.65), (1.31, height, .14), 'garra', rotation=(5, 0, side * 10))
            if not mode.level_line:
                model.card(arm, (side * 6.22, 14.29, -2.42), (.91, 1.73, .16), 'garra', rotation=(6, 0, side * -8))
            continue
        mantle = model.bone(f'ht_manto_{label}', arm, (side * 6.08, 23.37, 0))
        shoulder_fur(model, mantle, side, 23.60, 0., dense=True)
        model.sway(mantle, 1.25, side * 1.5)
        if mode.level_line:
            model.strand(arm, (side * 4.96, 22.56, -1.84), (side * 4.61, 24.92, -.28),
                         1.60, .61, 'tufo_sombra', cutout=True)
        model.box(arm, (side * 5.98, 15.38, .01), (4.49, 3.79, 4.50), 'chumbo')
        model.box(arm, (side * 5.99, 14.58, -.09), (4.57, 1.80, 4.55), 'carvao')
        model.box(arm, (side * 6.03, 16.44, -2.23), (2.98, 1.53, .63), 'grafite', (0, 0, side * -8))
        for i in range(2 + int(mode.level_line)):
            x = side * (5.25 + i * .72)
            model.card(arm, (x, 14.17 - .16 * i, -2.51), (.71, 2.19 + .19 * i, .16), 'garra',
                       rotation=(8 + i * 3, 0, side * (3 + i * 5)))
        model.strand(arm, (side * 7.52, 20.79, -2.06), (side * 6.99, 18.10, -2.14),
                     .26, .16, 'violeta')


def legs(model):
    if model.mode.stage != 3:
        return
    for side, _, _, leg in SIDES:
        if model.mode.level_line:
            model.box(leg, (side * 3.52, 8.93, -.11), (.97, 2.82, 3.29), 'pelo_escuro', (0, 0, side * 7))
            model.strand(leg, (side * 3.43, 9.84, -1.78), (side * 4.06, 7.54, -1.93),
                         1.40, .38, 'tufo_cinza', cutout=True)
            model.box(leg, (side * 2.02, 2.00, .02), (4.25, .87, 4.22), 'pelo_escuro')
            model.strand(leg, (side * 3.06, 2.13, -1.97), (side * 4.09, 1.23, -2.11),
                         1.57, .31, 'tufo_marfim', cutout=True)
        else:
            model.box(leg, (side * 2.04, 6.40, -1.95), (3.19, 2.41, .67), 'grafite', (0, 0, side * 7))
            model.strand(leg, (side * 2.72, 7.04, -2.29), (side * 3.50, 5.50, -2.58),
                         1.79, .35, 'tufo_cinza', cutout=True)


def lightning(model):
    for label, windows in model.mode.pulses.items():
        hand, style = label.split('_')
        side = -1 if hand == 'd' else 1
        arm = 'rightArm' if side < 0 else 'leftArm'
        wrist = (side * 5.99, 13.03, -1.97)
        bone = model.bone(f'ht_fx_{label}', arm, wrist)
        width = .16 if side < 0 else .12
        rise = .78 if model.mode.level_line else 1.0
        breadth = .85 if side > 0 else 1.0
        if model.mode.stage == 3:
            rise *= .94
        if style == 'a':
            main = ((-.84, -.81, -.34), (-.19, -.48, -1.20), (.84, -.68, -1.19), (1.91, -.11, -.88),
                    (2.51, .51, -.59), (1.91, 1.34, -.61), (2.20, 2.09, -.26), (1.57, 3.03, -.47))
            branches = (main[3:4] + ((2.78, -.43, -.46), (3.03, .24, -.15)),
                        main[5:6] + ((2.68, 1.36, .02), (2.83, 1.96, .34)))
        else:
            main = ((1.61, -.58, -1.07), (.91, -.10, -1.34), (-.16, -.07, -1.31), (-1.22, .49, -.89),
                    (-2.10, 1.33, -.84), (-1.48, 1.90, -.61), (-1.85, 2.73, -.21))
            branches = (main[2:3] + ((.84, .27, -.70), (1.26, .96, -.84)),
                        main[4:5] + ((-2.42, 1.69, -.26), (-2.57, 2.36, .04)))
        for path_index, polyline in enumerate((main, *branches)):
            points = [(wrist[0] + side * dx * breadth, wrist[1] + dy * rise, wrist[2] + dz)
                      for dx, dy, dz in polyline]
            for index, (a, b) in enumerate(zip(points, points[1:])):
                core = path_index == 0 and index < 4
                thick = width * (1.35 if core else .76 if path_index == 0 else .55)
                color = f"{'centro' if core else 'raio'}_{model.mode.color}"
                model.strand(bone, a, b, thick, thick, color)
        frames = {'0.0': [0, 0, 0]}
        for start, end in windows:
            frames[str(round(start - .02, 2))] = [0, 0, 0]
            frames[str(start)] = [1, 1, 1]
            frames[str(end)] = [1, 1, 1]
            frames[str(round(end + .02, 2))] = [0, 0, 0]
        frames[str(model.mode.length)] = [0, 0, 0]
        model.channels[bone] = {'scale': frames}


def create_model(mode):
    model = Wearable(mode)
    head = model.bone('ht_mascara', 'head', (0, 28, 0))
    hair(model, head)
    ears(model, head)
    mask(model, head)
    torso(model)
    sleeves(model)
    legs(model)
    lightning(model)
    return model
