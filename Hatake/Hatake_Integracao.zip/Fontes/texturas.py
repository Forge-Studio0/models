"""Atlas com recortes de pelagem, tecido, máscaras e filamentos Hatake."""

from PIL import Image, ImageDraw


SIZE = 256
TILE = 32
SWATCHES = {
    'prata': (197, 208, 216), 'gelo': (228, 233, 235), 'sombra': (133, 149, 163),
    'pelo': (177, 184, 190), 'pelo_frio': (104, 119, 132), 'pelo_escuro': (57, 65, 77),
    'chumbo': (53, 61, 72), 'grafite': (68, 77, 89), 'carvao': (34, 41, 52),
    'faixa': (82, 93, 107), 'bandagem': (118, 130, 142), 'naval': (37, 49, 66),
    'colete': (84, 103, 97), 'costura': (104, 119, 110), 'naval_claro': (58, 72, 90),
    'marfim': (220, 219, 208), 'nariz': (37, 44, 55), 'azul': (58, 104, 143),
    'violeta': (159, 103, 210), 'raio_azul': (67, 201, 255), 'centro_azul': (216, 248, 255),
    'raio_roxo': (172, 92, 247), 'centro_roxo': (242, 203, 255),
}
FUR = {'tufo_gelo': 'gelo', 'tufo_prata': 'prata', 'tufo_cinza': 'pelo_frio',
       'tufo_escuro': 'pelo_escuro', 'tufo_marfim': 'marfim', 'tufo_sombra': 'pelo'}
EARS = ('orelha_branca', 'orelha_prata', 'orelha_escura', 'orelha_costas')
FANGS = ('presa', 'garra')
PANELS = ('máscara', 'máscara_cinza', 'focinho', 'bochecha', 'placa_shinobi', 'tecido_colete')
TILES = {key: i for i, key in enumerate((*SWATCHES, *FUR, *EARS, *FANGS, *PANELS, 'transparente'))}


def shift(color, amount):
    return tuple(min(255, max(0, channel + amount)) for channel in color) + (255,)


def material(name):
    color = SWATCHES[name]
    image = Image.new('RGBA', (TILE, TILE))
    if name.startswith(('raio_', 'centro_')):
        return Image.new('RGBA', (TILE, TILE), (*color, 255))
    image.putdata([
        shift(color, (15 - y) // 3 + ((x * 5 + y * 11 + x * y) % 7 - 3))
        for y in range(TILE) for x in range(TILE)
    ])
    d = ImageDraw.Draw(image)
    if name in ('faixa', 'bandagem', 'naval', 'naval_claro'):
        for y in (5, 13, 22, 29):
            d.line(((0, y + 1), (31, y - 1)), fill=shift(color, -14))
            d.line(((0, y + 2), (31, y)), fill=shift(color, 8))
    if name in ('colete', 'costura', 'grafite', 'chumbo'):
        d.line(((4, 27), (4, 4), (27, 4)), fill=shift(color, 12))
        d.line(((4, 27), (27, 27), (27, 4)), fill=shift(color, -12))
    return image


def fur(name, line):
    color = SWATCHES[FUR[name]]
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    tip = 13 + line % 5
    d.polygon(((2, 30), (5, 22), (7, 16), (tip, 1), (tip + 2, 6), (tip + 5, 11),
               (22, 18), (29, 29), (24, 30), (18, 28), (14, 30)), fill=shift(color, -12))
    d.polygon(((5, 27), (9, 18), (tip, 3), (tip + 4, 12), (22, 24), (24, 27), (15, 26), (12, 29)),
              fill=shift(color, 2))
    d.polygon(((8, 25), (12, 19), (tip, 7), (tip + 2, 14), (18, 22), (13, 22)), fill=shift(color, 14))
    d.line(((8, 24), (10, 19), (tip - 1, 10)), fill=shift(color, 25))
    d.line(((21, 25), (18, 19), (tip + 3, 15)), fill=shift(color, -7))
    return image


def ear(name):
    outer, inner = {
        'orelha_branca': ('gelo', (88, 96, 111)),
        'orelha_prata': ('prata', (101, 119, 139)),
        'orelha_escura': ('pelo', (72, 61, 86)),
        'orelha_costas': ('prata', (172, 185, 195)),
    }[name]
    color = SWATCHES[outer]
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    d.polygon(((2, 29), (5, 22), (8, 17), (15, 1), (16, 2), (20, 13), (24, 20),
               (29, 29), (25, 30), (21, 28), (17, 30), (12, 28), (7, 30)), fill=shift(color, -13))
    d.polygon(((4, 27), (9, 18), (15, 3), (19, 12), (25, 24), (26, 27), (15, 28)), fill=shift(color, 6))
    d.polygon(((8, 26), (11, 18), (15, 8), (19, 16), (23, 26)), fill=shift(inner, -10))
    d.polygon(((12, 23), (15, 11), (18, 19), (19, 23), (16, 25)), fill=shift(inner, 10))
    d.line(((6, 26), (10, 19), (14, 8)), fill=shift(color, 21))
    return image


def fang(name):
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    tone = SWATCHES['marfim' if name == 'presa' else 'prata']
    # O recorte fica mais estreito embaixo e volta em curva para a mão.
    d.polygon(((3, 1), (28, 1), (27, 13), (23, 22), (15, 30), (11, 30),
               (13, 24), (11, 17), (6, 12)), fill=shift(tone, -30))
    d.polygon(((6, 2), (24, 2), (23, 14), (19, 22), (13, 28), (15, 24), (13, 16)), fill=shift(tone, 5))
    d.line(((21, 2), (21, 12), (17, 21), (13, 28)), fill=shift(tone, 26), width=2)
    return image


def panel(name, level):
    color = SWATCHES[{
        'máscara': 'carvao', 'máscara_cinza': 'chumbo', 'focinho': 'grafite',
        'bochecha': 'prata', 'placa_shinobi': 'prata', 'tecido_colete': 'colete',
    }[name]]
    image = Image.new('RGBA', (TILE, TILE))
    d = ImageDraw.Draw(image)
    if name == 'bochecha':
        d.polygon(((1, 3), (30, 1), (28, 12), (21, 21), (19, 28), (8, 30), (3, 21)), fill=shift(color, -13))
        d.polygon(((3, 4), (27, 3), (26, 10), (18, 20), (17, 27), (9, 28), (6, 20)), fill=shift(color, 8))
        d.line(((6, 9), (13, 12), (17, 16), (20, 15), (23, 10)), fill=shift(SWATCHES['azul'], -8), width=2)
        return image
    d.polygon(((2, 8), (6, 4), (13, 4), (16, 1), (19, 4), (25, 4), (29, 8), (30, 22),
               (26, 27), (17, 30), (14, 30), (5, 27), (1, 22)), fill=shift(color, -15))
    d.polygon(((4, 8), (14, 7), (16, 4), (18, 7), (26, 8), (28, 21), (23, 25),
               (16, 28), (7, 25), (3, 21)), fill=shift(color, 1))
    if name in ('máscara', 'máscara_cinza', 'focinho'):
        d.line(((4, 12), (10, 13), (15, 14), (21, 13), (27, 12)), fill=shift(color, 16), width=2)
        d.line(((7, 20), (12, 21), (15, 24), (19, 22), (24, 20)), fill=shift(color, -13), width=2)
        if name == 'focinho':
            d.polygon(((10, 9), (22, 9), (23, 13), (18, 18), (14, 18), (9, 13)), fill='#20252f')
            d.line(((10, 10), (21, 10)), fill='#576370', width=2)
    if name == 'placa_shinobi':
        d.polygon(((4, 9), (27, 9), (28, 22), (21, 25), (9, 25), (3, 21)), fill='#939faa')
        d.line(((6, 11), (25, 11)), fill='#d3dce3')
        d.rectangle((6, 16, 7, 18), fill='#536475')
        d.rectangle((24, 16, 25, 18), fill='#536475')
        if level:
            d.line(((12, 18), (10, 15), (16, 13), (20, 16), (17, 20), (14, 18), (16, 15), (18, 16)),
                   fill='#4d5c65', width=1)
            d.line(((12, 18), (11, 21), (15, 20)), fill='#4d5c65')
    if name == 'tecido_colete':
        d.line(((4, 11), (25, 11)), fill=shift(color, 18), width=2)
        d.rectangle((6, 14, 24, 23), fill=shift(color, -10))
        d.line(((7, 15), (23, 15), (23, 22)), fill=shift(color, 8))
        d.point((15, 18), fill='#c0c1ae')
    return image


def atlas(mode):
    image = Image.new('RGBA', (SIZE, SIZE))
    for name, i in TILES.items():
        if name in SWATCHES:
            tile = material(name)
        elif name in FUR:
            tile = fur(name, mode.index)
        elif name in EARS:
            tile = ear(name)
        elif name in FANGS:
            tile = fang(name)
        elif name in PANELS:
            tile = panel(name, mode.level_line)
        else:
            continue
        row, col = divmod(i, SIZE // TILE)
        image.paste(tile, (col * TILE, row * TILE))
    return image


def spark_texture(color):
    image = Image.new('RGBA', (16, 16))
    d = ImageDraw.Draw(image)
    tone = SWATCHES['raio_' + color]
    d.line(((3, 15), (8, 10), (6, 8), (12, 2)), fill=(*tone, 115), width=4)
    d.line(((3, 14), (9, 10), (7, 8), (12, 2)), fill=(*tone, 220), width=2)
    d.line(((5, 13), (9, 10), (7, 8), (11, 4)), fill=(*SWATCHES['centro_' + color], 255))
    return image
