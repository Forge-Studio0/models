/* Exercita a exibição das peças, as faíscas e a restauração do cabelo. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { Molang, Context } = require('molang');

const root = path.resolve(__dirname, '..');
const rp = path.join(root, 'Integracao', 'RP');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const modes = Object.values(read(path.join(root, 'Integracao_Manifesto.json')).modos);
const ids = modes.map(mode => mode.id);
const controller = read(path.join(rp, 'render_controllers/swbr_hatake.json')).render_controllers['controller.render.swbr.hatake'];
const report = { vestimentas: {}, jogadores: {} };

for (const mode of modes) {
  const desc = read(path.join(rp, mode.attachable))['minecraft:attachable'].description;
  let checked = 0;
  for (const item_slot of ['head', 'main_hand', 'off_hand', 'chest', 'legs', 'feet', '']) {
    for (const is_first_person of [0, 1]) {
      for (const age of [0, 1, 2]) {
        for (const [is_spectator, is_invisible] of [[0, 0], [1, 0], [0, 1]]) {
          const makeContext = slot => ({
            item_slot: slot,
            is_first_person,
            owning_entity: new Context({ query: {
              property: name => name === 'nzs:body_age' ? age : 0,
              is_spectator,
              is_invisible,
            } }),
          });
          const molang = new Molang({ context: makeContext(item_slot) }, { useCache: false });
          const evaluate = expr => Boolean(molang.execute(expr));
          const gate = desc.scripts.pre_animation.join('');
          const visible = item_slot === 'head' && !is_first_person && !is_spectator && !is_invisible;
          molang.execute(gate);
          assert.equal(evaluate(controller.part_visibility[0]['*']), visible, mode.id);
          assert.equal(evaluate(desc.scripts.animate[0].idle), visible, mode.id + ' animação');
          assert.ok(Math.abs(molang.execute(desc.scripts.scale) - .9375 * [1, .87, .70][age]) < 1e-8, mode.id + ' escala');
          molang.updateExecutionEnv({ context: makeContext(''), variable: { swbr_hatake_attachable: 1 } });
          molang.execute(gate);
          assert.equal(evaluate(controller.part_visibility[0]['*']), false, mode.id + ' retirado');
          assert.equal(evaluate(desc.scripts.animate[0].idle), false, mode.id + ' animação após retirada');
          checked++;
        }
      }
    }
  }
  report.vestimentas[mode.id] = { contextos: checked, desequipamentos: checked };
}

for (const variant of ['original', 'cumulativa']) {
  const files = path.join(root, 'Integracao', 'Edicoes', variant, 'RP');
  const player = read(path.join(files, 'entity/player.entity.json'))['minecraft:client_entity'].description;
  const renderer = read(path.join(files, 'render_controllers/player.json')).render_controllers['controller.render.player.third_person'];
  const hat = Object.assign({}, ...renderer.part_visibility).hat;
  const gates = player.scripts.pre_animation.filter(statement => /^v\.swbr_hatake_(vista|cabelo) =/.test(statement)).join('');
  const stages = new Map(modes.filter(mode => mode.cor).map(mode => ['hatake_faiscas_' + mode.chave, mode.id]));
  const sparks = Object.assign({}, ...player.scripts.animate.filter(track => typeof track !== 'string'));
  const suffix = ' && !v.swbr_hatake_cabelo';
  const cosmetics = player.render_controllers.flatMap(layer => typeof layer === 'string' ? [] : Object.entries(layer))
    .filter(([, condition]) => typeof condition === 'string' && condition.endsWith(suffix));
  assert.equal(cosmetics.length, 28);
  let checked = 0;
  for (const gear of ['', ...ids, 'minecraft:iron_helmet', 'nz:modo_sarutobi_v1']) {
    for (const mode of [{}, { first: 1 }, { map: 1 }, { spectator: 1 }, { invisible: 1 }]) {
      let equipped = gear;
      const env = {
        variable: { swbr_view_first_person: mode.first || 0, swbr_view_map_face: mode.map || 0 },
        query: { property: () => 0, is_spectator: mode.spectator || 0, is_invisible: mode.invisible || 0,
          is_item_name_any: (slot, index, ...items) => Number(slot === 'slot.armor.head' && index === 0 && items.includes(equipped)) },
      };
      const molang = new Molang(env, { useCache: false });
      const evaluate = expr => Boolean(molang.execute(expr));
      const inView = Object.keys(mode).length === 0;
      const covered = ids.includes(gear) && inView;
      molang.execute(gates);
      assert.equal(evaluate('v.swbr_hatake_cabelo'), covered, `${gear} cabelo`);
      assert.equal(evaluate(hat), !covered, `${gear} camada externa da cabeça`);
      for (const [key, id] of stages) {
        assert.equal(evaluate(sparks[key]), inView && id === gear, `${gear} ${key}`);
      }
      equipped = '';
      molang.execute(gates);
      assert.equal(evaluate('v.swbr_hatake_cabelo'), false, `${gear} cabelo restaurado`);
      assert.equal(evaluate(hat), true, `${gear} camada da cabeça restaurada`);
      for (const key of stages.keys()) assert.equal(evaluate(sparks[key]), false, 'faíscas após retirada');
      checked++;
    }
  }
  report.jogadores[variant] = { contextos: checked, camadas_de_cabelo: cosmetics.length, animacoes_de_faiscas: stages.size };
}

fs.writeFileSync(path.join(root, 'Validacao_Molang.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
