import {injuryAwareItemUse} from './rp_v18711_cast_windup.js';
import { emitParticle } from "./rp_v18347_visual_budget.js";
import { world, system, Player, EquipmentSlot } from "@minecraft/server";
import { applyVirtualSafeDamage } from "./rp_v131_safe_health.js";
import { watchEntityTypes, loadedEntities } from "./rp_v18341_loaded_entities.js";

// v170 — runtime leve dos modos de clã + Akamaru.
// Nenhum modo de clã consome chakra passivamente neste módulo.
const DOG="nzx:akamaru_companion", GATSUGA="nz:jutsu_gatsuuga_rp";
watchEntityTypes(DOG);
const INUZUKA=new Set(["nz:modo_inuzuka_presa_selvagem","nz:modo_inuzuka_fera","nz:modo_inuzuka_lobo_alfa"]);
const NARA=new Set(["nz:modo_nara_sombras","nz:modo_nara_sombra_profunda","nz:modo_nara_eclipse_sombrio"]);
const YUKI=new Set(["nz:modo_yuki_hyoton","nz:modo_yuki_criogenico","nz:modo_yuki_zero_absoluto"]);
const SARUTOBI=new Set(["nz:modo_sarutobi_vontade_fogo","nz:modo_sarutobi_guardiao_enma","nz:modo_sarutobi_rei_macaco"]);
const dogs=new Map(), assistCd=new Map();
let auraTick=0;

function valid(e){try{if(!e)return false;if(typeof e.isValid==="function")return e.isValid();if(typeof e.isValid==="boolean")return e.isValid;return !!e.id;}catch{return false;}}
function head(p){try{return p.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot.Head)?.typeId||"";}catch{return "";}}
// Mobile: only the cosmetic pulse is throttled; aura debuffs keep their original cadence.
const mobileAuraLast = new Map();
function particle(p,id,dy=.75){
 const now=system.currentTick, last=mobileAuraLast.get(p.id);
 if(last!==undefined && now-last<40)return;
 mobileAuraLast.set(p.id,now);
 try{emitParticle(p.dimension,id,{x:p.location.x,y:p.location.y+dy,z:p.location.z});}catch{}
}
function sound(p,id,v=.55,pitch=1){try{p.playSound(id,{volume:v,pitch});}catch{}}
function damage(e,a,p){try{applyVirtualSafeDamage(e,a,{cause:"entityAttack",damagingEntity:p});}catch{}}
function knock(e,x,z,f=.75,up=.15){const l=Math.max(.01,Math.hypot(x,z));try{e.applyKnockback(x/l,z/l,f,up);}catch{}}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);}
function tagFor(p){return `nz170_ak_${String(p.id).replace(/[^A-Za-z0-9_]/g,"_").slice(-30)}`;}
function score(p,name){try{return Number(world.scoreboard.getObjective(name)?.getScore(p.scoreboardIdentity)||0);}catch{return 0;}}
function getDog(p){
 const cached=dogs.get(p.id);if(valid(cached))return cached;dogs.delete(p.id);
 const tag=tagFor(p);
 try{for(const e of loadedEntities(DOG)){if(e.dimension.id===p.dimension.id&&valid(e)&&e.hasTag(tag)){dogs.set(p.id,e);return e;}}}catch{}
 return undefined;
}
function removeDog(p){
 const d=getDog(p);
 if(d){try{d.triggerEvent("nzx:despawn");}catch{try{d.remove();}catch{}}}
 dogs.delete(p.id);
}
function ensureDog(p){
 if(!INUZUKA.has(head(p))){if(getDog(p))removeDog(p);return;}
 const d=getDog(p);if(!d)return;
 try{
  const pl=p.location,dl=d.location;
  if(d.dimension.id!==p.dimension.id||dist(pl,dl)>12){const v=p.getViewDirection();d.teleport({x:pl.x-v.x*1.8,y:pl.y,z:pl.z-v.z*1.8},{dimension:p.dimension});}
 }catch{}
}
function nearTargets(p,r){
 const out=[];try{for(const e of p.dimension.getEntities({location:p.location,maxDistance:r})){if(!valid(e)||e.id===p.id||e.typeId===DOG||e.typeId==="minecraft:item"||e.typeId==="minecraft:xp_orb")continue;out.push(e);}}catch{}return out;
}
function aura(p,m,heavy){
 // Apenas uma partícula por pulso; em servidor cheio o intervalo dobra.
 if(INUZUKA.has(m)) particle(p,"nz:chakra",.18);
 else if(YUKI.has(m)) particle(p,"nz:hyouton_lightblue",.55);
 else if(NARA.has(m)) particle(p,"nz:sombra_rp",.12);
 else if(SARUTOBI.has(m)) particle(p,"nz:fogo",.5);
 if(!heavy)return;
 // Debuffs de aura são leves e processados 1x/s, apenas para os estágios que os pedem.
 if(m==="nz:modo_nara_sombra_profunda") for(const e of nearTargets(p,4.5))try{e.addEffect("slowness",30,{amplifier:0,showParticles:false});}catch{}
 if(m==="nz:modo_nara_eclipse_sombrio") for(const e of nearTargets(p,5.5))try{e.addEffect("slowness",35,{amplifier:1,showParticles:false});}catch{}
 if(m==="nz:modo_yuki_hyoton") for(const e of nearTargets(p,4.0))try{e.addEffect("slowness",25,{amplifier:0,showParticles:false});}catch{}
 if(m==="nz:modo_yuki_zero_absoluto") for(const e of nearTargets(p,5.0)){try{e.addEffect("slowness",35,{amplifier:2,showParticles:false});}catch{} try{e.addEffect("weakness",30,{amplifier:0,showParticles:false});}catch{}}
}

// Limpeza de entidades antigas deixadas por builds anteriores. Na v170.5 Akamaru passa a ser invocado por jutsu, não automaticamente.
system.runTimeout(()=>{for(const dimName of ["overworld","nether","the_end"]){try{for(const e of world.getDimension(dimName).getEntities({type:DOG}))e.remove();}catch{}}},10);

system.runInterval(()=>{
 auraTick++;
 const ps=[...world.getAllPlayers()], crowded=ps.length>=8;
 for(const p of ps){
  ensureDog(p);
  const m=head(p);
  if(!m)continue;
  if(crowded && auraTick%2)continue;
  aura(p,m,auraTick%2===0);
 }
},10);

// Akamaru auxilia golpes físicos com dano moderado e cooldown próprio.
world.afterEvents.entityHitEntity.subscribe(ev=>{
 const p=ev.damagingEntity,t=ev.hitEntity;if(!(p instanceof Player)||!valid(t)||!INUZUKA.has(head(p)))return;
 const d=getDog(p);if(!d)return;const now=system.currentTick;if((assistCd.get(p.id)||0)>now)return;assistCd.set(p.id,now+30);
 const stage=head(p)==="nz:modo_inuzuka_lobo_alfa"?3:head(p)==="nz:modo_inuzuka_fera"?2:1;
 system.runTimeout(()=>{
  if(!valid(p)||!valid(d)||!valid(t))return;
  try{const tl=t.location,dl=d.location;if(d.dimension.id!==t.dimension.id||dist(tl,dl)>16)return;const dx=tl.x-dl.x,dz=tl.z-dl.z,l=Math.max(.1,Math.hypot(dx,dz));d.teleport({x:tl.x-dx/l*1.15,y:tl.y,z:tl.z-dz/l*1.15},{dimension:t.dimension});damage(t,3+stage,p);knock(t,dx,dz,.55,.12);sound(p,"mob.wolf.growl",.4,1.1);}catch{}
 },4);
});

// O dano real de Akamaru acompanha o Ninjutsu do dono (20–520). A entidade usa
// dano base 1; este complemento evita centenas de variantes de entidade e mantém
// a progressão leve para servidores com pouca memória.
world.afterEvents.entityHitEntity.subscribe(ev=>{
 const d=ev.damagingEntity,t=ev.hitEntity;if(d?.typeId!==DOG||!valid(t))return;
 let owner;
 try{for(const p of world.getAllPlayers()){if(d.hasTag(tagFor(p))){owner=p;break;}}}catch{}
 if(!owner)return;
 let desired=0;
 try{desired=Number(d.getDynamicProperty("nzs_akamaru_damage")||0);}catch{}
 if(!desired)desired=Math.max(20,Math.min(520,Math.round(20+score(owner,"ninjutsu")*.25)));
 if(desired>1)damage(t,desired-1,owner);
});

// Zero Absoluto: ataques confirmados congelam/retardam o alvo.
world.afterEvents.entityHitEntity.subscribe(ev=>{
 const p=ev.damagingEntity,t=ev.hitEntity;if(!(p instanceof Player)||!valid(t)||head(p)!=="nz:modo_yuki_zero_absoluto")return;
 try{t.addEffect("slowness",50,{amplifier:4,showParticles:false});}catch{}
});

// Gatsūga Duplo somente depois do runtime principal confirmar chakra e cooldown.
world.afterEvents.itemUse.subscribe(injuryAwareItemUse(ev=>{
 const p=ev.source;if(!(p instanceof Player)||ev.itemStack?.typeId!==GATSUGA||!INUZUKA.has(head(p)))return;
 system.runTimeout(()=>{
  if(!valid(p)||!p.hasTag("nzx_gatsuuga_cast_ok"))return;
  try{p.removeTag("nzx_gatsuuga_cast_ok");}catch{}
  const d=getDog(p);if(!d)return;
  const m=head(p),stage=m==="nz:modo_inuzuka_lobo_alfa"?3:m==="nz:modo_inuzuka_fera"?2:1;
  const origin={...p.location},v=p.getViewDirection(),hit=new Set();
  try{p.onScreenDisplay?.setActionBar("§6Gatsūga Duplo §f— Akamaru!");}catch{}
  sound(p,"mob.wolf.growl",.6,.95);
  for(let step=1;step<=4;step++)system.runTimeout(()=>{
   if(!valid(p)||!valid(d))return;
   const q={x:origin.x+v.x*(1.4+step*.95),y:origin.y+.1,z:origin.z+v.z*(1.4+step*.95)};
   try{d.teleport(q,{dimension:p.dimension});}catch{}
   if(step%2===0)try{emitParticle(p.dimension, "nz:vento",{x:q.x,y:q.y+.65,z:q.z});}catch{}
   try{for(const e of p.dimension.getEntities({location:q,maxDistance:1.8})){if(!valid(e)||e.id===p.id||e.typeId===DOG||hit.has(e.id))continue;hit.add(e.id);damage(e,4+stage*2,p);knock(e,v.x,v.z,.8,.18);}}catch{}
  },step*2);
  system.runTimeout(()=>{if(valid(d)&&valid(p)){const l=p.location;try{d.teleport({x:l.x-v.x*1.8,y:l.y,z:l.z-v.z*1.8},{dimension:p.dimension});}catch{}}},14);
 },1);
}));

world.afterEvents.playerLeave.subscribe(ev=>{dogs.delete(ev.playerId);assistCd.delete(ev.playerId);mobileAuraLast.delete(ev.playerId);});
