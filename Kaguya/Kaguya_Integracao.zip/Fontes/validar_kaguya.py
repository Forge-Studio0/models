#!/usr/bin/env python3
"""Confere os packs, o isolamento da revisão e os encaixes em poses da addon."""

import argparse
import base64
from contextlib import ExitStack
import io
from itertools import product
import json
import math
from pathlib import Path
import re
import subprocess
from zipfile import ZipFile

from PIL import Image

from aplicar_integracao import ROOT, PACK_UUIDS, checked_file, open_packs
from construir_kaguya import (
    FOREST_ANIMATION_PATH, FOREST_ENTITY_PATH, FOREST_GEO_PATH, PARTICLE_ID, PROFILES,
    VISUAL_RUNTIME, WEARABLE_CONDITION, WEARABLE_CONTEXT, WEARABLE_RENDER, WEARABLE_SCALE, save_json,
)
from modelagem import FOREST_ANIMATION, FOREST_ID, MODOS, RIG, create_forest, create_wearable


def check(condition, description):
    if not condition:
        raise AssertionError(description)


def zip_files(archive):
    names = [entry.filename for entry in archive.infolist() if not entry.is_dir()]
    check(len(names) == len(set(names)), 'Entradas repetidas no arquivo ZIP.')
    check(all(not name.startswith('/') and '..' not in name.split('/') for name in names),
          'Caminho inválido no arquivo ZIP.')
    return set(names)


def item_definition(pack, mode_id):
    for name in pack.namelist():
        if name.startswith('items/') and name.endswith('.json'):
            data = pack.read(name)
            if mode_id.encode() not in data:
                continue
            parsed = json.loads(data).get('minecraft:item', {})
            if parsed.get('description', {}).get('identifier') == mode_id:
                return name, parsed
    raise KeyError(mode_id)


def attachable_matches(pack, mode_id):
    paths = []
    for name in pack.namelist():
        if not name.startswith('attachables/') or not name.endswith('.json'):
            continue
        raw = pack.read(name)
        if mode_id.encode() not in raw:
            continue
        desc = json.loads(raw)['minecraft:attachable']['description']
        if desc['identifier'] in (mode_id, mode_id + '.player') or mode_id in desc.get('item', {}):
            paths.append(name)
    return sorted(paths)


def read_json(pack, name):
    return json.loads(pack.read(name))


def open_zip(raw):
    return ZipFile(io.BytesIO(raw))


def compare_packs(source, addon, manifest, base_version):
    before, after = open_packs(source), open_packs(addon)
    spec = manifest['bases'][base_version]
    compare_report = {}
    with ZipFile(source) as a, ZipFile(addon) as b, ExitStack() as stack:
        check(a.testzip() is None and b.testzip() is None, 'CRC da addon inválido.')
        targets = {info['entrada'] for info in spec['packs'].values()}
        additional = zip_files(a) - targets
        expected_outer = additional | {'LEIA-ME_KAGUYA.md'} | {info['saida'] for info in spec['packs'].values()}
        check(zip_files(b) == expected_outer, 'Entradas externas .mcaddon divergentes.')
        for filename in additional:
            check(a.read(filename) == b.read(filename), f'Conteúdo externo alterado: {filename}.')
        packs = {}
        for pack in ('BP', 'RP'):
            src = stack.enter_context(open_zip(before[pack][2]))
            out = stack.enter_context(open_zip(after[pack][2]))
            check(src.testzip() is None and out.testzip() is None, f'CRC inválido no {pack}.')
            packs[pack] = (src, out)
            expected = {p: checked_file(ROOT, info) for p, info in manifest['arquivos'][pack].items()}
            expected['manifest.json'] = checked_file(ROOT, spec['packs'][pack]['manifesto'])
            originals, packaged = zip_files(src), zip_files(out)
            check(packaged == originals | set(expected), f'Arquivos do {pack} divergentes do manifesto.')
            changed = []
            for filename in sorted(packaged):
                final = out.read(filename)
                old = src.read(filename) if filename in originals else None
                check(final == expected.get(filename, old), f'Diferença inesperada em {pack}/{filename}.')
                if old != final:
                    changed.append(filename)
            check(set(changed) == set(expected), f'Overlay {pack} com caminhos redundantes.')
            orig_info, info = before[pack][1], after[pack][1]
            header = info['header']
            check(header['uuid'] == orig_info['header']['uuid'] == PACK_UUIDS[pack], f'UUID do {pack} alterado.')
            check(header['min_engine_version'] == orig_info['header']['min_engine_version'], f'Versão mínima do {pack} alterada.')
            check(header['version'] == manifest['versao'], f'Versão incorreta do {pack}.')
            for entry in info.get('dependencies', []):
                if entry.get('uuid') in PACK_UUIDS.values():
                    check(entry['version'] == manifest['versao'], f'Dependência de versão incorreta no {pack}.')
            for prior, current in zip(orig_info['modules'], info['modules']):
                check(prior['uuid'] == current['uuid'] and current['version'] == manifest['versao'],
                      f'Módulo incorreto no {pack}.')
            compare_report[pack] = {'arquivos': len(packaged), 'alteracoes': changed,
                                    'identicos_a_base': len(packaged) - len(changed)}

        bp_old, bp = packs['BP']
        rp_old, rp = packs['RP']
        rc = read_json(rp, 'render_controllers/swbr_kaguya.json')['render_controllers'][WEARABLE_RENDER]
        check(rc['part_visibility'] == [{'*': WEARABLE_CONDITION}], 'Regra de câmera e slot incorreta.')
        for mode in manifest['modos'].values():
            item_path, item = item_definition(bp, mode['id'])
            check(item['components']['minecraft:wearable']['slot'] == 'slot.armor.head', f'Slot incorreto em {item_path}.')
            check(bp.read(item_path) == bp_old.read(item_path), f'Item original alterado: {item_path}.')
            check(attachable_matches(rp, mode['id']) == sorted(mode['attachables']),
                  f'Vínculos de attachable incorretos: {mode["id"]}.')
            for path in mode['attachables']:
                old, new = (read_json(p, path)['minecraft:attachable']['description'] for p in (rp_old, rp))
                check(new['identifier'] == old['identifier'] and new.get('item') == old.get('item'), path)
                check(new['geometry']['default'] == mode['geometria'] and new['textures']['default'] + '.png' == mode['textura'], path)
                check(new['render_controllers'] == [WEARABLE_RENDER], path)
                check(new['scripts'] == {'pre_animation': [WEARABLE_CONTEXT], 'scale': WEARABLE_SCALE}, path)

        forest_rp = read_json(rp, FOREST_ENTITY_PATH)['minecraft:client_entity']['description']
        forest_bp = read_json(bp, 'entities/refined_sawarabi_no_mai_visual_v18389.json')['minecraft:entity']
        check(forest_rp['identifier'] == forest_bp['description']['identifier'], 'Cliente e servidor do Sawarabi divergem.')
        check(forest_rp['geometry']['default'] == FOREST_ID, 'Geometria do Sawarabi no solo ausente.')
        check(forest_rp['animations']['life'] == FOREST_ANIMATION, 'Animação de surgimento sem vínculo.')
        check(forest_bp['components']['minecraft:timer']['time_down_event']['event'] == 'nzs:expire', 'Timer de limpeza ausente.')
        check('minecraft:instant_despawn' in forest_bp['component_groups']['nzs:remove'], 'Despawn do Sawarabi ausente.')
        check(bp_old.read('scripts/jutsu/rp_creator_combat_v18385.js') == bp.read('scripts/jutsu/rp_creator_combat_v18385.js'),
              'Combate do Sawarabi alterado.')
        check(bp_old.read('scripts/jutsu/rp_creator_catalog_v18385.js') == bp.read('scripts/jutsu/rp_creator_catalog_v18385.js'),
              'Catálogo de técnicas alterado.')

        # Use the actual neutral skin rig, walking, running and jump animations of each base.
        body = read_json(rp, 'models/entity/swbr39/custom.geo.json')['minecraft:geometry'][0]['bones']
        anim = read_json(rp, 'animations/player.json')['animations']
        run = read_json(rp, 'animations/correndo.json')['animations']['animation.player_new.correndo']
        compare_report['poses_amostradas'] = check_poses(body, anim, run)
    return compare_report


def mul_vec(matrix, vec):
    vec = tuple(vec)
    return tuple(sum(a * b for a, b in zip(row, vec)) for row in matrix)


def rotation(angles):
    # Bedrock coordinates from Blockbench's mirrored X and ZYX Euler order.
    x, y, z = (-math.radians(angles[0]), math.radians(angles[1]), -math.radians(angles[2]))
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    return ((cz * cy, cz * sy * sx - sz * cx, cz * sy * cx + sz * sx),
            (sz * cy, sz * sy * sx + cz * cx, sz * sy * cx - cz * sx),
            (-sy, cy * sx, cy * cx))


def around(point, pivot, mat, shift=(0, 0, 0)):
    rotated = mul_vec(mat, (p - o for p, o in zip(point, pivot)))
    return tuple(p + o + d for p, o, d in zip(rotated, pivot, shift))


def vertices(cube):
    mat = rotation(cube.get('rotation', (0, 0, 0)))
    offset = cube['origin']
    return [around(tuple(o + b * s for o, b, s in zip(offset, corner, cube['size'])), cube.get('pivot', offset), mat)
            for corner in product((0, 1), repeat=3)]


def inside_box(point, cube, slack=0):
    return all(o - slack <= p <= o + w + slack for p, o, w in zip(point, cube['origin'], cube['size']))


def inside_segment(point, cube, margin=0):
    mat = rotation(cube['rotation'])
    inverse = tuple(zip(*mat))
    return inside_box(around(point, cube['pivot'], inverse), cube, margin)


def channel_sample(channel, time):
    if isinstance(channel, list):
        return channel
    keys = sorted((float(t), data) for t, data in channel.items())
    if time <= keys[0][0]:
        return keys[0][1]
    for (left, before), (right, after) in zip(keys, keys[1:]):
        if time <= right:
            t = (time - left) / (right - left)
            return [a * (1 - t) + b * t for a, b in zip(before, after)]
    return keys[-1][1]


def check_poses(original_rig, player_animations, run):
    native = {bone['name']: bone for bone in original_rig}
    parent = {name: ancestor for name, ancestor, _ in RIG}
    modes = [(mode, create_wearable(index)) for index, mode in enumerate(MODOS)]
    for name, ancestor, pivot in RIG:
        check(native[name].get('parent') == ancestor and tuple(native[name]['pivot']) == pivot,
              f'Hierarquia e pivô do jogador divergentes: {name}.')
    motions = {
        'repouso': {'animation_length': 0, 'bones': {}},
        'caminhada': player_animations['animation.player_new.andando'],
        'corrida': run,
        'salto': player_animations['animation.player_new.pulo'],
        'agachamento_aproximado': {'animation_length': 1, 'bones': {
            'body': {'rotation': [25, 0, 0], 'position': [0, -2, 0]},
            'head': {'rotation': [-10, 0, 0]},
            'rightArm': {'rotation': [-15, 0, 3]}, 'leftArm': {'rotation': [-15, 0, -3]},
        }},
    }
    report, head_hits = {}, set()
    for action, animation in motions.items():
        times = [animation['animation_length'] * i / 10 for i in range(11)] if animation['animation_length'] else [0]
        tested = 0
        tips_intersections = 0
        tip_hits = set()
        for time in times:
            transforms = {}
            for name in parent:
                tracks = animation['bones'].get(name, {})
                mat = rotation(channel_sample(tracks.get('rotation', [0, 0, 0]), time))
                shift = channel_sample(tracks.get('position', [0, 0, 0]), time)
                transforms[name] = (native[name]['pivot'], mat, shift)

            def world(point, name):
                while name is not None:
                    point = around(point, *transforms[name])
                    name = parent[name]
                return point

            def local(point, name):
                lineage = []
                while name is not None:
                    lineage.append(name)
                    name = parent[name]
                for name in reversed(lineage):
                    pivot, mat, shift = transforms[name]
                    point = around(tuple(p - d for p, d in zip(point, shift)), pivot, tuple(zip(*mat)))
                return point

            for mode, model in modes:
                for name, feature in model.parts.items():
                    driver = feature['parent']
                    origin, tip = feature['root'], feature['tip']
                    body_cube = native[driver]['cubes'][0]
                    # The same anchor falls inside both the SWBR and narrower arm profile.
                    narrow = dict(body_cube)
                    if driver.endswith('Arm'):
                        narrow['origin'] = [body_cube['origin'][0] + (1 if driver == 'rightArm' else 0), *body_cube['origin'][1:]]
                        narrow['size'] = [3, *body_cube['size'][1:]]
                    for skin in (body_cube, narrow):
                        check(inside_box(local(world(origin, driver), driver), skin, .035),
                              f'Base fora do rig {mode.item}/{name}/{action}.')
                    tip_world = world(tip, driver)
                    if any(inside_box(local(world(p, driver), 'head'), native['head']['cubes'][0], -.10)
                           for p in feature['path']):
                        head_hits.add(f'{mode.chave}/{name}/{action}')
                    for part in ('body', 'rightArm', 'leftArm', 'rightLeg', 'leftLeg'):
                        if part != driver and inside_box(local(tip_world, part), native[part]['cubes'][0], -.22):
                            tip_hits.add(f'{mode.chave}/{name}/{part}')
                            tips_intersections += 1
                    tested += 1
        report[action] = {'amostras': len(times), 'ancoras_testadas': tested,
                          'pontas_em_outro_membro': tips_intersections, 'contatos': sorted(tip_hits)}
    check(not head_hits, 'Ossos penetram na cabeça em ' + ', '.join(sorted(head_hits)))
    check(not any(sample['pontas_em_outro_membro'] for sample in report.values()),
          'Pontas em outro membro nas poses amostradas: ' + json.dumps(report, ensure_ascii=False))
    return report


def validate_models(manifest):
    rp = ROOT / 'Integracao/RP'
    projects = ROOT / 'Modelos_Blockbench'
    stats = {}
    for i, (key, mode) in enumerate(manifest['modos'].items()):
        rig = create_wearable(i)
        geometry = json.loads((rp / mode['arquivo_geo']).read_text())['minecraft:geometry'][0]
        bones = geometry['bones']
        by_name = {bone['name']: bone for bone in bones}
        check(len(by_name) == len(bones) == mode['bones'], f'Bones duplicados em {key}.')
        check(geometry['description']['identifier'] == mode['geometria'], f'Identificador errado em {key}.')
        check(sum(len(bone.get('cubes', [])) for bone in bones) == mode['cubos'], f'Contagem de cubos incorreta em {key}.')
        for feature, info in rig.parts.items():
            cubes = by_name[feature]['cubes']
            start = 0 if cubes[0]['pivot'] == info['root'] else 1
            check(inside_segment(info['root'], cubes[start], .02),
                  f'Osso solto na raiz. {key}/{feature}.')
            check(inside_segment(info['tip'], cubes[-1], .02), f'Ponta fora da geometria. {key}/{feature}.')
            for before, after in zip(cubes[start:], cubes[start + 1:]):
                check(inside_segment(after['pivot'], before, .02), f'Intervalo entre segmentos. {key}/{feature}.')
        for b in bones:
            check('parent' not in b or b['parent'] in by_name, f'Parent ausente: {b["name"]}.')
            for cube in b.get('cubes', []):
                check(all(dim > 0 for dim in cube['size']), 'Cubo degenerado.')
                for face in cube['uv'].values():
                    check(all(0 <= v <= v + size <= 256 for v, size in zip(face['uv'], face['uv_size'])), 'UV fora do atlas.')
        img_file = rp / mode['textura']
        with Image.open(img_file) as tex:
            check(tex.size == (256, 256) and tex.getchannel('A').getextrema() == (255, 255), 'Atlas ósseo inválido.')
        bb = json.loads((projects / mode['projeto']).read_text())
        check(bb['meta']['model_format'] == 'bedrock' and len(bb['elements']) == mode['cubos'], 'Projeto Blockbench inválido.')
        check(len(bb['textures']) == 1 and base64.b64decode(bb['textures'][0]['source'].split(',', 1)[1]) == img_file.read_bytes(),
              'Textura embutida diverge do PNG do pack.')
        vtx = [p for b in bones for cube in b.get('cubes', []) for p in vertices(cube)]
        stats[key] = {'id': mode['id'], 'cubos': mode['cubos'], 'projecoes': mode['projecoes'],
                      'extensao_em_blocos': [round((max(a) - min(a)) / 16, 3) for a in zip(*vtx)]}
    check(len(stats) == 5, 'A revisão deve ter cinco modelos próprios.')
    return stats


def validate_forest():
    rp = ROOT / 'Integracao/RP'
    forest, _ = create_forest()
    geometry = json.loads((rp / FOREST_GEO_PATH).read_text())['minecraft:geometry'][0]
    animation = json.loads((rp / FOREST_ANIMATION_PATH).read_text())['animations'][FOREST_ANIMATION]
    by_name = {bone['name']: bone for bone in geometry['bones']}
    check(animation['loop'] == 'hold_on_last_frame', 'O surgimento deve ocorrer uma vez.')
    delays = set()
    tops = set()
    for bone, channels in animation['bones'].items():
        timeline = sorted((float(time), position) for time, position in channels['position'].items())
        cubes = list(by_name[bone]['cubes'])
        for child in by_name.values():
            if child.get('parent') == bone:
                cubes.extend(child.get('cubes', []))
        top = max(p[1] for cube in cubes for p in vertices(cube))
        bottom = min(p[1] for cube in cubes for p in vertices(cube))
        check(bottom < -16 < 0 < top, f'Base do Sawarabi solta do chão: {bone}.')
        check(top + timeline[0][1][1] < 0, f'{bone} já começa acima do terreno.')
        check(timeline[-1][1] == [0, 0, 0] and timeline[-1][0] <= animation['animation_length'], f'{bone} não chega à pose final.')
        check(all(a[1][1] <= b[1][1] for a, b in zip(timeline, timeline[1:])), f'{bone} inverte o surgimento.')
        check(all(p[0] == p[2] == 0 for _, p in timeline), f'{bone} desloca a base no solo.')
        delays.add(timeline[1][0])
        tops.add(round(top, 2))
    check(len(delays) >= 10 and len(tops) >= 10, 'As estacas precisam nascer em tempos e alturas variados.')
    return {'estacas': len(animation['bones']), 'ramificacoes': len(forest.parts) - len(animation['bones']),
            'segundos_surgimento': animation['animation_length'], 'alturas_blocos': [round(min(tops) / 16, 2), round(max(tops) / 16, 2)]}


def validate_particles():
    bp = ROOT / 'Integracao/BP'
    paths = (VISUAL_RUNTIME, PROFILES)
    for path in paths:
        subprocess.run(['node', '--input-type=module', '--check'], input=(bp / path).read_bytes(), check=True)
    runtime = (bp / VISUAL_RUNTIME).read_text()
    activate, passive = runtime.split('function passive(p,key){')
    for key in ('kaguya1', 'kaguya2'):
        fx = re.search(rf'else if\(key==="{key}"\)\{{([^}}]+)\}}', activate).group(1)
        check(PARTICLE_ID in fx and 'snowflake' not in fx and key not in passive, f'Partículas indevidas em {key}.')
    check('snowflake_particle' in passive and 'key==="yuki"' in passive, 'Efeito pré-existente do Yuki alterado.')
    return {'scripts_js_validados': len(paths), 'id_fragmento': PARTICLE_ID}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base64', type=Path)
    parser.add_argument('base72', type=Path)
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'Integracao_Manifesto.json').read_text())
    report = {'minecraft_executado': False, 'modelos': validate_models(manifest),
              'sawarabi': validate_forest(), 'particulas': validate_particles(), 'bases': {}}
    for base, original, addon in (('18.11.64', args.base64, 'Kaguya_Base_18.11.64.mcaddon'),
                                 ('18.11.72', args.base72, 'Kaguya.mcaddon')):
        report['bases'][base] = compare_packs(original, ROOT / addon, manifest, base)
    save_json(ROOT / 'Validacao.json', report)
    for mode, info in report['modelos'].items():
        print(f'{mode}: {info["cubos"]} cubos, extensão {info["extensao_em_blocos"]} blocos')
    for base, info in report['bases'].items():
        print(f'{base}: BP + RP conferidos, poses {info["poses_amostradas"]}')
    print(f'Sawarabi: {report["sawarabi"]}')


if __name__ == '__main__':
    main()
