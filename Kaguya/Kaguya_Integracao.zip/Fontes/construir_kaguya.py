#!/usr/bin/env python3
"""Gera os recursos Kaguya, o overlay e as duas compilações da addon."""

import argparse
from contextlib import ExitStack
import copy
import io
import json
from pathlib import Path
import re
from zipfile import ZipFile

from PIL import Image, ImageDraw

from aplicar_integracao import PACK_UUIDS, ROOT, apply, open_packs, sha256
from modelagem import (
    FOREST_ANIMATION, FOREST_ID, FOREST_TEXTURE, MODOS, atlas, create_forest, create_wearable,
)


VERSION = [18, 11, 73]
WEARABLE_RENDER = 'controller.render.swbr.kaguya.ossos'
FOREST_RENDER = 'controller.render.swbr.kaguya.solo'
WEARABLE_CONDITION = 'variable.swbr_kaguya_equipped'
WEARABLE_CONTEXT = f"{WEARABLE_CONDITION} = context.item_slot == 'head' && !context.is_first_person;"
AGE_QUERY = "(context.owning_entity -> q.property('nzs:body_age'))"
WEARABLE_SCALE = f'0.9375 * ({AGE_QUERY} == 1 ? 0.87 : ({AGE_QUERY} == 2 ? 0.70 : 1.0))'
FOREST_ENTITY_PATH = 'entity/refined_sawarabi_no_mai_visual_v18389.json'
FOREST_GEO_PATH = 'models/entity/v18389/sawarabi_no_mai.geo.json'
FOREST_ANIMATION_PATH = 'animations/v18389/sawarabi_no_mai.json'
PARTICLE_ID = 'swbr:kaguya_fragmento_osseo'
PARTICLE_TEXTURE = 'textures/entity/swbr/kaguya/fragmento'
VISUAL_RUNTIME = 'scripts/rp_v159_visual_rework.js'
PROFILES = 'scripts/jutsu/nzs_visual_profiles_v18389.js'


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def save_image(path, image):
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, optimize=True)


def attachable(original, mode):
    desc = original['minecraft:attachable']['description']
    body = {
        'identifier': desc['identifier'],
        'materials': {'default': 'entity_alphatest'},
        'textures': {'default': mode.textura},
        'geometry': {'default': mode.geometria},
        'scripts': {'pre_animation': [WEARABLE_CONTEXT], 'scale': WEARABLE_SCALE},
        'render_controllers': [WEARABLE_RENDER],
    }
    if 'item' in desc:
        body['item'] = desc['item']
    return {'format_version': '1.10.0', 'minecraft:attachable': {'description': body}}


def dust_particle():
    return {'format_version': '1.10.0', 'particle_effect': {
        'description': {'identifier': PARTICLE_ID, 'basic_render_parameters': {
            'material': 'particles_alpha', 'texture': PARTICLE_TEXTURE,
        }},
        'components': {
            'minecraft:emitter_rate_instant': {'num_particles': 2},
            'minecraft:emitter_lifetime_once': {'active_time': .03},
            'minecraft:emitter_shape_sphere': {'radius': .045, 'direction': 'outwards'},
            'minecraft:particle_lifetime_expression': {'max_lifetime': 'math.random(0.19, 0.32)'},
            'minecraft:particle_initial_speed': 'math.random(0.22, 0.54)',
            'minecraft:particle_motion_dynamic': {'linear_acceleration': [0, -2.3, 0], 'linear_drag_coefficient': .85},
            'minecraft:particle_initial_spin': {'rotation': 'math.random(0, 360)', 'rotation_rate': 'math.random(-90, 75)'},
            'minecraft:particle_appearance_billboard': {
                'size': ['(0.035 + 0.023 * v.particle_random_1) * (1 - 0.55 * v.particle_age / v.particle_lifetime)',
                         '(0.046 + 0.028 * v.particle_random_1) * (1 - 0.55 * v.particle_age / v.particle_lifetime)'],
                'facing_camera_mode': 'lookat_xyz',
                'uv': {'texture_width': 32, 'texture_height': 16,
                       'uv': ['math.floor(v.particle_random_2 * 2) * 16', 0], 'uv_size': [16, 16]},
            },
            'minecraft:particle_appearance_lighting': {},
        },
    }}


def fragment_texture():
    texture = Image.new('RGBA', (32, 16))
    draw = ImageDraw.Draw(texture)
    draw.polygon([(6, 13), (2, 8), (7, 4), (13, 2), (12, 8), (9, 12)], fill='#ddd3b8')
    draw.polygon([(2, 8), (7, 4), (13, 2), (8, 8)], fill='#f5efdb')
    draw.polygon([(6, 13), (8, 8), (12, 8), (9, 12)], fill='#bdb6a7')
    draw.polygon([(19, 11), (23, 6), (28, 3), (29, 5), (28, 11), (22, 13)], fill='#e7e1cc')
    draw.polygon([(23, 6), (28, 3), (27, 8), (22, 11)], fill='#fcf4dc')
    draw.polygon([(19, 11), (22, 11), (27, 8), (28, 11), (22, 13)], fill='#c3bbab')
    return texture


def patch_activation(data):
    text = data.decode('utf-8')
    for key, radius, count, burst_count, spread, vol, pitch in (
        ('kaguya1', '1.15', 13, 10, '.85', '.5', '1.5'),
        ('kaguya2', '1.55', 20, 16, '1.10', '.7', '1.15'),
    ):
        template = rf'^  else if\(key==="{key}"\)\{{[^\n]+minecraft:snowflake_particle[^\n]+\}}$'
        replacement = (
            f'  else if(key==="{key}"){{\n'
            f'    ring(p,"{PARTICLE_ID}",{radius},{count},.17);\n'
            f'    burst(p,["{PARTICLE_ID}"],{burst_count},{spread});\n'
            f'    sound(p,"random.anvil_land",{vol},{pitch});\n'
            '  }'
        )
        text, n = re.subn(template, replacement, text, flags=re.MULTILINE)
        if n != 1:
            raise ValueError(f'Ativação visual {key} não encontrada uma única vez na base.')
    passive = (r'^  \} else if\(key==="kaguya1"\)\{\n[^}]*\} else if\(key==="kaguya2"\)\{\n[^}]*'
               r'(?=^  \} else if\(key==="inuzuka"\))')
    text, n = re.subn(passive, '', text, flags=re.MULTILINE)
    if n != 1:
        raise ValueError('Seção visual passiva da Forma I/II não encontrada na base.')
    return text.encode('utf-8')


def patch_sawarabi_fx(data):
    text = data.decode('utf-8')
    template = r'("nz:jutsu_sawarabi_no_mai": \{[^}]*?"mesh": "refined_sawarabi_no_mai")'
    phases = f',\n    "phases": {{ "trail": "{PARTICLE_ID}", "impact": "{PARTICLE_ID}" }}'
    text, n = re.subn(template, lambda match: match.group(1) + phases, text)
    if n != 1:
        raise ValueError('Perfil visual do Sawarabi não encontrado uma única vez na base.')
    return text.encode('utf-8')


def update_manifest(original, variant):
    manifest = copy.deepcopy(original)
    header = manifest['header']
    header['version'] = VERSION
    header['name'] = 'Shinobi World BR 18.11.73 · Kaguya'
    header['description'] = f'Shinobi World BR 18.11.73 | Cinco modos Kaguya e efeito Sawarabi | Base {variant}'
    for module in manifest['modules']:
        module['version'] = VERSION
    for dependency in manifest.get('dependencies', []):
        if dependency.get('uuid') in PACK_UUIDS.values():
            dependency['version'] = VERSION
    return manifest


def file_record(path, root):
    return {'arquivo': path.relative_to(root).as_posix(), 'sha256': sha256(path.read_bytes())}


def build(base64, base72, root=ROOT):
    bases = {'18.11.64': base64, '18.11.72': base72}
    source = {key: open_packs(addon) for key, addon in bases.items()}
    overlay = root / 'Integracao'
    rp, bp = overlay / 'RP', overlay / 'BP'
    manifest = {'cla': 'Kaguya', 'versao': VERSION, 'slot': 'slot.armor.head', 'modos': {}, 'bases': {}, 'arquivos': {}}
    with ExitStack() as stack:
        original = {
            base: {p: stack.enter_context(ZipFile(io.BytesIO(pack[2]))) for p, pack in pack_set.items()}
            for base, pack_set in source.items()
        }

        def read_common(pack, path):
            original64 = original['18.11.64'][pack].read(path)
            if original64 != original['18.11.72'][pack].read(path):
                raise ValueError(f'{pack}/{path} diverge entre as bases. Revise a integração deste arquivo.')
            return original64

        for i, mode in enumerate(MODOS):
            model = create_wearable(i)
            save_json(rp / mode.arquivo_geo, model.geometry(mode.geometria, (4, 4, 1.25)))
            save_image(rp / (mode.textura + '.png'), atlas(i))
            possible = [f'attachables/nz_{mode.item}{ending}.json' for ending in ('', '.player')]
            linked = []
            for path in possible:
                exists = [path in original[base]['RP'].namelist() for base in bases]
                if len(set(exists)) != 1:
                    raise ValueError(f'Vínculo divergente entre as bases: {path}.')
                if exists[0]:
                    save_json(rp / path, attachable(json.loads(read_common('RP', path)), mode))
                    linked.append(path)
            if not linked:
                raise ValueError(f'Attachable original ausente para {mode.item}.')
            manifest['modos'][mode.chave] = {
                'id': f'nz:{mode.item}', 'nome': mode.nome, 'requisito': mode.requisito,
                'geometria': mode.geometria, 'arquivo_geo': mode.arquivo_geo, 'textura': mode.textura + '.png',
                'projeto': mode.projeto + '.bbmodel', 'attachables': linked,
                'bones': len(model.bones), 'cubos': sum(len(bone.get('cubes', [])) for bone in model.bones),
                'projecoes': len(model.parts),
            }

        forest, animation = create_forest()
        save_json(rp / FOREST_GEO_PATH, forest.geometry(FOREST_ID, (12, 13, 1.85)))
        save_json(rp / FOREST_ANIMATION_PATH, animation)
        save_image(rp / (FOREST_TEXTURE + '.png'), atlas(7))
        entity = json.loads(read_common('RP', FOREST_ENTITY_PATH))
        desc = entity['minecraft:client_entity']['description']
        desc.update(materials={'default': 'entity_alphatest'}, textures={'default': FOREST_TEXTURE},
                    animations={'life': FOREST_ANIMATION}, scripts={'animate': ['life']},
                    render_controllers=[FOREST_RENDER])
        save_json(rp / FOREST_ENTITY_PATH, entity)
        controller = {'geometry': 'Geometry.default', 'materials': [{'*': 'Material.default'}],
                      'textures': ['Texture.default']}
        wear_controller = {**controller, 'part_visibility': [{'*': WEARABLE_CONDITION}]}
        save_json(rp / 'render_controllers/swbr_kaguya.json', {
            'format_version': '1.8.0',
            'render_controllers': {WEARABLE_RENDER: wear_controller, FOREST_RENDER: controller},
        })
        save_json(rp / 'particles/swbr_kaguya_fragmento_osseo.json', dust_particle())
        save_image(rp / (PARTICLE_TEXTURE + '.png'), fragment_texture())
        bp.mkdir(parents=True, exist_ok=True)
        for path, transform in ((VISUAL_RUNTIME, patch_activation), (PROFILES, patch_sawarabi_fx)):
            dest = bp / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(transform(read_common('BP', path)))

    manifest['jutsu'] = {'id': 'nz:jutsu_sawarabi_no_mai', 'estacas': len(animation['animations'][FOREST_ANIMATION]['bones']),
                        'geometria': FOREST_GEO_PATH, 'animacao': FOREST_ANIMATION_PATH}
    for base, pack_set in source.items():
        spec = {'nome': bases[base].name, 'sha256': sha256(bases[base].read_bytes()), 'packs': {}}
        for pack, (entry, info, _) in pack_set.items():
            if '.'.join(str(x) for x in info['header']['version']) != base:
                raise ValueError(f'Arquivo fornecido para {base} tem outra versão.')
            destination = overlay / 'Versoes' / base / pack / 'manifest.json'
            save_json(destination, update_manifest(info, base))
            spec['packs'][pack] = {'entrada': entry, 'saida': f'SWBR_{pack}_v18.11.73_KAGUYA.mcpack',
                                   'manifesto': file_record(destination, root)}
        manifest['bases'][base] = spec
    for pack in PACK_UUIDS:
        manifest['arquivos'][pack] = {
            f.relative_to(overlay / pack).as_posix(): file_record(f, root)
            for f in sorted((overlay / pack).rglob('*')) if f.is_file()
        }
    save_json(root / 'Integracao_Manifesto.json', manifest)
    for key, name in (('18.11.64', 'Kaguya_Base_18.11.64.mcaddon'), ('18.11.72', 'Kaguya.mcaddon')):
        print(apply(bases[key], root / name, root))
    for mode in manifest['modos'].values():
        print(f'{mode["nome"]} · {mode["cubos"]} cubos, {mode["bones"]} bones')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base64', type=Path)
    parser.add_argument('base72', type=Path)
    args = parser.parse_args()
    build(args.base64, args.base72)
