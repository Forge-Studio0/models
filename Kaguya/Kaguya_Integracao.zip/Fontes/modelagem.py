"""Geometrias Bedrock do Shikotsumyaku e atlas originais de marfim."""

from dataclasses import dataclass
from math import asin, atan2, degrees, dist, sin

from PIL import Image


TEXTURE_SIZE = 256
FACES = ('north', 'south', 'east', 'west', 'up', 'down')
RIG = (
    ('root', None, (0, 0, 0)),
    ('waist', 'root', (0, 12, 0)),
    ('body', 'waist', (0, 24, 0)),
    ('head', 'body', (0, 24, 0)),
    ('rightArm', 'body', (-5, 22, 0)),
    ('leftArm', 'body', (5, 22, 0)),
    ('rightLeg', 'root', (-1.9, 12, 0)),
    ('leftLeg', 'root', (1.9, 12, 0)),
)


@dataclass(frozen=True)
class Modo:
    chave: str
    item: str
    projeto: str
    nome: str
    requisito: str

    @property
    def geometria(self):
        return f'geometry.swbr.kaguya.{self.chave}'

    @property
    def arquivo_geo(self):
        return f'models/entity/swbr/kaguya/{self.chave}.geo.json'

    @property
    def textura(self):
        return f'textures/entity/swbr/kaguya/{self.chave}'


MODOS = (
    Modo('despertar', 'kaguya_shikotsumyaku', 'Kaguya_01_Despertar',
         'Shikotsumyaku — Despertar', 'Nível 8'),
    Modo('armadura', 'kaguya_hone_armor', 'Kaguya_02_Armadura_Ossea',
         'Shikotsumyaku — Armadura Óssea', 'Nível 18'),
    Modo('forma_i', 'shikotsumyaku_forma1', 'Kaguya_03_Forma_I',
         'Shikotsumyaku — Forma I', '30.000 TP'),
    Modo('forma_ii', 'shikotsumyaku_forma2', 'Kaguya_04_Forma_II',
         'Shikotsumyaku — Forma II', '50.000 TP após a Forma I'),
    Modo('sawarabi', 'kaguya_bracken_dance', 'Kaguya_05_Sawarabi_no_Mai',
         'Sawarabi no Mai', 'Nível 30'),
)


def atlas(variant):
    """Azulejos por face e região do osso, com bordas preenchidas para mipmaps."""
    surface = (
        (209, 201, 180), (219, 212, 196), (239, 234, 216), (234, 228, 212),
        (229, 225, 212), (246, 242, 226), (240, 237, 225), (214, 208, 194),
    )
    face_light = (4, -8, -13, 0, 8, -13, -3, 1)
    texture = Image.new('RGBA', (TEXTURE_SIZE, TEXTURE_SIZE))
    data = texture.load()
    for y in range(TEXTURE_SIZE):
        row, py = divmod(y, 32)
        v = min(27, max(4, py))
        for x in range(TEXTURE_SIZE):
            col, px = divmod(x, 32)
            u = min(27, max(4, px))
            phase = col * 1.82 + row * .79 + variant * .63
            # Longitudinal growth marks and a bright ridge off the centerline.
            ripple = sin(.71 * u + .042 * v + phase) + .55 * sin(1.6 * u - .07 * v)
            light = face_light[col] + 6.4 * (1 - ((u - 13) / 15) ** 2) + 1.8 * ripple
            light += (variant % 3) - 1
            if row in (0, 1, 7):
                crease = 21 + int(1.9 * sin(.22 * u + phase))
                light -= (18 if row != 7 else 24) * max(0, 1 - abs(v - crease) / 2.4)
                if 12 < u < 23 and abs(v - crease - (u - 14) * .30) < .7:
                    light -= 10
                if v == crease - 2:
                    light += 5
            elif row < 5 and abs(u - (8 + (row + col) % 5) - .09 * v) < .58 and 9 < v < 23:
                light -= 7
            rgb = [max(0, min(255, round(channel + light))) for channel in surface[row]]
            data[x, y] = (*rgb, 255)
    return texture


def vector(values):
    return [round(number, 5) for number in values]


def uv(row, variant):
    columns = (0, 1, 2, 3, 4, 5) if not variant else (7, 6, 3, 2, 4, 5)
    return {
        face: {'uv': [col * 32 + 4, row * 32 + 4], 'uv_size': [24, 24]}
        for face, col in zip(FACES, columns)
    }


def segment(start, end, width, depth, row, variant, overlap=0):
    """Gira o eixo longo do cubo sobre cada trecho do eixo curvo do osso."""
    length = dist(start, end)
    dx, dy, dz = (b - a for a, b in zip(start, end))
    # Bedrock espelha X na importação. A rotação equivale a Rz(Rx(+Y)) no editor.
    rot = [-degrees(asin(max(-1, min(1, dz / length)))), 0, degrees(atan2(dx, dy))]
    return {
        'origin': vector((start[0] - width / 2, start[1] - overlap, start[2] - depth / 2)),
        'size': vector((width, length + 2 * overlap, depth)),
        'pivot': vector(start),
        'rotation': vector(rot),
        'uv': uv(row, variant),
    }


def bezier(root, end, bend, fraction):
    return tuple(a + (b - a) * fraction + offset * 4 * fraction * (1 - fraction)
                 for a, b, offset in zip(root, end, bend))


class Modelo:
    def __init__(self, rig=RIG):
        self.bones = []
        self.parts = {}
        for name, parent, pivot in rig:
            bone = {'name': name, 'pivot': list(pivot)}
            if parent:
                bone['parent'] = parent
            self.bones.append(bone)

    def group(self, name, parent, root, cubes):
        self.bones.append({'name': name, 'parent': parent, 'pivot': vector(root), 'cubes': cubes})

    def spike(self, name, parent, root, end, width, bend=(0, 0, 0), *, aspect=.79,
              collar=True):
        long = dist(root, end) > 6
        fractions = (0, .20, .43, .64, .80, .92, 1) if long else (0, .27, .54, .76, .92, 1)
        profile = (1, .84, .66, .48, .28, .12) if long else (1, .76, .55, .33, .13)
        color = sum(name.encode())
        points = [bezier(root, end, bend, fraction) for fraction in fractions]
        cubes = []
        for i, (start, stop, ratio) in enumerate(zip(points, points[1:], profile)):
            row = (color % 2) if i == 0 else (5 + color % 2 if i == len(profile) - 1 else 2 + color % 3)
            radius = width * ratio
            join = min(dist(start, stop) * .26, radius * .30) if i < len(profile) - 1 else radius * .3
            cubes.append(segment(start, stop, radius, radius * aspect, row, color % 2, join))
        if collar:
            a = tuple(r + (s - r) * .12 for r, s in zip(root, points[1]))
            b = tuple(r + (s - r) * .70 for r, s in zip(root, points[1]))
            cubes.insert(0, segment(a, b, width * 1.19, width * aspect * 1.15, 7, color % 2, .12))
        self.group(name, parent, root, cubes)
        self.parts[name] = {'parent': parent, 'root': vector(root), 'tip': vector(end), 'path': points,
                            'segments': len(cubes)}

    def vertebrae(self, count, *, top, spacing, width, sweep=0):
        for i in range(count):
            x = .105 * sin(i * 1.7)
            y = top - i * spacing
            z = 1.60 + .22 * sin(i * .6)
            w = width * (1 - .12 * (i / count))
            name = f'vertebra_{i + 1:02}'
            core = segment((x, y - .42, z), (x, y + .44, z + .16), w, 1.12, 7, i % 2, .08)
            outer = segment((x, y, z + .12), (x, y + .22, z + 1.17 + sweep),
                            w * .69, .66, 2 + i % 3, i % 2, .14)
            crest = segment((x, y + .13, z + .81), (x, y + .54, z + 1.51 + sweep),
                            w * .28, .34, 5 + i % 2, i % 2, .14)
            lobes = [segment((x + side * .27, y - .04, z + .27),
                             (x + side * w * .69, y + .14 - .12 * side, z + .59),
                             .40, .52, 1 + (i % 2), i % 2, .085)
                     for side in (-1, 1)]
            self.group(name, 'body', (x, y, z), [core, outer, crest, *lobes])

    def geometry(self, ident, bounds):
        width, height, center_y = bounds
        return {'format_version': '1.16.0', 'minecraft:geometry': [{
            'description': {'identifier': ident, 'texture_width': TEXTURE_SIZE,
                            'texture_height': TEXTURE_SIZE, 'visible_bounds_width': width,
                            'visible_bounds_height': height, 'visible_bounds_offset': [0, center_y, 0]},
            'bones': self.bones,
        }]}


# Each pose has its own shoulder/elbow silhouette within the vanilla arm pivots.
# Coordinates use the magnitude of X. Positive Z is behind the player.
ARMS = (
    ((8.7, 26.45, 1.75, .98), (9.0, 26.2, 1.25, .94),
     (8.15, 16.65, 4.55, .88), (8.0, 17.2, 4.35, .91)),
    ((9.65, 27.1, 2.95, 1.35), (9.45, 27.5, 2.55, 1.29),
     (8.75, 16.1, 5.95, 1.11), (9.15, 16.9, 5.70, 1.15)),
    ((11.30, 27.95, 2.82, 1.62), (10.65, 29.0, 1.65, 1.49),
     (10.25, 16.3, 6.40, 1.30), (9.0, 17.65, 6.65, 1.26)),
    ((11.7, 29.0, 3.85, 1.82), (11.35, 29.65, 2.75, 1.76),
     (10.7, 15.9, 7.16, 1.58), (10.25, 17.45, 7.41, 1.52)),
    ((12.60, 29.45, 4.60, 1.89), (12.1, 29.95, 3.30, 1.87),
     (10.65, 15.2, 8.39, 1.52), (10.3, 16.1, 8.05, 1.59)),
)


def arms(model, stage):
    shoulders = ARMS[stage][:2]
    elbows = ARMS[stage][2:]
    for i, (s, letter, arm) in enumerate(((-1, 'd', 'rightArm'), (1, 'e', 'leftArm'))):
        x, y, z, width = shoulders[i]
        model.spike(f'ombro_{letter}', arm, (s * 6.25, 23.32, .64), (s * x, y, z), width,
                    (s * -.24, .37, .15), aspect=.84)
        x, y, z, width = elbows[i]
        model.spike(f'cotovelo_{letter}', arm, (s * 6.34, 18.03 + i * .17, 1.42), (s * x, y, z), width,
                    (s * .21, -.37 - i * .08, .36), aspect=.83)
        if stage >= 1:
            model.spike(f'antebraco_{letter}', arm, (s * 6.44, 14.38 + i * .14, 1.03),
                        (s * (8.45 + .53 * stage), 12.74 + .17 * i, 3.15 + .74 * stage),
                        .77 + .13 * stage, (s * .25, -.27, .32), aspect=.70)
        if stage >= 2:
            model.spike(f'ombro_lateral_{letter}', arm, (s * 6.78, 21.97 - .28 * i, .21),
                        (s * (10.42 + stage * .40), 23.68 - i * .43, 1.95 + i * .5), .89 + .11 * stage,
                        (s * .25, .30, -.08))
        if stage == 3:
            model.spike(f'pulso_{letter}', arm, (s * 6.31, 12.58, -.54),
                        (s * (8.47 - i * .18), 11.9 - i * .33, -1.56), .72, (0, -.18, -.24))


def ribs(model, stage, lengths):
    for s, letter, rows in zip((-1, 1), ('d', 'e'), lengths):
        for i, (y, x, z, rise) in enumerate(rows):
            front = -1 if z < 0 else 1
            model.spike(f'costela_{letter}_{i + 1:02}', 'body', (s * (2.66 - .12 * (i % 3)), y, front * 1.60),
                        (s * x, y + rise, z), .70 + stage * .11 + (.10 if i == 0 else 0),
                        (s * -.23, -.42 + .07 * (i % 3), front * .43), aspect=.71, collar=i % 3 != 2)


def dorsal_spikes(model, spikes):
    for i, (x, y, end, width, bend) in enumerate(spikes):
        model.spike(f'espinho_dorsal_{i + 1:02}', 'body', (x, y, 1.62), end, width, bend,
                    aspect=.86)


def legs(model, advanced=False):
    for i, (s, side, leg) in enumerate(((-1, 'd', 'rightLeg'), (1, 'e', 'leftLeg'))):
        model.spike(f'joelho_{side}', leg, (s * 2.26, 6.72 - .20 * i, -1.50),
                    (s * (3.82 if advanced else 3.37), 7.58 - .35 * i, -5.00 if advanced else -4.16),
                    1.15 if advanced else .97, (s * .15, -.18, -.13), aspect=.76)
        if advanced:
            model.spike(f'canela_{side}', leg, (s * 2.86, 3.74 + .28 * i, -1.47),
                        (s * (4.58 + .21 * i), 2.9 + i * .50, -3.55),
                        .83, (0, -.21, -.20), aspect=.72)
            model.spike(f'panturrilha_{side}', leg, (s * 2.18, 4.51 + .38 * i, 1.40),
                        (s * (3.57 + i * .26), 5.87 - .12 * i, 4.85),
                        .90, (s * .19, -.12, .32))


def create_wearable(index):
    model = Modelo()
    arms(model, index)
    if index == 0:
        model.spike('osso_curto_ombro_d', 'rightArm', (-6.9, 22.95, -.37), (-8.25, 24.44, -1.32),
                    .64, (-.1, .12, -.15), collar=False)
        model.spike('osso_curto_ombro_e', 'leftArm', (6.7, 23.05, 1.3), (7.8, 24.5, 2.4),
                    .69, (.12, .15, .08), collar=False)
    elif index == 1:
        ribs(model, 1, (
            [(22.05, 4.48, -3.35, .40), (19.9, 4.25, -3.62, .29), (17.7, 4.06, -3.41, -.14), (15.78, 3.68, 4.15, .20)],
            [(21.8, 4.28, -3.71, .55), (19.55, 4.44, -3.48, .27), (17.55, 4.22, -3.58, .02), (15.5, 3.46, 4.48, .13)],
        ))
        model.vertebrae(5, top=21.65, spacing=1.60, width=1.11)
        dorsal_spikes(model, [
            (-.38, 22.20, (-.75, 25.6, 5.85), 1.07, (.03, -1.45, 1.20)),
            (.44, 19.40, (1.03, 21.86, 5.4), .91, (-.07, -.20, .22)),
            (-.63, 16.08, (-1.30, 16.18, 5.05), .93, (.03, -.39, .17)),
        ])
    elif index == 2:
        ribs(model, 2, (
            [(22.05, 4.57, -4.10, .64), (19.7, 4.38, -3.64, .11), (16.85, 4.58, -3.96, -.01)],
            [(22.2, 4.48, -3.75, .40), (20.0, 4.45, -4.14, .40), (18.5, 3.97, -3.92, .31), (15.52, 3.49, 4.80, .32)],
        ))
        model.vertebrae(7, top=22.55, spacing=1.38, width=1.29, sweep=.12)
        dorsal_spikes(model, [
            (-1.05, 22.15, (-3.30, 26.50, 6.10), 1.12, (.23, -.44, .80)),
            (1.05, 20.96, (3.30, 23.8, 5.22), 1.05, (-.22, .19, .46)),
            (-.88, 18.30, (-2.77, 19.97, 5.25), .96, (.16, -.19, .43)),
            (.78, 16.9, (2.56, 17.91, 4.59), .90, (-.11, -.24, .37)),
        ])
        legs(model)
    elif index == 3:
        ribs(model, 3, (
            [(22.12, 4.62, -4.63, .79), (20.06, 4.70, -4.29, .15), (17.75, 4.36, -4.61, .25), (15.2, 4.54, -4.30, -.02), (15.72, 4.78, 4.38, .56)],
            [(21.8, 4.62, -4.47, .62), (19.67, 4.74, -4.73, .26), (17.31, 4.63, -4.21, .19), (15.15, 4.49, -4.38, .29), (15.98, 3.56, 5.61, -.16)],
        ))
        model.vertebrae(8, top=22.68, spacing=1.20, width=1.40, sweep=.30)
        dorsal_spikes(model, [
            (-.94, 22.48, (-3.28, 30.02, 8.05), 1.54, (.27, -2.97, 1.46)),
            (1.34, 22.11, (3.84, 28.12, 7.40), 1.65, (-.31, -1.94, 1.31)),
            (-1.95, 20.0, (-4.15, 24.54, 7.67), 1.43, (.18, .21, .61)),
            (1.64, 18.85, (4.66, 20.92, 7.02), 1.34, (-.31, -.35, .61)),
            (-1.40, 16.76, (-3.86, 17.48, 6.66), 1.30, (.21, -.42, .47)),
            (1.11, 15.28, (2.66, 16.63, 5.66), 1.10, (-.08, -.25, .41)),
        ])
        legs(model, advanced=True)
    else:
        model.vertebrae(9, top=23.08, spacing=1.17, width=1.66, sweep=.41)
        ribs(model, 3, (
            [(21.44, 4.29, -3.56, .49), (17.6, 4.62, -4.30, .03), (15.74, 4.13, 3.97, .25)],
            [(21.18, 4.55, -3.69, .42), (17.87, 4.53, -4.33, .13), (15.45, 3.63, 4.48, -.05)],
        ))
        dorsal_spikes(model, [
            (-1.20, 22.44, (-3.18, 31.15, 8.70), 1.72, (.40, -3.28, 1.60)),
            (1.08, 22.35, (3.04, 31.66, 8.75), 1.75, (-.31, -3.31, 1.59)),
            (-2.03, 20.86, (-4.9, 25.80, 8.38), 1.62, (.31, .19, .69)),
            (1.85, 20.00, (4.80, 24.34, 9.17), 1.71, (-.39, .16, .67)),
            (-1.76, 17.92, (-3.54, 19.90, 9.26), 1.50, (.28, -.45, .81)),
            (1.47, 17.13, (3.83, 19.30, 8.11), 1.46, (-.37, -.39, .71)),
            (-.86, 15.04, (-2.60, 14.91, 7.19), 1.27, (.27, -.45, .61)),
            (1.02, 14.15, (2.86, 14.58, 6.40), 1.24, (-.18, -.45, .55)),
        ])
    return model


FOREST_ID = 'geometry.nzs_v18389_sawarabi_no_mai'
FOREST_ANIMATION = 'animation.nzs_v18389_sawarabi_no_mai'
FOREST_TEXTURE = 'textures/entity/swbr/kaguya/sawarabi_solo'

# Offsets in blocks. The existing cast covers a radius of four blocks.
STAKES = (
    (-.84, 1.17, 36, 6.8), (.87, -1.01, 31, 5.7), (1.55, .66, 65, 9.5), (-1.63, -.36, 72, 9.7),
    (-.55, -1.72, 46, 7.7), (1.29, -1.72, 77, 10.6), (.32, 2.11, 56, 7.5), (-1.9, 1.82, 60, 9.4),
    (2.29, 1.36, 82, 10.9), (2.48, -.38, 56, 8.3), (-2.44, -.98, 83, 11.2), (-.71, -2.66, 68, 9.2),
    (2.63, -1.78, 64, 8.7), (-2.77, .81, 35, 6.5), (-1.83, -2.63, 59, 8.2), (1.30, 2.92, 70, 10.5),
    (-.55, 3.13, 82, 10.7), (-2.59, 2.06, 45, 7.4), (2.89, 1.88, 54, 8.2), (.70, -3.19, 58, 8.4),
    (3.39, -.27, 32, 5.8), (-3.40, -.26, 34, 6.1),
)


def create_forest():
    model = Modelo((('root', None, (0, 0, 0)),))
    channels = {}
    for i, (x, z, height, width) in enumerate(STAKES):
        root = (16 * x, -2.4, 16 * z)
        end = (16 * x + (i % 5 - 2) * 2.40 + x * 2.1,
               height, 16 * z + (i % 7 - 3) * 1.63 + z * 1.6)
        name = f'estaca_{i + 1:02}'
        bend = (2.4 * sin(i * 2.3), .23, 2.7 * sin(i * 1.7))
        model.spike(name, 'root', root, end, width, bend, aspect=.69 + .055 * (i % 4))
        cubes = model.bones[-1]['cubes']
        cubes.insert(0, segment((root[0], -22, root[2]), (root[0], .44, root[2]),
                                width * .91, width * .69, 0, i % 2, .18))
        if i in (2, 5, 8, 10, 16):
            split = bezier(root, end, bend, .24)
            twig_end = (split[0] + 7.5 * sin(i), split[1] + height * .39, split[2] + 8.3 * sin(i * 2))
            model.spike(f'ramo_{i + 1:02}', name, split, twig_end, width * .44,
                        (.4, .4, -.35), aspect=.74, collar=False)
        delay = round(.027 * (i % 3) + .044 * dist((x, z), (0, 0)), 3)
        finish = round(delay + .35 + (i % 4) * .059, 3)
        channels[name] = {'position': {
            '0.0': [0, -height - 3, 0], f'{delay:.3f}': [0, -height - 3, 0],
            f'{delay + (finish - delay) * .56:.3f}': [0, round(-height * .28, 2), 0],
            f'{finish:.3f}': [0, 0, 0],
        }}
    animation = {'format_version': '1.8.0', 'animations': {FOREST_ANIMATION: {
        'animation_length': .75, 'loop': 'hold_on_last_frame', 'bones': channels,
    }}}
    return model, animation
