/* Abre os recursos no Blockbench e exporta os cinco projetos editáveis. */
const fs = require('node:fs');
const path = require('node:path');
const { isDeepStrictEqual } = require('node:util');
const { chromium } = require('playwright');

const root = path.resolve(__dirname, '..');
const rp = path.join(root, 'Integracao', 'RP');
const manifest = read(path.join(root, 'Integracao_Manifesto.json'));
const editorURL = process.env.KAGUYA_BLOCKBENCH_URL || 'http://127.0.0.1:8876/';

function read(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function write(file, value) {
  fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n');
}

function normalize(value) {
  if (typeof value === 'number') return Math.round(value * 1e5) / 1e5 || 0;
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value).sort().map(key => [key, normalize(value[key])]));
  }
  return value;
}

function checkGeometry(input, exportValue, label) {
  function bones(json) {
    const geometry = json['minecraft:geometry'][0];
    for (const bone of geometry.bones) {
      for (const cube of bone.cubes || []) {
        if (!cube.rotation || cube.rotation.every(x => x === 0)) {
          delete cube.rotation;
          delete cube.pivot;
        }
      }
    }
    return normalize(Object.fromEntries(geometry.bones.map(bone => [bone.name, bone])));
  }
  const before = JSON.parse(JSON.stringify(input));
  const output = JSON.parse(JSON.stringify(exportValue));
  if (before['minecraft:geometry'][0].description.identifier !== output['minecraft:geometry'][0].description.identifier) {
    throw Error('Identificador de geometria alterado pelo editor: ' + label);
  }
  const originalBones = bones(before);
  const exportedBones = bones(output);
  for (const bone of Object.keys(originalBones)) {
    if (!isDeepStrictEqual(originalBones[bone], exportedBones[bone])) {
      throw Error(`Geometria ou UV divergente em ${label}/${bone}`);
    }
  }
  if (Object.keys(originalBones).length !== Object.keys(exportedBones).length) {
    throw Error('Quantidade de bones divergente: ' + label);
  }
}

async function textureReady(page) {
  await page.waitForFunction(() => Texture.all.length === 1 && Texture.all[0].img.complete &&
    Texture.all[0].img.naturalWidth === 256 && Texture.all[0].img.naturalHeight === 256);
}

async function inspect(page, geometry, texPath, name, animation) {
  const texture = 'data:image/png;base64,' + fs.readFileSync(path.join(rp, texPath)).toString('base64');
  const startErrors = await page.evaluate(() => ErrorLog.length);
  await page.evaluate(({ geometry, texture, name, animation }) => {
    Codecs.bedrock.load(geometry, { path: `${name}.geo.json` });
    Project.name = name;
    const image = new Texture({ name: `${name}.png`, keep_size: true }).fromDataURL(texture).add(false);
    for (const cube of Cube.all) {
      for (const face of Object.values(cube.faces)) {
        if (face.texture !== null) face.texture = image.uuid;
      }
    }
    if (animation) Animator.loadFile({ path: `${name}.animation.json`, json: animation });
  }, { geometry, texture, name, animation });
  await textureReady(page);
  const model = await page.evaluate(() => ({
    editor: Blockbench.version, format: Format.id, cubes: Cube.all.length, bones: Group.all.length,
    textureError: Texture.all[0].error,
    project: Codecs.project.compile({ raw: true, bitmaps: true }),
    geometry: Codecs.bedrock.compile({ raw: true }),
    animations: Animation.all.map(anim => ({ name: anim.name, length: anim.length, channels: Object.keys(anim.animators).length })),
  }));
  const errors = await page.evaluate(index => ErrorLog.slice(index), startErrors);
  if (errors.length || model.textureError) throw Error(name + ': ' + JSON.stringify(errors));
  model.project.textures[0].source = texture;
  model.project.textures[0].internal = true;
  return { model, startErrors };
}

async function main() {
  const options = { headless: true, args: [
    '--no-sandbox', '--disable-dev-shm-usage', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
  ] };
  if (fs.existsSync('/usr/bin/chromium')) options.executablePath = '/usr/bin/chromium';
  const browser = await chromium.launch(options);
  try {
    const page = await browser.newPage();
    await page.route('https://**/*', route => route.abort());
    await page.goto(editorURL, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => typeof Blockbench !== 'undefined' && Blockbench.setup_successful);
    const projects = path.join(root, 'Modelos_Blockbench');
    fs.mkdirSync(projects, { recursive: true });
    const results = [];
    for (const spec of Object.values(manifest.modos)) {
      const geometry = read(path.join(rp, spec.arquivo_geo));
      const name = spec.projeto.replace(/\.bbmodel$/, '');
      const { model, startErrors } = await inspect(page, geometry, spec.textura, name);
      checkGeometry(geometry, model.geometry, name);
      if (model.cubes !== spec.cubos || model.bones !== spec.bones) throw Error('Contagem divergente: ' + name);
      const target = path.join(projects, spec.projeto);
      write(target, model.project);
      await page.evaluate(({ json, name }) => Codecs.project.load(json, { path: name }), { json: read(target), name: spec.projeto });
      await textureReady(page);
      const reopened = await page.evaluate(() => ({
        cubes: Cube.all.length, bones: Group.all.length, textureError: Texture.all[0].error,
        geometry: Codecs.bedrock.compile({ raw: true }),
      }));
      const errors = await page.evaluate(index => ErrorLog.slice(index), startErrors);
      if (reopened.cubes !== model.cubes || reopened.bones !== model.bones || reopened.textureError || errors.length) {
        throw Error('Projeto inválido na reabertura: ' + name + ' ' + JSON.stringify(errors));
      }
      checkGeometry(geometry, reopened.geometry, name + ' reaberto');
      results.push({ item: spec.id, projeto: spec.projeto, cubos: model.cubes, bones: model.bones,
        editor: model.editor, formato: model.format, textura: '256x256', reaberto: true, exportacao_identica: true });
      console.log(`${name}: ${model.cubes} cubos, ${model.bones} bones, projeto reaberto`);
    }
    const forest = read(path.join(rp, manifest.jutsu.geometria));
    const animation = read(path.join(rp, manifest.jutsu.animacao));
    const { model } = await inspect(page, forest, 'textures/entity/swbr/kaguya/sawarabi_solo.png', 'Sawarabi_Solo', animation);
    checkGeometry(forest, model.geometry, 'Sawarabi no solo');
    const imported = model.animations[0];
    if (model.animations.length !== 1 || imported.channels !== manifest.jutsu.estacas || imported.length !== 0.75) {
      throw Error('Os canais de surgimento das estacas não foram importados.');
    }
    write(path.join(root, 'Validacao_Blockbench.json'), { resultados: results, sawarabi: imported });
    console.log(`Sawarabi no solo: ${imported.channels} estacas com animação importada`);
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
