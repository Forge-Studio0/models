/* Executa as expressões de câmera, slot e escala com contextos simulados. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { Molang, Context } = require(process.env.KAGUYA_MOLANG_MODULE || 'molang');
const root = path.resolve(__dirname, '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'Integracao_Manifesto.json'), 'utf8'));
const rp = path.join(root, 'Integracao', 'RP');
const controllers = JSON.parse(fs.readFileSync(path.join(rp, 'render_controllers/swbr_kaguya.json'), 'utf8')).render_controllers;
let tested = 0;

for (const mode of Object.values(manifest.modos)) {
  for (const file of mode.attachables) {
    const data = JSON.parse(fs.readFileSync(path.join(rp, file), 'utf8'));
    const desc = data['minecraft:attachable'].description;
    const gate = controllers[desc.render_controllers[0]].part_visibility[0]['*'];
    for (const item_slot of ['head', 'main_hand', 'off_hand', 'torso', '']) {
      for (const is_first_person of [0, 1]) {
        for (const age of [0, 1, 2]) {
          const context = {
            item_slot, is_first_person,
            owning_entity: new Context({ query: { property: key => key === 'nzs:body_age' ? age : 0 } }),
          };
          const molang = new Molang({ context }, { useCache: false });
          molang.execute(desc.scripts.pre_animation[0]);
          assert.equal(Boolean(molang.execute(gate)), item_slot === 'head' && !is_first_person, file);
          assert.ok(Math.abs(Number(molang.execute(desc.scripts.scale)) - .9375 * [1, .87, .70][age]) < 1e-8, file);
          // Trocando o slot no mesmo contexto, o estado da peça deve ser recalculado.
          molang.updateExecutionEnv({ context: { ...context, item_slot: 'main_hand' },
            variable: { swbr_kaguya_equipped: molang.execute(gate) } });
          molang.execute(desc.scripts.pre_animation[0]);
          assert.equal(Boolean(molang.execute(gate)), false, file);
          tested++;
        }
      }
    }
  }
}

const report = { biblioteca: 'molang 2.0.1', contextos_simulados: tested,
  variacoes: ['posição do item', 'primeira ou terceira pessoa', 'três idades do corpo'] };
fs.writeFileSync(path.join(root, 'Validacao_Molang.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
