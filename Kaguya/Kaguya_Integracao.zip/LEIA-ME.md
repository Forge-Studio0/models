# Shinobi World BR · Kaguya 18.11.73

A revisão traz cinco modelos ósseos vestíveis para o clã Kaguya. Os itens continuam equipáveis no slot da cabeça. O Sawarabi equipado tem sua própria geometria. Ao usar o jutsu Sawarabi existente, 22 estacas de alturas variadas emergem do chão e seguem a duração e a limpeza do efeito original.

| Modo | Item | Desbloqueio | Silhueta |
| --- | --- | --- | --- |
| Despertar | `nz:kaguya_shikotsumyaku` | Nível 8 | Pequenas projeções nos ombros e cotovelos |
| Armadura Óssea | `nz:kaguya_hone_armor` | Nível 18 | Costelas abertas, espinhos na coluna e nos antebraços |
| Forma I | `nz:shikotsumyaku_forma1` | 30.000 TP | Ombros mais altos, costelas assimétricas, vértebras e joelhos |
| Forma II | `nz:shikotsumyaku_forma2` | 50.000 TP após a Forma I | Costelas alongadas e mais ossos nos braços, costas e pernas |
| Sawarabi no Mai | `nz:kaguya_bracken_dance` | Nível 30 | Coluna com pontas laterais, ossos longos nos ombros e antebraços |

## Instalação

- `Kaguya.mcaddon` parte da 18.11.72 e inclui os modelos aprovados de Iburi e Aburame.
- `Kaguya_Base_18.11.64.mcaddon` parte da 18.11.64 indicada no briefing.

Escolha a edição correspondente à sua base. As duas edições têm os mesmos UUIDs e a mesma versão de pack. Importe o `.mcaddon` no Bedrock e ative os packs do Shinobi World BR e o Desmaio Nativo incluído quando já estiver em uso no mundo.

## Edição e integração

- `Modelos_Blockbench/` tem os cinco projetos `.bbmodel` com PNG incorporado. Abra no Blockbench como modelos de entidade Bedrock.
- `Integracao/RP/` contém geometrias, PNGs, attachables, controladores de renderização, partículas e o efeito de solo do Sawarabi.
- `Integracao/BP/` contém os dois arquivos com ajustes de partículas. Os manifestos das duas bases ficam em `Integracao/Versoes/`.
- `Integracao_Manifesto.json` registra a lista de arquivos, caminhos e SHA-256. `Validacao.json` e `Validacao_Blockbench.json` registram os testes dos arquivos.

Para aplicar o overlay, extraia `Kaguya_Integracao.zip` e execute com Python 3 a partir da pasta extraída, usando a sua base correspondente ao SHA-256 do manifesto.

```sh
python Fontes/aplicar_integracao.py /caminho/para/base.mcaddon Kaguya_Integrado.mcaddon
```

## Referências visuais

As pontas curvas e as bases largas dos ossos orientaram o Despertar e as projeções dos braços. A distribuição aberta de ossos do Lariço orientou as costelas e os espinhos dorsais. [Naruto #121](https://naruto-official.com/en/anime/naruto1/list/01_345), [Naruto #124](https://naruto-official.com/en/anime/naruto1/list/01_348), [Dança do Salgueiro](https://naruto.fandom.com/wiki/Dance_of_the_Willow), [Dança do Lariço](https://naruto.fandom.com/wiki/Dance_of_the_Larch), [imagens do Salgueiro](https://naruto.wiki/Yanagi_no_Mai), [imagens do Lariço](https://naruto.wiki/Karamatsu_no_Mai).

As vértebras segmentadas, as diferentes inclinações e a subida das estacas no solo vieram do confronto com Gaara. [Naruto #126](https://naruto-official.com/en/anime/naruto1/list/01_350), [Naruto #127](https://naruto-official.com/en/anime/naruto1/list/01_351), [imagens do Sawarabi](https://naruto.wiki/Sawarabi_no_Mai).

## Teste no jogo

A validação foi feita nos arquivos dos packs e no Blockbench. A conferência no Minecraft Bedrock ainda precisa cobrir os cinco equipamentos em terceira pessoa, a câmera em primeira pessoa, caminhada, corrida, agachamento e salto com diferentes skins, a troca e a retirada dos itens e o surgimento e a remoção da floresta do Sawarabi.
