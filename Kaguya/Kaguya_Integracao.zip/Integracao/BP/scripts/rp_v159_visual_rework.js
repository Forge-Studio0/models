import { emitParticle, emitParticleCommand } from "./rp_v18347_visual_budget.js";
import { world, system, EquipmentSlot } from "@minecraft/server";

// v159.1 — camada visual persistente para RP. Os passivos continuam enquanto o modo estiver equipado.
const lastMode = new Map();
let pulse = 0;
function safe(fn, fallback){ try { return fn(); } catch { return fallback; } }
function eq(p, slot){ return safe(()=>p.getComponent("minecraft:equippable")?.getEquipment(slot)?.typeId, "") || ""; }
function pfx(dim,id,pos,commandFallback=true){ let ok=false; try{ emitParticle(dim, id,pos); ok=true; }catch{} if(!ok&&commandFallback){try{emitParticleCommand(dim, `particle ${id} ${pos.x.toFixed(2)} ${pos.y.toFixed(2)} ${pos.z.toFixed(2)}`);}catch{}} }
function sound(p,id,vol=0.7,pitch=1){ try{ p.runCommandAsync(`playsound ${id} @s ~ ~ ~ ${vol} ${pitch}`); }catch{} }
function pos(p,y=1){ return {x:p.location.x,y:p.location.y+y,z:p.location.z}; }
function randAround(p,r=1,y0=.15,y1=1.8){ const a=Math.random()*Math.PI*2,d=Math.random()*r; return {x:p.location.x+Math.cos(a)*d,y:p.location.y+y0+Math.random()*(y1-y0),z:p.location.z+Math.sin(a)*d}; }
function burst(p, ids, n=16, r=1.4){ n=Math.max(1,Math.min(8,Math.ceil(n*.25)));for(let i=0;i<n;i++) pfx(p.dimension,ids[i%ids.length],randAround(p,r,.1,2.1)); }
function ring(p,id,r=1.5,count=12,y=.15){ count=Math.max(3,Math.min(8,Math.ceil(count*.25)));for(let i=0;i<count;i++){const a=i*Math.PI*2/count;pfx(p.dimension,id,{x:p.location.x+Math.cos(a)*r,y:p.location.y+y,z:p.location.z+Math.sin(a)*r});} }
function ocular(id){
  const s=String(id||"").toLowerCase();
  // v18.3.43 — o Mangekyou Negro usa apenas seus olhos, sem aura de Amaterasu.
  if(s==="nz:modo_mangekyou_negro_admin") return "";
  if(s.includes("rinnegan")) return "rinnegan";
  if(s.includes("mangekyou")||s.includes("mg_eterno")) return "mangekyou";
  if(s.includes("sharingan")) return "sharingan";
  return "";
}
function visualKey(p){
  const h=eq(p,EquipmentSlot.Head), c=eq(p,EquipmentSlot.Chest);
  if(h==="nz:modo_nara_sombras") return "nara";
  if(h==="nz:modo_inuzuka_fera") return "inuzuka";
  if(h==="nz:modo_yuki_hyoton") return "yuki";
  if(h==="nz:modo_hozuki_hidrico") return "hozuki";
  if(h==="nz:shikotsumyaku_forma1") return "kaguya1";
  if(h==="nz:shikotsumyaku_forma2") return "kaguya2";
  if(h==="nz:konan_form") return "konan";
  if(h==="nz:deidara_form") return "deidara";
  // v18.1.0 — formas Ōtsutsuki usam aura de baixo custo para não saturar clientes/servidor.
  if(["nz:rinnegan_momoshiki","nz:rinnegan_urashiki","nz:rinnegan_kaguya"].includes(h)) return "rinnegan_otsutsuki";
  if(["nz:byakugan_otsutsuki","nz:bk_otsutsuki_ativado","nz:modo_deus_otsutsuki_admin"].includes(h)) return "otsutsuki_eye";
  const eye=ocular(h); if(eye) return eye;
  if(/^nz:susanoo_[a-z0-9_]+5$/.test(c)) return "susanoo";
  return "";
}
function activation(p,key){
  if(!key)return;
  if(key==="nara"){ ring(p,"nz:sombra_rp",1.35,16,.06); burst(p,["nz:sombra_rp","minecraft:basic_smoke_particle"],14,1.0); sound(p,"mob.endermen.portal",.38,.62); }
  else if(key==="kaguya1"){
    ring(p,"swbr:kaguya_fragmento_osseo",1.15,13,.17);
    burst(p,["swbr:kaguya_fragmento_osseo"],10,.85);
    sound(p,"random.anvil_land",.5,1.5);
  }
  else if(key==="kaguya2"){
    ring(p,"swbr:kaguya_fragmento_osseo",1.55,20,.17);
    burst(p,["swbr:kaguya_fragmento_osseo"],16,1.10);
    sound(p,"random.anvil_land",.7,1.15);
  }
  else if(key==="inuzuka"){ burst(p,["nz:vento","nz:terra"],24,1.5); ring(p,"nz:vento",1.45,16,.2); sound(p,"mob.wolf.growl",.7,.9); }
  else if(key==="yuki"){ ring(p,"nz:hyouton_lightblue",1.7,18,.18); burst(p,["minecraft:snowflake_particle","nz:hyouton_lightblue"],28,1.8); sound(p,"random.glass",.6,1.25); }
  else if(key==="hozuki"){ ring(p,"nz:agua",1.45,18,.2); burst(p,["minecraft:water_splash_particle","nz:agua"],28,1.65); sound(p,"random.splash",.8,1); }
  else if(key==="konan"){ burst(p,["nz:papel","minecraft:cloud_particle"],28,2.0); sound(p,"random.bow",.45,1.4); }
  else if(key==="deidara"){ burst(p,["minecraft:basic_smoke_particle","minecraft:cloud_particle"],22,1.8); sound(p,"random.fuse",.45,1.1); }
  else if(key==="susanoo"){ ring(p,"nz:chakra",2.2,24,.25); burst(p,["nz:chakra","minecraft:soul_particle"],30,2.3); sound(p,"mob.enderdragon.growl",.45,.75); }
  else if(key==="sharingan"){ burst(p,["nz:chakra","minecraft:basic_smoke_particle"],10,.65); sound(p,"random.orb",.35,.7); }
  // v18.3.48 — olhos Mangekyou/eternos não produzem aura automática de fogo.
  else if(key==="mangekyou"){ sound(p,"random.orb",.45,.55); }
  else if(key==="rinnegan"){ burst(p,["nz:chakra","minecraft:soul_particle"],16,.95); ring(p,"nz:chakra",1.25,12,1.0); sound(p,"mob.endermen.portal",.4,.8); }
  else if(key==="rinnegan_otsutsuki"||key==="otsutsuki_eye"){ burst(p,["nz:chakra","minecraft:soul_particle"],8,.75); sound(p,"mob.endermen.portal",.28,.9); }
}
function passive(p,key){
  const moving=safe(()=>{const v=p.getVelocity();return Math.hypot(v.x,v.z)>.045;},false);
  if(key==="nara"){
    if(pulse%2===0)pfx(p.dimension,"nz:sombra_rp",randAround(p,.62,.015,.11));
    if(moving&&pulse%4===0)pfx(p.dimension,"minecraft:basic_smoke_particle",randAround(p,.48,.02,.18));
  } else if(key==="inuzuka"){
    if(moving){for(let i=0;i<2;i++)pfx(p.dimension,i%2?"nz:vento":"nz:terra",randAround(p,.55,.02,.28));}
    else if(pulse%3===0)pfx(p.dimension,"nz:vento",randAround(p,.4,.05,.3));
  } else if(key==="yuki"){
    for(let i=0;i<1;i++)pfx(p.dimension,i?"minecraft:snowflake_particle":"nz:hyouton_lightblue",randAround(p,1.05,.55,2.15));
  } else if(key==="hozuki"){
    for(let i=0;i<1;i++)pfx(p.dimension,i?"minecraft:water_splash_particle":"nz:agua",randAround(p,.8,.25,1.85));
  } else if(key==="konan"){
    for(let i=0;i<1;i++)pfx(p.dimension,"nz:papel",randAround(p,1.25,.5,2.3));
    if(safe(()=>p.hasTag("nzs_mode_flight"),false)){ for(let i=0;i<3;i++)pfx(p.dimension,"nz:papel",{x:p.location.x+(Math.random()-.5)*1.2,y:p.location.y-.2+Math.random()*.6,z:p.location.z+(Math.random()-.5)*1.2}); }
  } else if(key==="deidara"){
    if(moving&&pulse%2===0)pfx(p.dimension,"minecraft:basic_smoke_particle",{x:p.location.x,y:p.location.y-.1,z:p.location.z});
  } else if(key==="susanoo"){
    for(let i=0;i<1;i++)pfx(p.dimension,"nz:chakra",randAround(p,2.0,.15,2.7));
    if(safe(()=>p.hasTag("nzs_mode_flight"),false)){pfx(p.dimension,"nz:chakra",{x:p.location.x,y:p.location.y-.2,z:p.location.z});pfx(p.dimension,"minecraft:soul_particle",{x:p.location.x+(Math.random()-.5),y:p.location.y,z:p.location.z+(Math.random()-.5)});}
  } else if(key==="sharingan"){
    if(pulse%4===0)pfx(p.dimension,"nz:chakra",{x:p.location.x,y:p.location.y+1.62,z:p.location.z});
  } else if(key==="rinnegan"){
    if(pulse%3===0){const a=pulse*.7;pfx(p.dimension,"nz:chakra",{x:p.location.x+Math.cos(a)*.48,y:p.location.y+1.45,z:p.location.z+Math.sin(a)*.48});}
  } else if(key==="rinnegan_otsutsuki"||key==="otsutsuki_eye"){
    // 1 emissão a cada ~4 s; modelo do modo continua renderizado normalmente.
    if(pulse%4===0){const a=pulse*.47;pfx(p.dimension,"nz:chakra",{x:p.location.x+Math.cos(a)*.38,y:p.location.y+1.45,z:p.location.z+Math.sin(a)*.38},false);}
  }
}
function nearestPlayer(p,r=20){
  const arr=safe(()=>[...p.dimension.getPlayers({location:p.location,maxDistance:r})],[])||[];
  return arr.filter(x=>x.id!==p.id).sort((a,b)=>Math.hypot(a.location.x-p.location.x,a.location.y-p.location.y,a.location.z-p.location.z)-Math.hypot(b.location.x-p.location.x,b.location.y-p.location.y,b.location.z-p.location.z))[0];
}
function visualShadowPrison(p){ const t=nearestPlayer(p,20); if(!t)return; const a=p.location,b=t.location; for(let i=1;i<=12;i++)system.runTimeout(()=>{const f=i/12,q={x:a.x+(b.x-a.x)*f,y:Math.min(a.y,b.y)+.08,z:a.z+(b.z-a.z)*f};pfx(p.dimension,"minecraft:basic_smoke_particle",q);if(i%3===0)pfx(p.dimension,"minecraft:soul_particle",q);},i); }
function visualGatsuuga(p){ for(let t=0;t<10;t++)system.runTimeout(()=>{if(!safe(()=>p.isValid(),false))return;for(let i=0;i<5;i++){const a=i*Math.PI*2/5+t*.75,r=.7+t*.035;pfx(p.dimension,"minecraft:cloud_particle",{x:p.location.x+Math.cos(a)*r,y:p.location.y+.35+(i%2)*.7,z:p.location.z+Math.sin(a)*r});}},t); }
function visualHyoton(p){ for(let r=1;r<=5;r++)system.runTimeout(()=>{ring(p,"nz:hyouton_lightblue",r,16,.12);for(let i=0;i<5;i++)pfx(p.dimension,"minecraft:snowflake_particle",randAround(p,r,.2,2));},r*2); }
function visualHozuki(p){ for(let t=0;t<12;t++)system.runTimeout(()=>{for(let i=0;i<5;i++){const a=i*Math.PI*2/5+t*.5,r=.65+Math.sin(t*.3)*.2;pfx(p.dimension,i%2?"nz:agua":"minecraft:water_splash_particle",{x:p.location.x+Math.cos(a)*r,y:p.location.y+.25+t*.12,z:p.location.z+Math.sin(a)*r});}},t); }

// v159.3: VFX dos quatro jutsus foi movido para o cast real em rp_v158_8_immersive_expansion.js.
system.runInterval(()=>{
  pulse++;
  const players=world.getAllPlayers(),start=(pulse*7)%Math.max(1,players.length);
  // Alternar a ordem evita que só os primeiros jogadores consumam o orçamento.
  for(let i=0;i<players.length;i++){
    const p=players[(start+i)%players.length];
    const key=visualKey(p), old=lastMode.get(p.id)||"";
    // Entrar com um modo já equipado não reproduz a explosão de ativação.
    if(!lastMode.has(p.id)){lastMode.set(p.id,key);continue;}
    if(key!==old){ if(key)activation(p,key); else if(old&&old!=="mangekyou")burst(p,["minecraft:basic_smoke_particle"],6,.65); lastMode.set(p.id,key); }
    // Mobile: passive sparkles run every 2 s; mode changes are still checked every second.
    if(key && pulse%2===0)passive(p,key);
  }
},20);

world.afterEvents.playerLeave.subscribe(ev=>lastMode.delete(ev.playerId));
