// Visual profiles only. These do not grant items, charge or deal damage.
export const JUTSU_VISUAL_PROFILES = {
  "nz:jutsu_suiton_daibakufu": {
    "style": "water_spiral",
    "group": "water",
    "kind": "vortex",
    "mesh": "refined_suiton_daibakufu"
  },
  "nz:jutsu_suiton_suikodan": {
    "style": "water_trail",
    "group": "water",
    "kind": "shark"
  },
  "nz:jutsu_suiton_daikodan": {
    "style": "water_trail",
    "group": "water",
    "kind": "shark"
  },
  "nz:jutsu_bakuton_bakuretsu_ken": {
    "style": "bakuton_bakuton_fist",
    "group": "bakuton",
    "kind": "line_explosion",
    "mesh": "refined_bakuton_bakuretsu_ken",
    "impact": "refined_bakuton_bakuretsu_ken_impact"
  },
  "nz:jutsu_bakuton_chikyuu_bakuha": {
    "style": "bakuton_bakuton_ground",
    "group": "bakuton",
    "kind": "carpet_explosion",
    "mesh": "refined_bakuton_chikyuu_bakuha",
    "impact": "refined_bakuton_chikyuu_bakuha_impact"
  },
  "nz:jutsu_bakuton_happa": {
    "style": "bakuton_bakuton_burst",
    "group": "bakuton",
    "kind": "blast",
    "mesh": "refined_bakuton_happa",
    "impact": "refined_bakuton_happa_impact"
  },
  "nz:jutsu_bakuton_renzoku_bakuha": {
    "style": "bakuton_bakuton_chain",
    "group": "bakuton",
    "kind": "blast",
    "mesh": "refined_bakuton_renzoku_bakuha",
    "impact": "refined_bakuton_renzoku_bakuha_impact",
    "interval": 6
  },
  "nz:jutsu_futon_daitoppa": {
    "style": "wind_spiral",
    "group": "wind",
    "kind": "vortex",
    "mesh": "refined_futon_daitoppa"
  },
  "nz:jutsu_futon_kazekiri": {
    "style": "wind_slash",
    "group": "wind",
    "kind": "crescent",
    "mesh": "refined_futon_kazekiri"
  },
  "nz:jutsu_futon_shinkugyoku": {
    "style": "wind_trail",
    "group": "wind",
    "kind": "orb",
    "mesh": "refined_futon_shinkugyoku"
  },
  "nz:jutsu_futon_shinkuha": {
    "style": "wind_slash",
    "group": "wind",
    "kind": "wind_sweep",
    "mesh": "refined_futon_shinkuha"
  },
  "nz:jutsu_gudoudama": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "dark_orb",
    "mesh": "refined_gudoudama"
  },
  "nz:jutsu_hakke_kusho": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "orb",
    "mesh": "refined_hakke_kusho"
  },
  "nz:jutsu_hirudora": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "tiger",
    "mesh": "refined_hirudora"
  },
  "nz:jutsu_hyoton_dragao_de_gelo": {
    "style": "ice_trail",
    "group": "ice",
    "kind": "dragon"
  },
  "nz:jutsu_hyoton_hyari": {
    "style": "ice_shard",
    "group": "ice",
    "kind": "spear",
    "mesh": "refined_hyoton_hyari"
  },
  "nz:jutsu_hyoton_senbon": {
    "style": "ice_shard",
    "group": "ice",
    "kind": "needle",
    "mesh": "refined_hyoton_senbon"
  },
  "nz:jutsu_hyoton_hyoketsu": {
    "style": "ice_shard",
    "group": "ice",
    "kind": "ice_orb",
    "mesh": "refined_hyoton_hyoketsu"
  },
  "nz:jutsu_inton_jigoku_goka": {
    "style": "shadow_trail",
    "group": "shadow",
    "kind": "dark_orb",
    "mesh": "refined_inton_jigoku_goka"
  },
  "nz:jutsu_inton_kage_nui": {
    "style": "shadow_trail",
    "group": "shadow",
    "kind": "shadow_spear",
    "mesh": "refined_inton_kage_nui"
  },
  "nz:jutsu_jinton_ensui": {
    "style": "dust_trail",
    "group": "dust",
    "kind": "dust_cube",
    "mesh": "refined_jinton_ensui"
  },
  "nz:jutsu_jinton_genkai_hakuri": {
    "style": "dust_beam",
    "group": "dust",
    "kind": "dust_beam",
    "mesh": "refined_jinton_genkai_hakuri"
  },
  "nz:jutsu_jinton_hashira": {
    "style": "dust_trail",
    "group": "dust",
    "kind": "dust_cylinder",
    "mesh": "refined_jinton_hashira"
  },
  "nz:jutsu_jinton_rippotai": {
    "style": "dust_trail",
    "group": "dust",
    "kind": "dust_cube",
    "mesh": "refined_jinton_rippotai"
  },
  "nz:jutsu_doton_doryo_dango": {
    "style": "earth_trail",
    "group": "earth",
    "kind": "disc",
    "mesh": "refined_doton_doryo_dango"
  },
  "nz:jutsu_doton_doryudan": {
    "style": "earth_trail",
    "group": "earth",
    "kind": "dragon"
  },
  "nz:jutsu_jiongu_costura": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "thread",
    "mesh": "refined_jiongu_costura"
  },
  "nz:jutsu_katon_bakufu_ranbu": {
    "style": "fire_spiral",
    "group": "fire",
    "kind": "fire_vortex",
    "mesh": "refined_katon_bakufu_ranbu"
  },
  "nz:jutsu_katon_goryuka": {
    "style": "fire_trail",
    "group": "fire",
    "kind": "dragon"
  },
  "nz:jutsu_katon_karyu_endan": {
    "style": "fire_trail",
    "group": "fire",
    "kind": "dragon_head"
  },
  "nz:jutsu_katon_ryuka": {
    "style": "fire_trail",
    "group": "fire",
    "kind": "fire_wave",
    "mesh": "refined_katon_ryuka"
  },
  "nz:jutsu_katon_zukokku": {
    "style": "fire_beam",
    "group": "fire",
    "kind": "beam",
    "mesh": "refined_katon_zukokku"
  },
  "nz:jutsu_kinrin_tensei_baku": {
    "style": "chakra_beam",
    "group": "chakra",
    "kind": "solar_beam",
    "mesh": "refined_kinrin_tensei_baku"
  },
  "nz:jutsu_kinshiki_corte_celestial": {
    "style": "chakra_slash",
    "group": "chakra",
    "kind": "rift_slash",
    "mesh": "refined_kinshiki_corte_celestial"
  },
  "nz:jutsu_karma_ruptura": {
    "style": "chakra_slash",
    "group": "chakra",
    "kind": "rift_slash",
    "mesh": "refined_karma_ruptura"
  },
  "nz:jutsu_mokuton_daijurin": {
    "style": "wood_trail",
    "group": "wood",
    "kind": "logs",
    "mesh": "refined_mokuton_daijurin"
  },
  "nz:jutsu_mokuton_mokujin": {
    "style": "wood_trail",
    "group": "wood",
    "kind": "wood_fist",
    "mesh": "refined_mokuton_mokujin"
  },
  "nz:jutsu_shoton_hassho_koryu": {
    "style": "crystal_trail",
    "group": "crystal",
    "kind": "dragon"
  },
  "nz:jutsu_raiton_jibashi": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "lightning_branch",
    "mesh": "refined_raiton_jibashi"
  },
  "nz:jutsu_suiton_teppodama": {
    "style": "water_trail",
    "group": "water",
    "kind": "water_orb",
    "mesh": "refined_suiton_teppodama"
  },
  "nz:jutsu_raiton_chidori_senbon": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "lightning_needle",
    "mesh": "refined_raiton_chidori_senbon"
  },
  "nz:jutsu_raiton_gian": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "lightning_beam",
    "mesh": "refined_raiton_gian"
  },
  "nz:jutsu_raiton_kangekiha": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "electro_water",
    "mesh": "refined_raiton_kangekiha"
  },
  "nz:jutsu_raiton_raikyu": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "lightning_orb",
    "mesh": "refined_raiton_raikyu"
  },
  "nz:jutsu_raiton_raiju_tsuiga": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "dog",
    "mesh": "refined_raiton_raiju_tsuiga"
  },
  "nz:jutsu_ranton_arashi_dan": {
    "style": "storm_arc",
    "group": "storm",
    "kind": "purple_lightning",
    "mesh": "refined_ranton_arashi_dan"
  },
  "nz:jutsu_ranton_kokuryu": {
    "style": "storm_arc",
    "group": "storm",
    "kind": "dragon"
  },
  "nz:jutsu_ranton_raikoha": {
    "style": "storm_arc",
    "group": "storm",
    "kind": "purple_beam",
    "mesh": "refined_ranton_raikoha"
  },
  "nz:jutsu_ranton_reiza_sakasu": {
    "style": "storm_arc",
    "group": "storm",
    "kind": "dark_wolf",
    "mesh": "refined_ranton_reiza_sakasu"
  },
  "nz:jutsu_samehada_dreno": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bite",
    "mesh": "refined_samehada_dreno"
  },
  "nz:jutsu_senpo_serpente": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "fang",
    "mesh": "refined_senpo_serpente"
  },
  "nz:jutsu_shakuton_hikari_tama": {
    "style": "scorch_trail",
    "group": "scorch",
    "kind": "sun_orb",
    "mesh": "refined_shakuton_hikari_tama"
  },
  "nz:jutsu_shakuton_kakoraku": {
    "style": "scorch_trail",
    "group": "scorch",
    "kind": "sun_orb",
    "mesh": "refined_shakuton_kakoraku"
  },
  "nz:jutsu_shakuton_neppu": {
    "style": "scorch_beam",
    "group": "scorch",
    "kind": "heat_beam",
    "mesh": "refined_shakuton_neppu"
  },
  "nz:jutsu_shakuton_shakunetsu": {
    "style": "scorch_trail",
    "group": "scorch",
    "kind": "sun_bomb",
    "mesh": "refined_shakuton_shakunetsu"
  },
  "nz:jutsu_shakuton_taiyo": {
    "style": "scorch_trail",
    "group": "scorch",
    "kind": "giant_sun",
    "mesh": "refined_shakuton_taiyo"
  },
  "nz:jutsu_shoton_shuriken": {
    "style": "crystal_shard",
    "group": "crystal",
    "kind": "shuriken",
    "mesh": "refined_shoton_shuriken"
  },
  "nz:jutsu_shoton_suisho_tou": {
    "style": "crystal_slash",
    "group": "crystal",
    "kind": "vertical_slash",
    "mesh": "refined_shoton_suisho_tou"
  },
  "nz:jutsu_suiton_mizurappa": {
    "style": "water_beam",
    "group": "water",
    "kind": "water_beam",
    "mesh": "refined_suiton_mizurappa"
  },
  "nz:jutsu_suiton_suigadan": {
    "style": "water_trail",
    "group": "water",
    "kind": "water_blast",
    "mesh": "refined_suiton_suigadan"
  },
  "nz:jutsu_yoton_kazan": {
    "style": "lava_trail",
    "group": "lava",
    "kind": "lava_orb",
    "mesh": "refined_yoton_kazan"
  },
  "nz:jutsu_yoton_yogan_ken": {
    "style": "lava_trail",
    "group": "lava",
    "kind": "lava_fist",
    "mesh": "refined_yoton_yogan_ken"
  },
  "nz:jutsu_yoton_yogan_nami": {
    "style": "lava_trail",
    "group": "lava",
    "kind": "lava_wave",
    "mesh": "refined_yoton_yogan_nami"
  },
  "nz:jutsu_bakuton_jirai_bakuha": {
    "style": "bakuton_mine",
    "group": "bakuton",
    "kind": "landmine",
    "mesh": "refined_bakuton_jirai_bakuha",
    "impact": "refined_bakuton_jirai_bakuha_impact",
    "burstTicks": 22
  },
  "nz:jutsu_byakugou_regeneracao": {
    "style": "heal_heal",
    "group": "heal",
    "kind": "green_heal",
    "mesh": "refined_byakugou_regeneracao"
  },
  "nz:jutsu_doton_domu": {
    "style": "earth_trail",
    "group": "earth",
    "kind": "stone_dome",
    "mesh": "refined_doton_domu"
  },
  "nz:jutsu_futton_joki_yoroi": {
    "style": "vapor_smoke",
    "group": "vapor",
    "kind": "vapor_armor",
    "mesh": "refined_futton_joki_yoroi"
  },
  "nz:jutsu_futton_kairiki_musou": {
    "style": "vapor_smoke",
    "group": "vapor",
    "kind": "vapor_eruption",
    "mesh": "refined_futton_kairiki_musou"
  },
  "nz:jutsu_futton_san_kiri": {
    "style": "vapor_beam",
    "group": "vapor",
    "kind": "vapor_beam",
    "mesh": "refined_futton_san_kiri"
  },
  "nz:jutsu_hyoton_hyoga": {
    "style": "ice_shard",
    "group": "ice",
    "kind": "ice_prison",
    "mesh": "refined_hyoton_hyoga"
  },
  "nz:jutsu_hyoton_hyoro": {
    "style": "ice_pulse",
    "group": "ice",
    "kind": "ground_spike",
    "mesh": "refined_hyoton_hyoro"
  },
  "nz:jutsu_inton_kage_kubishibari": {
    "style": "shadow_bind",
    "group": "shadow",
    "kind": "shadow_grip",
    "mesh": "refined_inton_kage_kubishibari"
  },
  "nz:jutsu_inton_kurayami": {
    "style": "shadow_pulse",
    "group": "shadow",
    "kind": "dark_zone",
    "mesh": "refined_inton_kurayami"
  },
  "nz:jutsu_inton_narakumi": {
    "style": "shadow_bind",
    "group": "shadow",
    "kind": "shadow_control",
    "mesh": "refined_inton_narakumi"
  },
  "nz:jutsu_jinton_kekkai": {
    "style": "dust_bind",
    "group": "dust",
    "kind": "dust_prison",
    "mesh": "refined_jinton_kekkai"
  },
  "nz:jutsu_jirobo_prisao": {
    "style": "chakra_bind",
    "group": "chakra",
    "kind": "earth_prison",
    "mesh": "refined_jirobo_prisao"
  },
  "nz:jutsu_jiton_jiki_fuin": {
    "style": "sand_bind",
    "group": "sand",
    "kind": "magnetic_bind",
    "mesh": "refined_jiton_jiki_fuin"
  },
  "nz:jutsu_jiton_sakin_kabe": {
    "style": "sand_trail",
    "group": "sand",
    "kind": "gold_wall",
    "mesh": "refined_jiton_sakin_kabe"
  },
  "nz:jutsu_jiton_sakin_shigure": {
    "style": "sand_rain",
    "group": "sand",
    "kind": "gold_rain",
    "mesh": "refined_jiton_sakin_shigure"
  },
  "nz:jutsu_jiton_satetsu_kaiho": {
    "style": "sand_trail",
    "group": "sand",
    "kind": "iron_sand_wave",
    "mesh": "refined_jiton_satetsu_kaiho"
  },
  "nz:jutsu_jiton_suna_tekkin": {
    "style": "sand_bind",
    "group": "sand",
    "kind": "gold_bind",
    "mesh": "refined_jiton_suna_tekkin"
  },
  "nz:jutsu_jougan_tenketsu": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "chakra_hits",
    "mesh": "refined_jougan_tenketsu"
  },
  "nz:jutsu_kamui_intangivel": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "intangible",
    "mesh": "refined_kamui_intangivel"
  },
  "nz:jutsu_suiton_suidan": {
    "style": "water_pulse",
    "group": "water",
    "kind": "intangible",
    "mesh": "refined_suiton_suidan"
  },
  "nz:jutsu_mokuton_mokujouheki": {
    "style": "wood_trail",
    "group": "wood",
    "kind": "wood_half_dome",
    "mesh": "refined_mokuton_mokujouheki"
  },
  "nz:jutsu_katon_haisekisho": {
    "style": "fire_smoke",
    "group": "fire",
    "kind": "smoke_ignite",
    "mesh": "refined_katon_haisekisho"
  },
  "nz:jutsu_raiton_raiga": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "lightning_burst",
    "mesh": "refined_raiton_raiga"
  },
  "nz:jutsu_ranton_kumo_arashi": {
    "style": "storm_arc",
    "group": "storm",
    "kind": "purple_rain",
    "mesh": "refined_ranton_kumo_arashi"
  },
  "nz:jutsu_rugido_fera": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "wind_roar",
    "mesh": "refined_rugido_fera"
  },
  "nz:jutsu_sakon_impacto": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "twin_impact",
    "mesh": "refined_sakon_impacto"
  },
  "nz:jutsu_senpo_escamas": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "scale_aura",
    "mesh": "refined_senpo_escamas"
  },
  "nz:jutsu_senpo_mokuton": {
    "style": "wood_trail",
    "group": "wood",
    "kind": "root_barrier",
    "mesh": "refined_senpo_mokuton"
  },
  "nz:jutsu_shoton_kessho_ro": {
    "style": "crystal_shard",
    "group": "crystal",
    "kind": "amethyst_prison",
    "mesh": "refined_shoton_kessho_ro"
  },
  "nz:jutsu_suiton_bakusui_shoha": {
    "style": "water_pulse",
    "group": "water",
    "kind": "tsunami_pool",
    "mesh": "refined_suiton_bakusui_shoha"
  },
  "nz:jutsu_suiton_suishoha": {
    "style": "water_trail",
    "group": "water",
    "kind": "water_dome",
    "mesh": "refined_suiton_suishoha"
  },
  "nz:jutsu_teia_dourada": {
    "style": "chakra_bind",
    "group": "chakra",
    "kind": "golden_threads",
    "mesh": "refined_teia_dourada"
  },
  "nz:jutsu_tenpenchii": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "five_elements",
    "mesh": "refined_tenpenchii"
  },
  "nz:jutsu_tenseigan_orbita": {
    "style": "chakra_spiral",
    "group": "chakra",
    "kind": "gravity",
    "mesh": "refined_tenseigan_orbita"
  },
  "nz:jutsu_veneno_marionete": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "poison_needles",
    "mesh": "refined_veneno_marionete"
  },
  "nz:jutsu_yang_chakra_transfer": {
    "style": "heal_heal",
    "group": "heal",
    "kind": "chakra_transfer",
    "mesh": "refined_yang_chakra_transfer"
  },
  "nz:jutsu_yang_saisei": {
    "style": "heal_heal",
    "group": "heal",
    "kind": "yellow_heal",
    "mesh": "refined_yang_saisei"
  },
  "nz:jutsu_yang_seimei": {
    "style": "heal_heal",
    "group": "heal",
    "kind": "revive",
    "mesh": "refined_yang_seimei"
  },
  "nz:jutsu_yang_shosen": {
    "style": "heal_pulse",
    "group": "heal",
    "kind": "heal_hits",
    "mesh": "refined_yang_shosen"
  },
  "nz:jutsu_yang_tate": {
    "style": "heal_heal",
    "group": "heal",
    "kind": "team_heal",
    "mesh": "refined_yang_tate"
  },
  "nz:jutsu_yang_vital_burst": {
    "style": "heal_heal",
    "group": "heal",
    "kind": "full_heal",
    "mesh": "refined_yang_vital_burst"
  },
  "nz:jutsu_yoton_yokai": {
    "style": "lava_trail",
    "group": "lava",
    "kind": "honey_wall",
    "mesh": "refined_yoton_yokai"
  },
  "nz:jutsu_sharingan_contragolpe": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "counter",
    "mesh": "refined_sharingan_contragolpe"
  },
  "nz:jutsu_tayuya_dissonancia": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "sound_zone",
    "mesh": "refined_tayuya_dissonancia"
  },
  "nz:jutsu_selo_chidori": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "dash"
  },
  "nz:jutsu_portoes_impacto": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "uppercut",
    "mesh": "refined_portoes_impacto"
  },
  "nz:jutsu_presa_trovao": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "dash"
  },
  "nz:jutsu_suika_pressao": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "orb",
    "mesh": "refined_suika_pressao"
  },
  "nz:jutsu_devolver_jutsu": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "return_jutsu",
    "mesh": "refined_devolver_jutsu"
  },
  "nz:jutsu_hatake_corte_relampago": {
    "style": "chakra_slash",
    "group": "chakra",
    "kind": "rift_slash",
    "mesh": "refined_hatake_corte_relampago"
  },
  "nz:jutsu_doton_iwa_yado_kuzushi": {
    "style": "earth_pulse",
    "group": "earth",
    "kind": "earth_crush",
    "mesh": "refined_doton_iwa_yado_kuzushi"
  },
  "nz:jutsu_doton_kajugan": {
    "style": "earth_pulse",
    "group": "earth",
    "kind": "heavy_body",
    "mesh": "refined_doton_kajugan"
  },
  "nz:jutsu_inton_chakra_fuin": {
    "style": "shadow_trail",
    "group": "shadow",
    "kind": "chakra_seal",
    "mesh": "refined_inton_chakra_fuin"
  },
  "nz:jutsu_shoton_suishoheki": {
    "style": "crystal_trail",
    "group": "crystal",
    "kind": "crystal_wall",
    "mesh": "refined_shoton_suishoheki"
  },
  "nz:jutsu_yoton_yogan_kabe": {
    "style": "lava_trail",
    "group": "lava",
    "kind": "lava_wall",
    "mesh": "refined_yoton_yogan_kabe"
  },
  "nz:jutsu_futton_joki": {
    "style": "vapor_smoke",
    "group": "vapor",
    "kind": "vapor_zone",
    "mesh": "refined_futton_joki"
  },
  "nz:jutsu_futton_atsu": {
    "style": "vapor_smoke",
    "group": "vapor",
    "kind": "vapor_eruption",
    "mesh": "refined_futton_atsu"
  },
  "nz:jutsu_bansho_tenin": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "pull",
    "mesh": "refined_bansho_tenin"
  },
  "nz:jutsu_rinne_tensei": {
    "style": "chakra_heal",
    "group": "chakra",
    "kind": "revive",
    "mesh": "refined_rinne_tensei"
  },
  "nz:jutsu_yasaka_magatama": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "magatama"
  },
  "nz:jutsu_baika_no_jutsu": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "expansion",
    "mesh": "refined_baika_no_jutsu"
  },
  "nz:jutsu_iburi_fumaca": {
    "style": "chakra_smoke",
    "group": "chakra",
    "kind": "smoke_body",
    "mesh": "refined_iburi_fumaca"
  },
  "nz:jutsu_shunshin": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "dash_move",
    "mesh": "refined_shunshin"
  },
  "nz:jutsu_odama_rasengan": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "rasengan_orb"
  },
  "nz:jutsu_senpo_cho_odama_rasengan": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "rasengan_orb"
  },
  "nz:jutsu_raiton_lariat": {
    "style": "lightning_arc",
    "group": "lightning",
    "kind": "dash"
  },
  "nz:jutsu_susanoo_arrow": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "arrow"
  },
  "nz:jutsu_chibaku_meteoro": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "meteor",
    "phases": {
      "trail": "nzs:v18399_meteor_trail",
      "warning": "nzs:v18399_meteor_warning",
      "impact": "nzs:v18399_meteor_shock",
      "debris": "nzs:v18399_meteor_debris",
      "flash": "nzs:v18399_meteor_flash",
      "dust": "nzs:v18401_meteor_dust"
    }
  },
  "nz:jutsu_amaterasu_kamui_shuriken": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "black_shuriken"
  },
  "nz:jutsu_genjutsu_shisui": {
    "style": "shadow_trail",
    "group": "shadow",
    "kind": "genjutsu"
  },
  "nz:jutsu_shindenshin_no_jutsu": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "mind_link",
    "mesh": "refined_shindenshin_no_jutsu"
  },
  "nz:jutsu_shinranshin_no_jutsu": {
    "style": "chakra_bind",
    "group": "chakra",
    "kind": "shadow_control",
    "mesh": "refined_shinranshin_no_jutsu"
  },
  "nz:jutsu_suna_shigure": {
    "style": "sand_rain",
    "group": "sand",
    "kind": "sand_rain"
  },
  "nz:jutsu_sabaku_kyu": {
    "style": "chakra_bind",
    "group": "chakra",
    "kind": "sand_prison"
  },
  "nz:jutsu_sabaku_soso": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "sand_crush"
  },
  "nz:jutsu_kaiten": {
    "style": "chakra_spiral",
    "group": "chakra",
    "kind": "rotation_guard"
  },
  "nz:jutsu_konoha_daisenpu": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "physical_sweep",
    "mesh": "refined_konoha_daisenpu"
  },
  "nz:jutsu_sawarabi_no_mai": {
    "style": "chakra_pulse",
    "group": "chakra",
    "kind": "bone_spikes",
    "mesh": "refined_sawarabi_no_mai",
    "phases": { "trail": "swbr:kaguya_fragmento_osseo", "impact": "swbr:kaguya_fragmento_osseo" }
  },
  "nz:jutsu_rasen_shuriken_shukaku": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_matatabi": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_isobu": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_songoku": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_kokuo": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_saiken": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_chomei": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_gyuki": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_kurama": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_rasen_shuriken_juubi": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "bijuu_shuriken"
  },
  "nz:jutsu_amenominaka": {
    "style": "chakra_trail",
    "group": "chakra",
    "kind": "space_shift",
    "mesh": "refined_amenominaka"
  },
  "nz:jutsu_futon_reppusho": {
    "style": "wind_trail",
    "group": "wind",
    "kind": "wind_push",
    "mesh": "refined_futon_reppusho"
  }
};
